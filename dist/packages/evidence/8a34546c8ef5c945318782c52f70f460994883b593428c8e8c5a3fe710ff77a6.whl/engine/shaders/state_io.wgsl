// ca-v2 storage adapter. A cell is its packed view AND conserved energy.
@group(0) @binding(0) var<storage, read> grid_in: array<u32>;
@group(0) @binding(1) var<storage, read_write> grid_out: array<u32>;
@group(0) @binding(2) var<storage, read> cold_table: array<u32>;
@group(0) @binding(3) var<storage, read> energy_in: array<u32>;
@group(0) @binding(4) var<storage, read_write> energy_out: array<u32>;

const MAX_ENERGY_Q: u32 = 0x3fffffffu;
const NO_MATERIAL: u32 = 256u;
const NO_CELL: u32 = 0xffffffffu;

fn io_cold(material: u32, field: u32) -> u32 {
    return cold_table[material * 24u + field];
}

// Same logical property layout as Thermodynamics.gpu_table(); this adapter
// reads the authoritative cold table, so material edits need no shader rewrite.
fn property(material: u32, field: u32) -> u32 {
    switch field {
        case 0u: { return io_cold(material, 1u); }
        case 1u: { return io_cold(material, 19u) * 256u; }
        case 2u: { return io_cold(material, 16u) * 256u; }
        case 3u: {
            let boil = io_cold(material, 13u);
            if (boil != 0u) { return boil; }
            let melt = io_cold(material, 12u);
            return select(NO_MATERIAL, melt, melt != 0u);
        }
        case 4u: {
            if (io_cold(material, 13u) != 0u) { return io_cold(material, 3u) * 256u; }
            return io_cold(material, 2u) * 256u;
        }
        case 5u: {
            let freeze = io_cold(material, 14u);
            if (freeze != 0u) { return freeze; }
            let condense = io_cold(material, 15u);
            return select(NO_MATERIAL, condense, condense != 0u);
        }
        case 6u: {
            if (io_cold(material, 14u) != 0u) { return io_cold(material, 8u) * 256u; }
            return io_cold(material, 9u) * 256u;
        }
        case 7u: { return io_cold(material, 17u); }
        case 8u: { return io_cold(material, 18u); }
        case 9u: { return io_cold(material, 21u); }
        case 10u: { return io_cold(material, 4u) * 256u; }
        default: { return 0u; }
    }
}

fn io_state(index: u32) -> vec2<u32> {
    return vec2<u32>(grid_in[index] & MATERIAL_MASK, energy_in[index]);
}

fn io_copy(destination: u32, source: u32) {
    grid_out[destination] = grid_in[source];
    energy_out[destination] = energy_in[source];
}

fn io_write(index: u32, packed: u32, energy: u32) {
    let temperature = min(255u, temperature_q(vec2<u32>(packed & MATERIAL_MASK, energy)) / 256u);
    grid_out[index] = (packed & 0xffff00ffu) | (temperature << THERMAL_SHIFT);
    energy_out[index] = energy;
}

fn io_rewrite(packed: u32, material: u32) -> u32 {
    return (packed & 0xf0ff0000u) | material | (io_cold(material, 20u) << PHASE_SHIFT);
}
