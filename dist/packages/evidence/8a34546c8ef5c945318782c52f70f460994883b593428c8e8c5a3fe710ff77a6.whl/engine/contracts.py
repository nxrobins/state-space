"""Validation and portable snapshots for the current engine contract."""

from dataclasses import dataclass, field

import numpy as np

from engine.validation import (MAX_CELLS as MAX_CELLS, MAX_TICK as MAX_TICK, checked_integer as checked_integer,
                               validate_dimensions as validate_dimensions, validate_packed as validate_packed)
from engine.registry import DEFAULT_REGISTRY, MaterialRegistry
from engine.state import validate_state
from engine._generated_schema import SCHEMA_VERSION as SCHEMA_VERSION
from engine.version import RULES_VERSION as RULES_VERSION


MATERIAL_CATALOG_HASH = DEFAULT_REGISTRY.hash
@dataclass(frozen=True)
class Snapshot:
    width: int
    height: int
    tick: int
    packed_cells: np.ndarray
    energy_q: np.ndarray
    schema_version: int = SCHEMA_VERSION
    rules_version: str = RULES_VERSION
    material_catalog_hash: str | None = None
    registry: MaterialRegistry = field(default=DEFAULT_REGISTRY, repr=False, compare=False, kw_only=True)

    def __post_init__(self):
        width, height = validate_dimensions(self.width, self.height)
        checked_integer(self.tick, 0, MAX_TICK, "tick")
        if type(self.schema_version) is not int or self.schema_version != SCHEMA_VERSION:
            raise ValueError("Unsupported snapshot schema version")
        if self.rules_version != RULES_VERSION:
            raise ValueError("Incompatible snapshot rules version")
        if not isinstance(self.registry, MaterialRegistry):
            raise ValueError("Snapshot requires a validated material registry")
        expected_hash = self.registry.hash
        if self.material_catalog_hash is None:
            object.__setattr__(self, "material_catalog_hash", expected_hash)
        if self.material_catalog_hash != expected_hash:
            raise ValueError("Incompatible snapshot material catalog")
        cells, energy = validate_state(self.packed_cells, self.energy_q, width * height, self.registry._model)
        # Immutable bytes prevent callers from re-enabling ndarray writeability.
        object.__setattr__(self, "packed_cells", np.frombuffer(cells.astype("<u4").tobytes(), dtype="<u4"))
        object.__setattr__(self, "energy_q", np.frombuffer(energy.astype("<u4").tobytes(), dtype="<u4"))

    def to_dict(self) -> dict:
        return {"schemaVersion": self.schema_version, "rulesVersion": self.rules_version,
                "materialCatalogHash": self.material_catalog_hash, "width": int(self.width),
                "height": int(self.height), "tick": int(self.tick), "packedCells": self.packed_cells.tolist(),
                "energyQ": self.energy_q.tolist()}

    @classmethod
    def from_dict(cls, value: dict, *, registry: MaterialRegistry = DEFAULT_REGISTRY) -> "Snapshot":
        expected = {"schemaVersion", "rulesVersion", "materialCatalogHash", "width", "height", "tick", "packedCells", "energyQ"}
        if not isinstance(value, dict) or set(value) != expected:
            raise ValueError("Snapshot contains missing or unexpected fields")
        if not isinstance(value["materialCatalogHash"], str):
            raise ValueError("Snapshot transport requires an explicit material catalog hash")
        return cls(value["width"], value["height"], value["tick"], value["packedCells"], value["energyQ"],
                   value["schemaVersion"], value["rulesVersion"], value["materialCatalogHash"], registry=registry)
