"""
Phase 2e: Composition Engine

Dispatches the physics kernels per tick in locked order. Phase 2 movement is
split into conservative swap passes before thermal/reaction work:
  vertical0 -> vertical1 -> diagonal0 -> diagonal1 -> liquid0 -> liquid1
  -> gas_buoyancy0 -> gas_buoyancy1 -> gas_spread0 -> gas_spread1
  -> thermal_x0 -> thermal_x1 -> thermal_y0 -> thermal_y1 -> phase -> combustion

Each kernel runs as a full double-buffer pass: reads grid_A, writes grid_B,
then swap.

The cold table is shared read-only across all kernels.
"""

import time
from contextlib import ExitStack
import numpy as np
import wgpu

from engine.wgsl_fixer import strip_entry_points_and_bindings
from engine.schedule import KERNEL_SPECS as KERNEL_SPECS, movement_schedule_for_tick as movement_schedule_for_tick
from engine.contracts import MAX_TICK, checked_integer, validate_dimensions, validate_packed
from engine.schema import COLD_TABLE_ENTRIES, COLD_TABLE_STRIDE
from engine.state import seed_state, thermodynamics_from_cold, validate_state
from engine.registry import MaterialRegistry
from engine.sources import ShaderBundle
from engine.array_state import energy_ledger_array


class CompositionEngine:
    """Runs the full physics pipeline per tick."""

    def __init__(self, grid_width: int | None = None, grid_height: int | None = None, *, sources: ShaderBundle | None = None):
        if (grid_width is None) != (grid_height is None):
            raise ValueError("Provide both grid dimensions or neither")
        if grid_width is not None:
            validate_dimensions(grid_width, grid_height)
        if sources is not None and not isinstance(sources, ShaderBundle):
            raise ValueError("sources must be an immutable ShaderBundle")
        self._sources = sources if sources is not None else ShaderBundle.load()
        self._bitmask_defs = self._sources.shader("bitmask_defs.wgsl")
        self._locked_1a = strip_entry_points_and_bindings(self._sources.kernel("phase_1a_winner.wgsl"))
        self._state_io = self._sources.shader("state_io.wgsl")
        self._enthalpy_law = self._sources.shader("enthalpy_law.wgsl")
        self._closed = False
        self.adapter = wgpu.gpu.request_adapter_sync(power_preference="high-performance")
        if self.adapter is None:
            raise RuntimeError("No GPU adapter found")
        self.device = self.adapter.request_device_sync()
        self.pipelines = {}
        self.kernel_sources = {}
        self._compiled_dims: tuple[int, int] | None = None

        if grid_width is not None and grid_height is not None:
            try:
                self._compile_pipelines(grid_width, grid_height)
            except Exception:
                self.close()
                raise

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self.pipelines.clear()
            self.kernel_sources.clear()
            self.device.destroy()

    def __enter__(self):
        self._ensure_open()
        return self

    def __exit__(self, *_exc):
        self.close()

    def _ensure_open(self) -> None:
        if self._closed:
            raise RuntimeError("Composition engine is closed")

    def _compile_pipelines(self, grid_width: int, grid_height: int) -> None:
        """Compile kernels specialized to the requested grid dimensions."""
        self._ensure_open()
        dims = validate_dimensions(grid_width, grid_height)
        if dims[0] * dims[1] * 4 > self.device.limits["max-storage-buffer-binding-size"]:
            raise ValueError("Grid exceeds the device storage buffer binding limit")
        if any((dimension + 15) // 16 > self.device.limits["max-compute-workgroups-per-dimension"] for dimension in dims):
            raise ValueError("Grid exceeds the device dispatch dimension limit")
        if self._compiled_dims == dims:
            return

        pipelines = {}
        kernel_sources = {}
        constants = {"GRID_WIDTH": dims[0], "GRID_HEIGHT": dims[1]}

        for spec in KERNEL_SPECS:
            kernel_code = self._sources.kernel(spec.source_file)
            full_code = self._bitmask_defs + "\n\n" + self._locked_1a + "\n\n" + self._state_io + "\n" + self._enthalpy_law + "\n" + kernel_code
            kernel_sources[spec.id] = full_code

            shader = self.device.create_shader_module(code=full_code)

            # Bindings: packed in/out, cold table, energy in/out.
            bgl = self.device.create_bind_group_layout(entries=[
                {"binding": 0, "visibility": wgpu.ShaderStage.COMPUTE,
                 "buffer": {"type": wgpu.BufferBindingType.read_only_storage}},
                {"binding": 1, "visibility": wgpu.ShaderStage.COMPUTE,
                 "buffer": {"type": wgpu.BufferBindingType.storage}},
                {"binding": 2, "visibility": wgpu.ShaderStage.COMPUTE,
                 "buffer": {"type": wgpu.BufferBindingType.read_only_storage}},
                {"binding": 3, "visibility": wgpu.ShaderStage.COMPUTE,
                 "buffer": {"type": wgpu.BufferBindingType.read_only_storage}},
                {"binding": 4, "visibility": wgpu.ShaderStage.COMPUTE,
                 "buffer": {"type": wgpu.BufferBindingType.storage}},
            ])

            pl = self.device.create_pipeline_layout(bind_group_layouts=[bgl])
            pipeline_constants = {**constants, **spec.constants}
            pipeline = self.device.create_compute_pipeline(
                layout=pl,
                compute={"module": shader, "entry_point": "tick", "constants": pipeline_constants},
            )
            pipelines[spec.id] = (pipeline, bgl)

        self.pipelines, self.kernel_sources = pipelines, kernel_sources
        self._compiled_dims = dims
        print(f"CompositionEngine: {len(self.pipelines)} pipelines compiled for {dims[0]}x{dims[1]}")
        print("  Tick schedule:")
        for pid in movement_schedule_for_tick(0):
            spec = next(s for s in KERNEL_SPECS if s.id == pid)
            print(f"    {spec.name:32s} [{pid}]")

    def run(
        self,
        initial_grid: np.ndarray,
        cold_table: np.ndarray,
        grid_width: int,
        grid_height: int,
        n_ticks: int = 200,
        snapshot_interval: int = 0,
        start_tick: int = 0,
        trace_passes: bool = False,
        initial_energy: np.ndarray | None = None,
        registry: MaterialRegistry | None = None,
    ) -> dict:
        """
        Run n_ticks of the full composed physics pipeline.

        Returns dict with:
          - final_grid: np.ndarray of the final state
          - tick_times_ms: list of per-tick wall-clock times
          - total_time_ms: total wall-clock time
          - snapshots: list of (tick, grid) tuples if snapshot_interval > 0
        """
        self._ensure_open()
        grid_width, grid_height = validate_dimensions(grid_width, grid_height)
        n_ticks = checked_integer(n_ticks, 0, MAX_TICK, "n_ticks")
        start_tick = checked_integer(start_tick, 0, MAX_TICK, "start_tick")
        checked_integer(start_tick + n_ticks, 0, MAX_TICK, "end_tick")
        snapshot_interval = checked_integer(snapshot_interval, 0, MAX_TICK, "snapshot_interval")
        if type(trace_passes) is not bool:
            raise ValueError("trace_passes must be a boolean")
        initial_grid = validate_packed(initial_grid, grid_width * grid_height)
        cold_table = validate_packed(cold_table, COLD_TABLE_ENTRIES * COLD_TABLE_STRIDE, "cold_table")
        if registry is not None:
            if not isinstance(registry, MaterialRegistry) or not np.array_equal(cold_table, registry.cold_table()):
                raise ValueError("Cold table must match the supplied validated registry")
            model = registry._model
        else:
            model = thermodynamics_from_cold(cold_table)
        if initial_energy is None:
            if start_tick:
                raise ValueError("Continuation requires initial_energy; a packed grid cannot preserve latent or fractional energy")
            initial_grid, initial_energy = seed_state(initial_grid, model)
        else:
            initial_grid, initial_energy = validate_state(initial_grid, initial_energy, grid_width * grid_height, model)
        self._compile_pipelines(grid_width, grid_height)

        N = grid_width * grid_height
        wg_x = (grid_width + 15) // 16
        wg_y = (grid_height + 15) // 16

        with ExitStack() as resources:
            def keep(buffer):
                resources.callback(buffer.destroy)
                return buffer

            # Create double buffers
            grid_a = keep(self.device.create_buffer_with_data(
                data=initial_grid.astype(np.uint32).tobytes(),
                usage=wgpu.BufferUsage.STORAGE | wgpu.BufferUsage.COPY_SRC,
            ))
            grid_b = keep(self.device.create_buffer(
                size=N * 4,
                usage=wgpu.BufferUsage.STORAGE | wgpu.BufferUsage.COPY_SRC,
            ))
            energy_a = keep(self.device.create_buffer_with_data(
                data=initial_energy.tobytes(), usage=wgpu.BufferUsage.STORAGE | wgpu.BufferUsage.COPY_SRC))
            energy_b = keep(self.device.create_buffer(size=N * 4, usage=wgpu.BufferUsage.STORAGE | wgpu.BufferUsage.COPY_SRC))
            cold_buf = keep(self.device.create_buffer_with_data(
                data=cold_table.astype(np.uint32).tobytes(),
                usage=wgpu.BufferUsage.STORAGE,
            ))

            # Pre-create bind groups for both directions, for each kernel
            bind_groups = {}
            for spec in KERNEL_SPECS:
                _, bgl = self.pipelines[spec.id]
                bind_groups[(spec.id, "ab")] = self.device.create_bind_group(
                    layout=bgl, entries=[
                        {"binding": 0, "resource": {"buffer": grid_a, "offset": 0, "size": grid_a.size}},
                        {"binding": 1, "resource": {"buffer": grid_b, "offset": 0, "size": grid_b.size}},
                        {"binding": 2, "resource": {"buffer": cold_buf, "offset": 0, "size": cold_buf.size}},
                        {"binding": 3, "resource": {"buffer": energy_a}},
                        {"binding": 4, "resource": {"buffer": energy_b}},
                    ])
                bind_groups[(spec.id, "ba")] = self.device.create_bind_group(
                    layout=bgl, entries=[
                        {"binding": 0, "resource": {"buffer": grid_b, "offset": 0, "size": grid_b.size}},
                        {"binding": 1, "resource": {"buffer": grid_a, "offset": 0, "size": grid_a.size}},
                        {"binding": 2, "resource": {"buffer": cold_buf, "offset": 0, "size": cold_buf.size}},
                        {"binding": 3, "resource": {"buffer": energy_b}},
                        {"binding": 4, "resource": {"buffer": energy_a}},
                    ])

            # Run ticks
            tick_times = []
            snapshots = []
            pass_snapshots = []
            energy_snapshots = []
            pass_energy_snapshots = []
            # Track which buffer is "current" (contains latest state)
            # Start: grid_a has initial state
            current_is_a = True

            for tick in range(start_tick, start_tick + n_ticks):
                t0 = time.perf_counter()

                for phase_id in movement_schedule_for_tick(tick):
                    pipeline, _ = self.pipelines[phase_id]

                    # Determine read/write direction
                    if current_is_a:
                        bg = bind_groups[(phase_id, "ab")]  # read A, write B
                    else:
                        bg = bind_groups[(phase_id, "ba")]  # read B, write A

                    encoder = self.device.create_command_encoder()
                    cp = encoder.begin_compute_pass()
                    cp.set_pipeline(pipeline)
                    cp.set_bind_group(0, bg)
                    cp.dispatch_workgroups(wg_x, wg_y)
                    cp.end()
                    self.device.queue.submit([encoder.finish()])

                    # Swap buffers after each kernel
                    current_is_a = not current_is_a
                    if trace_passes:
                        buffer = grid_a if current_is_a else grid_b
                        state = np.frombuffer(self.device.queue.read_buffer(buffer), dtype=np.uint32).copy()
                        pass_snapshots.append((tick, phase_id, state))
                        energy_buffer = energy_a if current_is_a else energy_b
                        energy = np.frombuffer(self.device.queue.read_buffer(energy_buffer), dtype=np.uint32).copy()
                        pass_energy_snapshots.append((tick, phase_id, energy))

                # Force GPU sync at end of tick (read 4 bytes to flush)
                sync_buf = grid_a if current_is_a else grid_b
                _ = self.device.queue.read_buffer(sync_buf, size=4)
                t1 = time.perf_counter()
                tick_times.append((t1 - t0) * 1000)

                # Optional snapshot
                if snapshot_interval > 0 and (tick + 1) % snapshot_interval == 0:
                    data = np.frombuffer(
                        self.device.queue.read_buffer(sync_buf),
                        dtype=np.uint32
                    )
                    snapshots.append((tick + 1, data.copy()))
                    energy_buffer = energy_a if current_is_a else energy_b
                    energy_snapshots.append((tick + 1, np.frombuffer(self.device.queue.read_buffer(energy_buffer), dtype=np.uint32).copy()))

            # Read final state
            final_buf = grid_a if current_is_a else grid_b
            final_grid = np.frombuffer(
                self.device.queue.read_buffer(final_buf),
                dtype=np.uint32
            )
            final_energy = np.frombuffer(self.device.queue.read_buffer(energy_a if current_is_a else energy_b), dtype=np.uint32).copy()

            return {
                "final_grid": final_grid.copy(),
                "initial_grid": initial_grid.copy(),
                "initial_energy": initial_energy.copy(),
                "final_energy": final_energy,
                "energy_ledger": energy_ledger_array(final_grid & 255, final_energy, model),
                "tick_times_ms": tick_times,
                "total_time_ms": sum(tick_times),
                "mean_tick_ms": float(np.mean(tick_times)) if tick_times else 0.0,
                "snapshots": snapshots,
                "start_tick": start_tick,
                "end_tick": start_tick + n_ticks,
                "pass_snapshots": pass_snapshots,
                "energy_snapshots": energy_snapshots,
                "pass_energy_snapshots": pass_energy_snapshots,
            }
