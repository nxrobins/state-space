# State Space

[![License](https://img.shields.io/github/license/nxrobins/state-space)](LICENSE)
[![GitHub last commit](https://img.shields.io/github/last-commit/nxrobins/state-space/main)](https://github.com/nxrobins/state-space/commits/main)
[![Open issues](https://img.shields.io/github/issues/nxrobins/state-space)](https://github.com/nxrobins/state-space/issues)
[![GitHub stars](https://img.shields.io/github/stars/nxrobins/state-space)](https://github.com/nxrobins/state-space/stargazers)

State Space is a deterministic cellular material engine for games and simulation
tools. Movement, heat, phase changes, combustion, and structural failure share one
replayable state: water freezes into bonded ice, fuel releases stored energy, and
burning supports can break and drop the fragments they were holding.

Version **0.4** provides native Python GPU, browser WebGPU, and browser/Node.js CPU
backends with a shared state contract. The engine is the core product; the lab and
game prototypes demonstrate how clients can build on it.

- **Exact energy accounting.** Integer energy tracks sensible, latent, and
  chemical stores. Closed-system ticks conserve their total; edits are recorded
  as external input or output.
- **Persistent structures.** Bonds, integrity, and anchors govern support,
  damage, breakage, and coherent fragment movement. Global support paths are
  solved to completion.
- **Pressure and velocity.** Water loads dams; trapped hot gas can break walls.
  Persistent integer pressure and quantized velocity drive flow after a breach.
  [The cellular model](docs/PRESSURE.md) defines its units and limits.
- **Portable continuation.** Complete snapshots carry cells, energy, structure,
  the absolute tick, and material-registry identity. Restore across backends with
  the same registry and continue the same simulation.
- **Inspectable and extensible.** Edit and sample fields, inspect individual
  passes, and define custom materials through validated registries.

## Try the engine lab

Install Python **3.10+**, Node.js/npm, and `uv`. From the repository root:

```powershell
uv sync
npm ci
npm run build:sdk
uv run python -m http.server 8765 --bind 127.0.0.1
```

Open the [engine lab](http://127.0.0.1:8765/examples/lab/). Five experiments cover
support, coherent fragments, burning supports, phase changes, and custom
materials. Inspect cells and bonds, change the scene, switch backends, and export
or restore complete sessions.

The lab starts on the CPU backend. Select WebGPU to use a compatible GPU adapter;
WebGPU requires a secure browser context, including localhost. The lab's small
interactive scenes are separate from the performance workloads below.

For the visual showcase, open the [burning bridge](http://127.0.0.1:8765/web/):
built-in material shading, energy-derived heat glow, dynamic fire/lava lighting,
soft terrain shadows, lit volumetric smoke/steam, water reflections/refraction,
heat distortion, and bloom. All presentation toggles use the same deterministic field.
Try the [smoke and steam chambers](http://127.0.0.1:8765/web/?scene=haze&paused)
and press **H** to compare the volume effect.
Try the [heat shimmer chambers](http://127.0.0.1:8765/web/?scene=heat&paused)
and press **D** to compare distortion.
Try the [dams and pressure vessels](http://127.0.0.1:8765/web/?scene=pressure&paused)
to compare wooden/metal dams and sealed/vented steam containers.
[Rendering guide and native Python API](docs/RENDERING.md) ·
[Current full-frame measurements](docs/checkpoints/PRESSURE_PERFORMANCE.md).

## 256 × 256 at 60 Hz

The current **ca-v4** benchmark measures complete 1920 × 1080 rendered frames on
an **Intel i9-11900K / NVIDIA RTX 4090**, with every effect enabled and a 256 × 256
physics grid. Six scenes each run 600 measured display-paced frames after warmup.

The **pressure gallery passed**: 10.0 ms median work, 11.7 ms p95, and a maximum
14.4 ms from display callback to GPU completion. Bridge, water, haze and heat
also passed. The **overall strict lock remains open**: both complete runs had
one 24–25 ms lighting frame that delayed the next frame, causing **two deadline
misses out of 3,600 frames**. All scenes sustained approximately 59.95 Hz;
none missed a display slot or coalesced a callback.

Timing includes all 23 physics passes, global support/pressure planning,
validation, state transfers, every rendering pass and GPU completion. Startup,
reference hashing and OS scanout are excluded. The initial pressure ruptures are
also timed separately from tick zero; browser p95 was 11.3 ms with all effects on.

All 60 rendered/replayed trajectories per complete run matched the CPU reference,
including pressure and velocity, with zero thermal/latent/chemical energy drift.
See the [pressure performance report](docs/checkpoints/PRESSURE_PERFORMANCE.md)
for raw results, native measurements, retained failures and reproduction.
The earlier [GPU tick](docs/checkpoints/GPU_PERFORMANCE.md) and
[browser pacing](docs/checkpoints/PACING_PERFORMANCE.md) reports describe ca-v3.

## Use the SDK

| Runtime | Entry point | Stepping |
| --- | --- | --- |
| Python, native GPU | `engine.create_field` | Synchronous |
| Browser, WebGPU | `createGpuField` | Asynchronous |
| Browser or Node.js, CPU | `createStateSpaceField` | Synchronous |

Python, from the checkout or an installed local wheel:

```python
from engine import create_field

with create_field(64, 48) as world:
    world.set_cell(20, 10, 2, thermal=25)  # Water.
    world.step(16)
    print(world.energy_balance().drift_q)  # 0

    saved = world.snapshot().to_dict()
    world.restore(saved)
```

JavaScript CPU, after installing the local npm package in your project:

```javascript
import { createStateSpaceField, MAT } from 'state-space-engine';

const world = createStateSpaceField(64, 48, MAT.AIR);
world.setCell(20, 10, MAT.WATER, 25);
world.step(16);
console.log(world.energyBalance().driftQ); // 0n

const saved = world.packedSnapshot();
world.restore(saved);
world.close();
```

For browser GPU execution, use `await createGpuField(width, height)` and
`await world.step(ticks)`. Await each step before editing, sampling, saving, or
closing that field. Request pass reports with Python `inspect=True` or JavaScript
`{ inspect: true }` when debugging; inspection adds synchronization and memory
costs.

The [SDK guide](docs/SDK.md) covers local wheel/npm packaging, browser imports,
custom registries, and complete installed-client examples. Packages are currently
built and installed locally; this repository does not publish them automatically
to a package registry.

## Model and documentation

State Space uses uncalibrated cellular units. Movement exchanges cells, and the
structural model resolves support, damage, and translation of bonded fragments.
Continuum fluid pressure, momentum, elasticity, and structural rotation are not
implemented. Material extensions configure existing rules; new physical laws
require engine changes.

Pressure in 0.4 is a cellular approximation: connected gas temperature and liquid
depth set a bounded target; persistent pressure loads walls and drives quantized
flow. Thermal/latent/chemical energy remains exact. Mechanical energy and momentum
are outside that conservation guarantee. Schema 4 / `ca-v4` snapshots reject older
versions rather than silently applying new physics to old saves.

- [Capabilities and limitations](docs/CAPABILITIES.md)
- [State, energy, and snapshot contract](ENGINE_CONTRACT.md)
- [Structural model and diagnostics](docs/STRUCTURES.md)
- [Pressure, velocity, and failure model](docs/PRESSURE.md)
- [Evolution acceptance and benchmark protocol](docs/EVOLUTION.md)
- [Roadmap and checkpoint history](ENGINE_ROADMAP.md)

The repository also includes [Element Fighter](game/README.md) and
[Relic Line](tower-defense-rogue/README.md), two Phaser/Vite game prototypes with
their own gameplay simulations and engine snapshot integrations.

## Verify the engine

After the root dependency installation above, install the game dependencies:

```powershell
npm --prefix game ci
npm --prefix tower-defense-rogue ci
```

With `agent-browser` on `PATH`, run the complete verification suite:

```powershell
uv run python -m engine.verify --report docs/checkpoints/local-verification.json
```

Alternatively, set `STATE_SPACE_BROWSER_CLI` to the browser tool's executable or
JavaScript launcher path. Full verification requires native GPU and hardware
WebGPU. It checks lint, properties, long scenarios, native/CPU/browser
conformance, installed SDK clients, the live lab, game regressions, adversarial
evolution checks, and benchmarks. Reports retain failures and source hashes.

The [pressure release verification](docs/checkpoints/pressure-release-verification.json)
covers 16 gates, including 35 conformance scenes and 4,416 per-pass comparisons.
Checkpoint evidence and content-addressed package artifacts are retained in Git;
generated evidence is collapsed by default in GitHub review.

## License

[MIT](LICENSE).
