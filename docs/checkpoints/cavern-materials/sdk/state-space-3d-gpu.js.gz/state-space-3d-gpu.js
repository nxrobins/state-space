const MATERIAL_CATALOG_HASH = "f5e8af40e58281e2e8b5d343fddbc849c1daecfa54d4a51ea10d4b3bf9ce5ce7";
const PHASE_SHIFT = 24;
const COLD_TABLE_STRIDE = 24;
const COLD_TABLE_ENTRIES = 256;
const COLD_DENSITY = 0;
const COLD_CONDUCTIVITY = 1;
const COLD_MELT_POINT = 2;
const COLD_BOIL_POINT = 3;
const COLD_FREEZE_POINT = 8;
const COLD_CONDENSE_POINT = 9;
const COLD_MELTS_INTO = 12;
const COLD_BOILS_INTO = 13;
const COLD_FREEZES_INTO = 14;
const COLD_CONDENSES_INTO = 15;
const COLD_FUEL_ENERGY = 16;
const COLD_PHASE_ENERGY = 19;
const COLD_DEFAULT_PHASE = 20;
const COLD_STRIDE = COLD_TABLE_STRIDE;
function freezeDefinition(value) {
  if (value !== null && typeof value === "object") {
    for (const child of Object.values(value)) freezeDefinition(child);
    Object.freeze(value);
  }
  return value;
}
const MAT = freezeDefinition({
  "AIR": 0,
  "STONE": 1,
  "WATER": 2,
  "SAND": 3,
  "FIRE": 4,
  "METAL": 5,
  "OIL": 6,
  "WOOD": 7,
  "ICE": 8,
  "STEAM": 9,
  "LAVA": 10,
  "GLASS": 11,
  "PLAYER": 12,
  "ASH": 13,
  "SMOKE": 14,
  "OIL_VAPOR": 15,
  "MOLTEN_METAL": 16,
  "MOLTEN_GLASS": 17
});
const PHASE = freezeDefinition({
  "SOLID": 0,
  "POWDER": 1,
  "LIQUID": 2,
  "VISCOUS": 3,
  "GAS": 4,
  "PLASMA": 5,
  "FROZEN": 6,
  "MOLTEN": 7,
  "BURNING": 8,
  "CONDENSING": 9,
  "EVAPORATING": 10,
  "SUBLIMATING": 11
});
freezeDefinition({
  "BURNING": 1,
  "CONDUCTING": 2,
  "PRESSURIZED": 4,
  "PLAYER_OWNED": 8
});
freezeDefinition({
  "0": "air",
  "1": "stone",
  "2": "water",
  "3": "sand",
  "4": "fire",
  "5": "metal",
  "6": "oil",
  "7": "wood",
  "8": "ice",
  "9": "steam",
  "10": "lava",
  "11": "glass",
  "12": "player",
  "13": "ash",
  "14": "smoke",
  "15": "oil_vapor",
  "16": "molten_metal",
  "17": "molten_glass"
});
freezeDefinition({
  "0": "#0d0d14",
  "1": "#808080",
  "2": "#2659cc",
  "3": "#c2b280",
  "4": "#ff6610",
  "5": "#b3b8bf",
  "6": "#331f0d",
  "7": "#8c5926",
  "8": "#bfe6f2",
  "9": "#d9d9e6",
  "10": "#ff4d00",
  "11": "#b3d9e6",
  "12": "#33cc66",
  "13": "#4d4740",
  "14": "#66666b",
  "15": "#b4a178",
  "16": "#ffb665",
  "17": "#f6d5aa"
});
freezeDefinition({
  "0": 4,
  "1": 0,
  "2": 2,
  "3": 1,
  "4": 4,
  "5": 0,
  "6": 3,
  "7": 0,
  "8": 6,
  "9": 4,
  "10": 3,
  "11": 0,
  "12": 0,
  "13": 1,
  "14": 4,
  "15": 4,
  "16": 7,
  "17": 7
});
freezeDefinition({
  "0": 20,
  "1": 20,
  "2": 25,
  "3": 20,
  "4": 255,
  "5": 20,
  "6": 22,
  "7": 20,
  "8": 5,
  "9": 120,
  "10": 250,
  "11": 20,
  "12": 20,
  "13": 30,
  "14": 40,
  "15": 120,
  "16": 250,
  "17": 250
});
const COLD_ROWS = freezeDefinition([
  [
    0,
    1,
    5,
    0,
    0,
    0,
    0,
    255,
    3704094720,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    4,
    1,
    0,
    0
  ],
  [
    1,
    200,
    30,
    220,
    255,
    0,
    0,
    0,
    2155872456,
    210,
    0,
    30,
    0,
    10,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    200,
    180
  ],
  [
    2,
    100,
    60,
    0,
    100,
    0,
    0,
    0,
    2151677982,
    15,
    90,
    0,
    40,
    0,
    9,
    8,
    0,
    0,
    0,
    0,
    15,
    2,
    0,
    0,
    0
  ],
  [
    3,
    180,
    20,
    200,
    255,
    0,
    0,
    150,
    2999058612,
    0,
    0,
    25,
    0,
    11,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    0,
    0,
    0
  ],
  [
    4,
    0,
    255,
    0,
    0,
    0,
    255,
    255,
    1694497290,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    4,
    0,
    0,
    0
  ],
  [
    5,
    220,
    200,
    230,
    255,
    0,
    0,
    0,
    3031695580,
    220,
    0,
    35,
    0,
    16,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    255,
    185
  ],
  [
    6,
    90,
    10,
    0,
    80,
    120,
    200,
    0,
    505938070,
    0,
    70,
    0,
    30,
    0,
    15,
    0,
    0,
    150,
    14,
    4,
    0,
    3,
    0,
    0,
    0
  ],
  [
    7,
    120,
    15,
    0,
    0,
    180,
    150,
    30,
    1519059104,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    80,
    13,
    4,
    0,
    0,
    0,
    24,
    120
  ],
  [
    8,
    100,
    40,
    30,
    100,
    0,
    0,
    0,
    3871866900,
    0,
    0,
    15,
    0,
    2,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    6,
    0,
    12,
    12
  ],
  [
    9,
    5,
    50,
    0,
    0,
    0,
    0,
    255,
    3705410565,
    0,
    90,
    0,
    0,
    0,
    0,
    0,
    2,
    0,
    0,
    0,
    55,
    4,
    0,
    0,
    0
  ],
  [
    10,
    210,
    150,
    0,
    255,
    0,
    50,
    0,
    1358947940,
    210,
    0,
    0,
    0,
    0,
    0,
    1,
    0,
    0,
    0,
    0,
    30,
    3,
    0,
    0,
    0
  ],
  [
    11,
    170,
    25,
    240,
    255,
    0,
    0,
    0,
    3704094730,
    235,
    0,
    30,
    0,
    17,
    0,
    0,
    0,
    0,
    0,
    0,
    25,
    0,
    0,
    48,
    190
  ],
  [
    12,
    100,
    30,
    0,
    0,
    0,
    0,
    0,
    3362004530,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    32,
    0
  ],
  [
    13,
    150,
    10,
    0,
    0,
    0,
    0,
    100,
    1684275380,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    0,
    0,
    0
  ],
  [
    14,
    3,
    30,
    0,
    0,
    0,
    0,
    255,
    1684277840,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    4,
    0,
    0,
    0
  ],
  [
    15,
    2,
    30,
    0,
    0,
    120,
    200,
    0,
    505938070,
    0,
    70,
    0,
    0,
    0,
    0,
    0,
    6,
    150,
    14,
    4,
    30,
    4,
    0,
    0,
    0
  ],
  [
    16,
    220,
    200,
    0,
    0,
    0,
    0,
    0,
    3031695580,
    220,
    0,
    0,
    0,
    0,
    0,
    5,
    0,
    0,
    0,
    0,
    35,
    7,
    0,
    0,
    0
  ],
  [
    17,
    170,
    40,
    0,
    0,
    0,
    0,
    0,
    3704094730,
    235,
    0,
    0,
    0,
    0,
    0,
    11,
    0,
    0,
    0,
    0,
    55,
    7,
    0,
    0,
    0
  ]
]);
const DEFAULT_CATALOG = freezeDefinition({
  "schema_version": 4,
  "cold_stride": 24,
  "capacity": 256,
  "bit_fields": {
    "material": {
      "shift": 0,
      "bits": 8,
      "signed": false
    },
    "thermal": {
      "shift": 8,
      "bits": 8,
      "signed": false
    },
    "kinetic_x": {
      "shift": 16,
      "bits": 4,
      "signed": true
    },
    "kinetic_y": {
      "shift": 20,
      "bits": 4,
      "signed": true
    },
    "phase": {
      "shift": 24,
      "bits": 4,
      "signed": false
    },
    "flags": {
      "shift": 28,
      "bits": 4,
      "signed": false
    }
  },
  "phases": {
    "SOLID": 0,
    "POWDER": 1,
    "LIQUID": 2,
    "VISCOUS": 3,
    "GAS": 4,
    "PLASMA": 5,
    "FROZEN": 6,
    "MOLTEN": 7,
    "BURNING": 8,
    "CONDENSING": 9,
    "EVAPORATING": 10,
    "SUBLIMATING": 11
  },
  "flags": {
    "BURNING": 1,
    "CONDUCTING": 2,
    "PRESSURIZED": 4,
    "PLAYER_OWNED": 8
  },
  "cold_fields": [
    "density",
    "conductivity",
    "melt_point",
    "boil_point",
    "flash_point",
    "reactivity",
    "porosity",
    "optical",
    "freeze_point",
    "condense_point",
    "latent_heat_melt",
    "latent_heat_boil",
    "melts_into",
    "boils_into",
    "freezes_into",
    "condenses_into",
    "fuel_energy",
    "burns_into",
    "smoke_product",
    "phase_energy",
    "default_phase",
    "oxidizer",
    "cohesion",
    "softening"
  ],
  "materials": [
    {
      "id": 0,
      "name": "air",
      "default_thermal": 20,
      "color": "#0d0d14",
      "properties": {
        "density": 1,
        "conductivity": 5,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 255,
        "optical": 3704094720,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 4,
        "oxidizer": 1,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 1,
      "name": "stone",
      "default_thermal": 20,
      "color": "#808080",
      "properties": {
        "density": 200,
        "conductivity": 30,
        "melt_point": 220,
        "boil_point": 255,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 2155872456,
        "freeze_point": 210,
        "condense_point": 0,
        "latent_heat_melt": 30,
        "latent_heat_boil": 0,
        "melts_into": 10,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 0,
        "oxidizer": 0,
        "cohesion": 200,
        "softening": 180
      }
    },
    {
      "id": 2,
      "name": "water",
      "default_thermal": 25,
      "color": "#2659cc",
      "properties": {
        "density": 100,
        "conductivity": 60,
        "melt_point": 0,
        "boil_point": 100,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 2151677982,
        "freeze_point": 15,
        "condense_point": 90,
        "latent_heat_melt": 0,
        "latent_heat_boil": 40,
        "melts_into": 0,
        "boils_into": 9,
        "freezes_into": 8,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 15,
        "default_phase": 2,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 3,
      "name": "sand",
      "default_thermal": 20,
      "color": "#c2b280",
      "properties": {
        "density": 180,
        "conductivity": 20,
        "melt_point": 200,
        "boil_point": 255,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 150,
        "optical": 2999058612,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 25,
        "latent_heat_boil": 0,
        "melts_into": 11,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 1,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 4,
      "name": "fire",
      "default_thermal": 255,
      "color": "#ff6610",
      "properties": {
        "density": 0,
        "conductivity": 255,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 255,
        "porosity": 255,
        "optical": 1694497290,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 4,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 5,
      "name": "metal",
      "default_thermal": 20,
      "color": "#b3b8bf",
      "properties": {
        "density": 220,
        "conductivity": 200,
        "melt_point": 230,
        "boil_point": 255,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3031695580,
        "freeze_point": 220,
        "condense_point": 0,
        "latent_heat_melt": 35,
        "latent_heat_boil": 0,
        "melts_into": 16,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 0,
        "oxidizer": 0,
        "cohesion": 255,
        "softening": 185
      }
    },
    {
      "id": 6,
      "name": "oil",
      "default_thermal": 22,
      "color": "#331f0d",
      "properties": {
        "density": 90,
        "conductivity": 10,
        "melt_point": 0,
        "boil_point": 80,
        "flash_point": 120,
        "reactivity": 200,
        "porosity": 0,
        "optical": 505938070,
        "freeze_point": 0,
        "condense_point": 70,
        "latent_heat_melt": 0,
        "latent_heat_boil": 30,
        "melts_into": 0,
        "boils_into": 15,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 150,
        "burns_into": 14,
        "smoke_product": 4,
        "phase_energy": 0,
        "default_phase": 3,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 7,
      "name": "wood",
      "default_thermal": 20,
      "color": "#8c5926",
      "properties": {
        "density": 120,
        "conductivity": 15,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 180,
        "reactivity": 150,
        "porosity": 30,
        "optical": 1519059104,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 80,
        "burns_into": 13,
        "smoke_product": 4,
        "phase_energy": 0,
        "default_phase": 0,
        "oxidizer": 0,
        "cohesion": 24,
        "softening": 120
      }
    },
    {
      "id": 8,
      "name": "ice",
      "default_thermal": 5,
      "color": "#bfe6f2",
      "properties": {
        "density": 100,
        "conductivity": 40,
        "melt_point": 30,
        "boil_point": 100,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3871866900,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 15,
        "latent_heat_boil": 0,
        "melts_into": 2,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 6,
        "oxidizer": 0,
        "cohesion": 12,
        "softening": 12
      }
    },
    {
      "id": 9,
      "name": "steam",
      "default_thermal": 120,
      "color": "#d9d9e6",
      "properties": {
        "density": 5,
        "conductivity": 50,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 255,
        "optical": 3705410565,
        "freeze_point": 0,
        "condense_point": 90,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 2,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 55,
        "default_phase": 4,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 10,
      "name": "lava",
      "default_thermal": 250,
      "color": "#ff4d00",
      "properties": {
        "density": 210,
        "conductivity": 150,
        "melt_point": 0,
        "boil_point": 255,
        "flash_point": 0,
        "reactivity": 50,
        "porosity": 0,
        "optical": 1358947940,
        "freeze_point": 210,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 1,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 30,
        "default_phase": 3,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 11,
      "name": "glass",
      "default_thermal": 20,
      "color": "#b3d9e6",
      "properties": {
        "density": 170,
        "conductivity": 25,
        "melt_point": 240,
        "boil_point": 255,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3704094730,
        "freeze_point": 235,
        "condense_point": 0,
        "latent_heat_melt": 30,
        "latent_heat_boil": 0,
        "melts_into": 17,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 25,
        "default_phase": 0,
        "oxidizer": 0,
        "cohesion": 48,
        "softening": 190
      }
    },
    {
      "id": 12,
      "name": "player",
      "default_thermal": 20,
      "color": "#33cc66",
      "properties": {
        "density": 100,
        "conductivity": 30,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3362004530,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 0,
        "oxidizer": 0,
        "cohesion": 32,
        "softening": 0
      }
    },
    {
      "id": 13,
      "name": "ash",
      "default_thermal": 30,
      "color": "#4d4740",
      "properties": {
        "density": 150,
        "conductivity": 10,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 100,
        "optical": 1684275380,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 1,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 14,
      "name": "smoke",
      "default_thermal": 40,
      "color": "#66666b",
      "properties": {
        "density": 3,
        "conductivity": 30,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 255,
        "optical": 1684277840,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 4,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 15,
      "name": "oil_vapor",
      "default_thermal": 120,
      "color": "#b4a178",
      "properties": {
        "density": 2,
        "conductivity": 30,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 120,
        "reactivity": 200,
        "porosity": 0,
        "optical": 505938070,
        "freeze_point": 0,
        "condense_point": 70,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 6,
        "fuel_energy": 150,
        "burns_into": 14,
        "smoke_product": 4,
        "phase_energy": 30,
        "default_phase": 4,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 16,
      "name": "molten_metal",
      "default_thermal": 250,
      "color": "#ffb665",
      "properties": {
        "density": 220,
        "conductivity": 200,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3031695580,
        "freeze_point": 220,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 5,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 35,
        "default_phase": 7,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 17,
      "name": "molten_glass",
      "default_thermal": 250,
      "color": "#f6d5aa",
      "properties": {
        "density": 170,
        "conductivity": 40,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3704094730,
        "freeze_point": 235,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 11,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 55,
        "default_phase": 7,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    }
  ],
  "structure_fields": {
    "integrity": {
      "shift": 0,
      "bits": 8
    },
    "bond_left": {
      "shift": 8,
      "bits": 1
    },
    "bond_right": {
      "shift": 9,
      "bits": 1
    },
    "bond_up": {
      "shift": 10,
      "bits": 1
    },
    "bond_down": {
      "shift": 11,
      "bits": 1
    },
    "anchor": {
      "shift": 12,
      "bits": 1
    },
    "fresh": {
      "shift": 13,
      "bits": 1
    },
    "moved": {
      "shift": 14,
      "bits": 1
    },
    "pressure": {
      "shift": 16,
      "bits": 16
    }
  }
});
function buildColdTable() {
  const buffer = new Uint32Array(COLD_TABLE_ENTRIES * COLD_STRIDE);
  for (const [id, ...props] of COLD_ROWS) buffer.set(props, id * COLD_STRIDE);
  return buffer;
}
const typedArrayName = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(Uint32Array.prototype), Symbol.toStringTag).get;
const typedArrayPrototype = Object.getPrototypeOf(Uint32Array.prototype);
Object.getOwnPropertyDescriptor(typedArrayPrototype, "length").get;
Object.getOwnPropertyDescriptor(typedArrayPrototype, "buffer").get;
Object.getOwnPropertyDescriptor(typedArrayPrototype, "byteOffset").get;
function checkedInteger(value, minimum, maximum, name) {
  if (!Number.isSafeInteger(value) || value < minimum || value > maximum) {
    throw new Error(`${name} must be an integer in [${minimum}, ${maximum}].`);
  }
  return value;
}
function validatePackedCells(values, length) {
  if (!values || values.length !== length) {
    throw new Error(`Engine snapshot cell length mismatch: expected ${length}, received ${values?.length}.`);
  }
  if (values instanceof Uint32Array && typedArrayName.call(values) === "Uint32Array") {
    const copy = new Uint32Array(values);
    if (copy.length !== length) throw new Error("Engine snapshot cell length mismatch.");
    return copy;
  }
  for (let index = 0; index < length; index += 1) {
    const value = values[index];
    if (!Number.isSafeInteger(value) || value < 0 || value > 4294967295) {
      checkedInteger(value, 0, 4294967295, `packedCells[${index}]`);
    }
  }
  return Uint32Array.from(values);
}
const sameKeys = (value, keys, label) => {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).length !== keys.length || keys.some((key) => !Object.hasOwn(value, key))) {
    throw new Error(`${label} has missing or unexpected fields.`);
  }
};
const integer = (value, min, max, label) => {
  if (typeof value !== "number") throw new Error(`${label} must be a number.`);
  checkedInteger(value, min, max, label);
};
function canonicalCatalog(catalog) {
  const stable = (value) => {
    if (Array.isArray(value)) return `[${value.map(stable).join(",")}]`;
    if (value && typeof value === "object") {
      return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stable(value[key])}`).join(",")}}`;
    }
    return JSON.stringify(value);
  };
  return stable({ ...catalog, materials: [...catalog.materials].sort((a, b) => a.id - b.id) });
}
function validateCatalog(value) {
  sameKeys(value, Object.keys(DEFAULT_CATALOG), "Catalog");
  const catalog = value;
  integer(catalog.schema_version, 4, 4, "schema_version");
  integer(catalog.capacity, 256, 256, "capacity");
  integer(catalog.cold_stride, 24, 24, "cold_stride");
  sameKeys(catalog.structure_fields, Object.keys(DEFAULT_CATALOG.structure_fields), "structure_fields");
  for (const [name, expected] of Object.entries(DEFAULT_CATALOG.structure_fields)) {
    const field = catalog.structure_fields[name];
    sameKeys(field, ["shift", "bits"], `structure_fields.${name}`);
    integer(field.shift, expected.shift, expected.shift, `${name}.shift`);
    integer(field.bits, expected.bits, expected.bits, `${name}.bits`);
  }
  sameKeys(catalog.bit_fields, Object.keys(DEFAULT_CATALOG.bit_fields), "bit_fields");
  for (const [name, expected] of Object.entries(DEFAULT_CATALOG.bit_fields)) {
    const field = catalog.bit_fields[name];
    sameKeys(field, ["shift", "bits", "signed"], `bit_fields.${name}`);
    if (field.shift !== expected.shift || field.bits !== expected.bits || field.signed !== expected.signed) throw new Error("Packed layout requires a new schema version.");
  }
  for (const [label, table] of [["phases", catalog.phases], ["flags", catalog.flags]]) {
    if (!table || typeof table !== "object" || Array.isArray(table)) throw new Error(`Invalid ${label}.`);
    const values = /* @__PURE__ */ new Set();
    for (const [name, id] of Object.entries(table)) {
      if (!/^[A-Z][A-Z_0-9]*$/.test(name)) throw new Error(`Invalid ${label} symbol.`);
      integer(id, label === "phases" ? 0 : 1, 15, name);
      if (values.has(id) || label === "flags" && (id & id - 1) !== 0) throw new Error(`Invalid ${label} value.`);
      values.add(id);
    }
    for (const [name, id] of Object.entries(DEFAULT_CATALOG[label])) {
      if (table[name] !== id) throw new Error(`Changing existing ${label} requires a new schema version.`);
    }
    if (label === "flags" && Object.keys(table).length !== Object.keys(DEFAULT_CATALOG.flags).length) throw new Error("Invalid flags.");
  }
  if (!Array.isArray(catalog.cold_fields) || catalog.cold_fields.length !== DEFAULT_CATALOG.cold_fields.length || Array.from(catalog.cold_fields).some((name, i) => name !== DEFAULT_CATALOG.cold_fields[i])) throw new Error("Cold table offsets require a new schema version.");
  if (!Array.isArray(catalog.materials) || !catalog.materials.length) throw new Error("materials must be a nonempty array.");
  const records = /* @__PURE__ */ new Map(), names = /* @__PURE__ */ new Set();
  for (const record of catalog.materials) {
    sameKeys(record, ["id", "name", "default_thermal", "color", "properties"], "Material");
    integer(record.id, 0, 255, "material.id");
    if (typeof record.name !== "string" || !/^[a-z][a-z_0-9]*$/.test(record.name)) throw new Error("Invalid material name.");
    if (records.has(record.id) || names.has(record.name)) throw new Error("Duplicate material ID or name.");
    if (typeof record.color !== "string" || !/^#[0-9a-fA-F]{6}$/.test(record.color)) throw new Error("Invalid material color.");
    integer(record.default_thermal, 0, 255, "default_thermal");
    sameKeys(record.properties, catalog.cold_fields, "Material properties");
    for (const [name, property] of Object.entries(record.properties)) integer(property, 0, name === "optical" ? 4294967295 : 255, name);
    if (!Object.values(catalog.phases).includes(record.properties.default_phase)) throw new Error("Undefined default phase.");
    if (![0, 1].includes(record.properties.oxidizer)) throw new Error("oxidizer must be 0 or 1.");
    if (record.properties.softening && !record.properties.cohesion) throw new Error("Softening requires nonzero cohesion.");
    records.set(record.id, record);
    names.add(record.name);
  }
  for (const builtin2 of DEFAULT_CATALOG.materials) {
    if (records.get(builtin2.id)?.name !== builtin2.name) throw new Error("Changing existing material IDs requires a new schema version.");
  }
  const up = (p) => [p.boils_into || p.melts_into, p.boils_into ? p.boil_point : p.melt_point];
  const down = (p) => [p.freezes_into || p.condenses_into, p.freezes_into ? p.freeze_point : p.condense_point];
  for (const record of records.values()) {
    const p = record.properties;
    for (const name of ["melts_into", "boils_into", "freezes_into", "condenses_into", "burns_into", "smoke_product"]) {
      if (!records.has(p[name])) throw new Error(`Undefined target ${record.name}.${name}.`);
    }
    for (const [threshold, target] of [["melt_point", "melts_into"], ["boil_point", "boils_into"], ["freeze_point", "freezes_into"], ["condense_point", "condenses_into"]]) {
      if (p[target] && !p[threshold]) throw new Error("Transition target requires a threshold.");
    }
    if (p.melts_into && p.boils_into || p.freezes_into && p.condenses_into) throw new Error("Only one upward and downward phase interval is supported.");
    if (p.fuel_energy && (!p.flash_point || !p.burns_into || !p.smoke_product)) throw new Error("Incomplete combustion definition.");
    if (p.oxidizer && (p.fuel_energy || p.phase_energy)) throw new Error("Oxidizer must have zero chemical and phase offsets.");
    const upward = up(p), downward = down(p);
    if (upward[0] && downward[0] && downward[1] >= upward[1]) throw new Error("Material phase intervals overlap.");
    for (const [transition, direction] of [[upward, 1], [downward, -1]]) {
      const [id, threshold] = transition;
      if (!id) continue;
      const target = records.get(id).properties;
      const difference = target.phase_energy - p.phase_energy;
      if (difference * direction <= 0) throw new Error("Phase energy must change monotonically.");
      if (direction > 0 && difference !== p[p.boils_into ? "latent_heat_boil" : "latent_heat_melt"]) throw new Error("Declared latent heat must equal the phase energy difference.");
      if (target.fuel_energy !== p.fuel_energy || target.oxidizer !== p.oxidizer) throw new Error("Phase changes must preserve chemical and oxidizer identity.");
      const reverse = direction > 0 ? down(target) : up(target);
      if (reverse[0] && (reverse[0] !== record.id || (direction > 0 ? reverse[1] >= threshold : threshold >= reverse[1]))) {
        throw new Error("Reverse phase edges require original identity and positive hysteresis.");
      }
    }
    if (p.fuel_energy) {
      for (const id of [p.burns_into, p.smoke_product]) {
        const product = records.get(id).properties;
        if (product.fuel_energy || product.oxidizer || product.phase_energy) throw new Error("Combustion products must be inert with zero phase offset.");
      }
    }
  }
}
const registries = /* @__PURE__ */ new WeakSet();
class ValidatedRegistry {
  hash;
  materialIds;
  #catalog;
  #records;
  #cold;
  constructor(catalog, hash) {
    this.hash = hash;
    this.#catalog = catalog;
    this.#records = new Map(catalog.materials.map((record) => [record.id, record]));
    this.materialIds = Object.freeze([...this.#records.keys()].sort((a, b) => a - b));
    this.#cold = new Uint32Array(catalog.capacity * catalog.cold_stride);
    for (const record of catalog.materials) {
      this.#cold.set(catalog.cold_fields.map((name) => record.properties[name]), record.id * catalog.cold_stride);
      Object.freeze(record.properties);
      Object.freeze(record);
    }
    registries.add(this);
    Object.freeze(this);
  }
  has(material2) {
    return this.#records.has(material2);
  }
  material(material2) {
    integer(material2, 0, 255, "material");
    const record = this.#records.get(material2);
    if (!record) throw new Error(`Undefined material: ${material2}`);
    return record;
  }
  toCatalog() {
    return structuredClone(this.#catalog);
  }
  coldTable() {
    return this.#cold.slice();
  }
  extend(materials) {
    return createMaterialRegistry({ ...this.toCatalog(), materials: [...this.toCatalog().materials, ...materials] });
  }
}
const builtin = structuredClone(DEFAULT_CATALOG);
validateCatalog(builtin);
const DEFAULT_REGISTRY = new ValidatedRegistry(builtin, MATERIAL_CATALOG_HASH);
async function createMaterialRegistry(value) {
  const catalog = structuredClone(value);
  validateCatalog(catalog);
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(canonicalCatalog(catalog)));
  const hash = Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
  return new ValidatedRegistry(catalog, hash);
}
const ENERGY_SCALE = 256;
const MAX_ENERGY_Q = 1073741823;
const prop = (v, cold2, field) => cold2[(v & 255) * COLD_STRIDE + field];
function temperatureQ(voxel, energy, cold2) {
  const heat = energy - prop(voxel, cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE;
  const phase2 = prop(voxel, cold2, COLD_PHASE_ENERGY) * ENERGY_SCALE;
  let temperature = Math.max(0, heat - phase2);
  const boil = prop(voxel, cold2, COLD_BOILS_INTO);
  const up = boil || prop(voxel, cold2, COLD_MELTS_INTO);
  const upTemperature = prop(voxel, cold2, boil ? COLD_BOIL_POINT : COLD_MELT_POINT) * ENERGY_SCALE;
  const freeze = prop(voxel, cold2, COLD_FREEZES_INTO);
  const down = freeze || prop(voxel, cold2, COLD_CONDENSES_INTO);
  const downTemperature = prop(voxel, cold2, freeze ? COLD_FREEZE_POINT : COLD_CONDENSE_POINT) * ENERGY_SCALE;
  if (up && heat >= phase2 + upTemperature) {
    temperature = Math.max(upTemperature, heat - prop(up, cold2, COLD_PHASE_ENERGY) * ENERGY_SCALE);
  } else if (down && heat <= phase2 + downTemperature) {
    temperature = Math.min(downTemperature, Math.max(0, heat - prop(down, cold2, COLD_PHASE_ENERGY) * ENERGY_SCALE));
  }
  return temperature;
}
function thermalView(voxel, energy, cold2) {
  return (voxel & 4294902015 | Math.min(255, Math.floor(temperatureQ(voxel, energy, cold2) / ENERGY_SCALE)) << 8) >>> 0;
}
function seedState(values, cold2 = buildColdTable(), registry = DEFAULT_REGISTRY) {
  const grid = validatePackedCells(values, values.length);
  const energyQ = new Uint32Array(grid.length);
  for (let i = 0; i < grid.length; i += 1) {
    const v = grid[i];
    if (!registry.has(v & 255)) throw new Error("Undefined material in initial state.");
    energyQ[i] = ((v >>> 8 & 255) + prop(v, cold2, COLD_PHASE_ENERGY) + prop(v, cold2, COLD_FUEL_ENERGY)) * ENERGY_SCALE;
    grid[i] = thermalView(v, energyQ[i], cold2);
  }
  return { grid, energyQ };
}
function validateEnergyState(cells, energies, length, cold2 = buildColdTable(), registry = DEFAULT_REGISTRY) {
  const grid = validatePackedCells(cells, length);
  const energyQ = validatePackedCells(energies, length);
  for (let i = 0; i < length; i += 1) {
    const v = grid[i];
    if (!registry.has(v & 255)) throw new Error("Undefined material in simulation state.");
    const minimum = prop(v, cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE;
    if (energyQ[i] < minimum || energyQ[i] > MAX_ENERGY_Q) checkedInteger(energyQ[i], minimum, MAX_ENERGY_Q, `energyQ[${i}]`);
    if (thermalView(v, energyQ[i], cold2) !== v) throw new Error("Packed thermal view disagrees with conserved energy.");
  }
  return { grid, energyQ };
}
function exchangeEnergy(a, b, ea, eb, cold2) {
  const ta = temperatureQ(a, ea, cold2), tb = temperatureQ(b, eb, cold2);
  const ca = prop(a, cold2, COLD_CONDUCTIVITY), cb = prop(b, cold2, COLD_CONDUCTIVITY);
  const k = ca + cb ? Math.floor(2 * ca * cb / (ca + cb)) : 0;
  const difference = Math.abs(ta - tb);
  let flux = Math.floor(difference / 512) * k + Math.floor((difference % 512 * k + 511) / 512);
  flux = Math.min(flux, Math.floor(difference / 2));
  if (ta > tb) {
    flux = Math.min(flux, ea - prop(a, cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE, MAX_ENERGY_Q - eb);
    return [ea - flux, eb + flux];
  }
  flux = Math.min(flux, eb - prop(b, cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE, MAX_ENERGY_Q - ea);
  return [ea + flux, eb - flux];
}
function phaseMaterial(v, energy, cold2) {
  const chemical = prop(v, cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE;
  const boil = prop(v, cold2, COLD_BOILS_INTO);
  const up = boil || prop(v, cold2, COLD_MELTS_INTO);
  if (up) {
    const boundary = chemical + (prop(up, cold2, COLD_PHASE_ENERGY) + prop(v, cold2, boil ? COLD_BOIL_POINT : COLD_MELT_POINT)) * ENERGY_SCALE;
    if (energy >= boundary) return up;
  }
  const freeze = prop(v, cold2, COLD_FREEZES_INTO);
  const down = freeze || prop(v, cold2, COLD_CONDENSES_INTO);
  if (down) {
    const boundary = chemical + (prop(down, cold2, COLD_PHASE_ENERGY) + prop(v, cold2, freeze ? COLD_FREEZE_POINT : COLD_CONDENSE_POINT)) * ENERGY_SCALE;
    if (energy <= boundary) return down;
  }
  return v & 255;
}
function rewriteMaterial(voxel, material2, energy, cold2) {
  const packed = (voxel & 4043243520 | material2 | prop(material2, cold2, COLD_DEFAULT_PHASE) << PHASE_SHIFT) >>> 0;
  return thermalView(packed, energy, cold2);
}
function energyLedger(state, cold2 = buildColdTable()) {
  let sensibleQ = 0n, latentQ = 0n, chemicalQ = 0n;
  for (let i = 0; i < state.grid.length; i += 1) {
    const chemical = prop(state.grid[i], cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE;
    const sensible = temperatureQ(state.grid[i], state.energyQ[i], cold2);
    sensibleQ += BigInt(sensible);
    chemicalQ += BigInt(chemical);
    latentQ += BigInt(state.energyQ[i] - chemical - sensible);
  }
  return { sensibleQ, latentQ, chemicalQ, totalQ: sensibleQ + latentQ + chemicalQ };
}
const SCHEMA_VERSION_3D = 1;
const RULES_VERSION_3D = "ca-3d-m1";
const MAX_CELLS_3D = 32768;
const MATERIAL_CATALOG_HASH_3D = DEFAULT_REGISTRY.hash;
const cold = buildColdTable();
const arrayPrototype = Object.getPrototypeOf(Uint32Array.prototype);
const arrayLength = Object.getOwnPropertyDescriptor(arrayPrototype, "length").get;
const arrayBuffer = Object.getOwnPropertyDescriptor(arrayPrototype, "buffer").get;
const arrayOffset = Object.getOwnPropertyDescriptor(arrayPrototype, "byteOffset").get;
const arrayName = Object.getOwnPropertyDescriptor(arrayPrototype, Symbol.toStringTag).get;
const MATERIALS_3D = Object.freeze([
  MAT.AIR,
  MAT.STONE,
  MAT.SAND,
  MAT.WATER,
  MAT.ICE,
  MAT.STEAM,
  MAT.LAVA,
  MAT.GLASS,
  MAT.MOLTEN_GLASS
].map((id) => DEFAULT_REGISTRY.material(id)));
const supported = new Set(MATERIALS_3D.map((m) => m.id));
const material = (v) => v & 255;
const phase = (v) => v >>> PHASE_SHIFT & 15;
const fixed = (v) => phase(v) === PHASE.SOLID || phase(v) === PHASE.FROZEN;
const liquid = (v) => phase(v) === PHASE.LIQUID || phase(v) === PHASE.VISCOUS || phase(v) === PHASE.MOLTEN;
const falling = (v) => phase(v) === PHASE.POWDER || liquid(v);
const gas = (v) => phase(v) === PHASE.GAS;
const density = (v) => cold[material(v) * COLD_STRIDE + COLD_DENSITY];
function dimensions(w, h, d, maximum = MAX_CELLS_3D) {
  for (const [key, value] of [["width", w], ["height", h], ["depth", d]]) checkedInteger(value, 1, maximum, key);
  return checkedInteger(w * h * d, 1, maximum, "volume cell count");
}
function requireMaterial(id) {
  checkedInteger(id, 0, 255, "material");
  if (!supported.has(id)) throw new Error("Material is not supported by ca-3d-m1.");
}
function placement(id, thermal) {
  requireMaterial(id);
  const record = DEFAULT_REGISTRY.material(id);
  checkedInteger(thermal ?? record.default_thermal, 0, 255, "thermal");
  return seedState([id | (thermal ?? record.default_thermal) << 8 | record.properties.default_phase << PHASE_SHIFT]);
}
function validateState(cells, energies, count) {
  const state = validateEnergyState(cells, energies, count);
  for (const v of state.grid) {
    requireMaterial(material(v));
    if ((v & 4043243520) !== 0 || phase(v) !== DEFAULT_REGISTRY.material(material(v)).properties.default_phase) {
      throw new Error("3D M1 requires the material default phase and zero velocity/flags.");
    }
  }
  return state;
}
function validateVolumeSnapshot$1(value, maximum = MAX_CELLS_3D) {
  const keys = ["schemaVersion", "rulesVersion", "materialCatalogHash", "width", "height", "depth", "tick", "packedCells", "energyQ"];
  if (!value || typeof value !== "object" || Object.keys(value).length !== keys.length || keys.some((k) => !Object.hasOwn(value, k))) {
    throw new Error("3D snapshot contains missing or unexpected fields.");
  }
  if (value.schemaVersion !== SCHEMA_VERSION_3D || value.rulesVersion !== RULES_VERSION_3D || value.materialCatalogHash !== MATERIAL_CATALOG_HASH_3D) {
    throw new Error("Incompatible 3D snapshot version or catalog.");
  }
  checkedInteger(value.tick, 0, Number.MAX_SAFE_INTEGER, "tick");
  return validateState(value.packedCells, value.energyQ, dimensions(value.width, value.height, value.depth, maximum));
}
function choice(index, axis, tick) {
  let h = Math.imul(index, 374761393) + Math.imul(axis, 668265263) + Math.imul(tick >>> 0, 1442695041) >>> 0;
  h = Math.imul(h ^ h >>> 13, 1274126177) >>> 0;
  return ((h ^ h >>> 16) & 1) === 0;
}
function volumeSchedule(tick) {
  checkedInteger(tick, 0, Number.MAX_SAFE_INTEGER, "tick");
  const passes = [];
  const pairs = (kind, axis, direction = 1) => {
    for (const parity of [0, 1]) passes.push({ kind, axis, parity, direction });
  };
  pairs("gravity", 1);
  const directions = [[0, 1], [0, -1], [2, 1], [2, -1]];
  for (let k = 0; k < 4; k++) {
    const [axis, direction] = directions[(k + tick % 4) % 4];
    pairs("diagonal", axis, direction);
  }
  const axes = tick % 2 ? [2, 0] : [0, 2];
  for (const axis of axes) pairs("liquid", axis);
  pairs("buoyancy", 1);
  for (const axis of axes) pairs("gas", axis);
  for (const axis of [0, 1, 2]) pairs("heat", axis);
  passes.push({ kind: "phase", axis: 0, parity: 0, direction: 1 });
  return passes;
}
function executePass(input, output, w, h, d, tick, pass) {
  const aGrid = input.grid, aEnergy = input.energyQ, bGrid = output.grid, bEnergy = output.energyQ;
  bGrid.set(aGrid);
  bEnergy.set(aEnergy);
  const layer = w * h;
  const bound = (index) => fixed(aGrid[index]);
  const canFall = (source, target) => falling(aGrid[source]) && !bound(source) && !bound(target) && density(aGrid[source]) > density(aGrid[target]);
  const gasRank = (i) => Math.floor(temperatureQ(aGrid[i], aEnergy[i], cold) / 256) * 2 - density(aGrid[i]);
  const canRise = (s, t) => material(aGrid[s]) !== MAT.AIR && gas(aGrid[s]) && gas(aGrid[t]) && gasRank(s) > gasRank(t) + 16;
  const swap = (s, t) => {
    bGrid[s] = aGrid[t];
    bGrid[t] = aGrid[s];
    bEnergy[s] = aEnergy[t];
    bEnergy[t] = aEnergy[s];
  };
  const hasFall = (i, x, y, z) => y + 1 < h && (canFall(i, i + w) || x > 0 && canFall(i, i + w - 1) || x + 1 < w && canFall(i, i + w + 1) || z > 0 && canFall(i, i + w - layer) || z + 1 < d && canFall(i, i + w + layer));
  if (pass.kind === "phase") {
    for (let i = 0; i < aGrid.length; i++) {
      const next = phaseMaterial(aGrid[i], aEnergy[i], cold);
      if (next !== material(aGrid[i])) bGrid[i] = rewriteMaterial(aGrid[i], next, aEnergy[i], cold);
    }
    return;
  }
  const vertical = ["gravity", "diagonal", "buoyancy"].includes(pass.kind);
  const pairAxis = vertical ? 1 : pass.axis;
  for (let z = pairAxis === 2 ? pass.parity : 0; z < d; z += pairAxis === 2 ? 2 : 1) {
    for (let y = pairAxis === 1 ? pass.parity : 0; y < h; y += pairAxis === 1 ? 2 : 1) {
      for (let x = pairAxis === 0 ? pass.parity : 0; x < w; x += pairAxis === 0 ? 2 : 1) {
        let tx = x + (pairAxis === 0 ? 1 : 0), ty = y + (pairAxis === 1 ? 1 : 0), tz = z + (pairAxis === 2 ? 1 : 0);
        if (pass.kind === "diagonal") {
          tx += pass.axis === 0 ? pass.direction : 0;
          tz += pass.axis === 2 ? pass.direction : 0;
        }
        if (tx < 0 || tx >= w || ty >= h || tz < 0 || tz >= d) continue;
        const a = x + w * (y + h * z), b = tx + w * (ty + h * tz);
        if (pass.kind === "gravity") {
          if (canFall(a, b)) swap(a, b);
        } else if (pass.kind === "diagonal") {
          if (!canFall(a, a + w) && canFall(a, b)) swap(a, b);
        } else if (pass.kind === "buoyancy") {
          if (canRise(b, a)) swap(a, b);
        } else if (pass.kind === "liquid") {
          const spread = (s, t) => liquid(aGrid[s]) && gas(aGrid[t]) && density(aGrid[s]) > density(aGrid[t]);
          if (spread(a, b) && !hasFall(a, x, y, z) || spread(b, a) && !hasFall(b, tx, ty, tz)) swap(a, b);
        } else if (pass.kind === "gas") {
          const [s, t, sy] = choice(a, pass.axis, tick) ? [a, b, y] : [b, a, ty];
          if (material(aGrid[s]) !== MAT.AIR && gas(aGrid[s]) && gas(aGrid[t]) && (sy === 0 || !canRise(s, s - w)) && (material(aGrid[t]) === MAT.AIR || gasRank(s) > gasRank(t) + 16)) swap(s, t);
        } else if (pass.kind === "heat") {
          if (material(aGrid[a]) === material(aGrid[b]) && aEnergy[a] === aEnergy[b]) continue;
          [bEnergy[a], bEnergy[b]] = exchangeEnergy(aGrid[a], aGrid[b], aEnergy[a], aEnergy[b], cold);
          bGrid[a] = thermalView(aGrid[a], bEnergy[a], cold);
          bGrid[b] = thermalView(aGrid[b], bEnergy[b], cold);
        }
      }
    }
  }
}
class CpuVolume {
  width;
  height;
  depth;
  #state;
  #spare;
  #tick = 0;
  #initial = 0n;
  #external = 0n;
  #maximum;
  constructor(w, h, d, fill, maximum = MAX_CELLS_3D) {
    const count = dimensions(w, h, d, maximum), seed = placement(fill);
    this.#maximum = maximum;
    this.width = w;
    this.height = h;
    this.depth = d;
    for (const key of ["width", "height", "depth"]) Object.defineProperty(this, key, { writable: false, configurable: false });
    this.#state = { grid: new Uint32Array(count).fill(seed.grid[0]), energyQ: new Uint32Array(count).fill(seed.energyQ[0]) };
    this.#spare = { grid: new Uint32Array(count), energyQ: new Uint32Array(count) };
    this.#initial = this.#total();
  }
  get tick() {
    return this.#tick;
  }
  get grid() {
    return this.#state.grid.slice();
  }
  get energyQ() {
    return this.#state.energyQ.slice();
  }
  #total() {
    let sum = 0;
    for (const q of this.#state.energyQ) sum += q;
    return BigInt(sum);
  }
  #index(x, y, z) {
    checkedInteger(x, 0, this.width - 1, "x");
    checkedInteger(y, 0, this.height - 1, "y");
    checkedInteger(z, 0, this.depth - 1, "z");
    return x + this.width * (y + this.height * z);
  }
  step(ticks = 1) {
    checkedInteger(ticks, 0, 1024, "ticks per request");
    checkedInteger(this.#tick + ticks, 0, Number.MAX_SAFE_INTEGER, "end tick");
    for (let n = 0; n < ticks; n++) {
      for (const pass of volumeSchedule(this.#tick)) {
        executePass(this.#state, this.#spare, this.width, this.height, this.depth, this.#tick, pass);
        [this.#state, this.#spare] = [this.#spare, this.#state];
      }
      this.#tick++;
    }
  }
  sample(x, y, z) {
    const i = this.#index(x, y, z), v = this.#state.grid[i], energyQ = this.#state.energyQ[i];
    return {
      material: material(v),
      materialName: DEFAULT_REGISTRY.material(material(v)).name,
      phase: phase(v),
      thermal: v >>> 8 & 255,
      temperatureQ: temperatureQ(v, energyQ, cold),
      energyQ
    };
  }
  setCell(x, y, z, id, thermal) {
    const i = this.#index(x, y, z), seed = placement(id, thermal);
    this.#external += BigInt(seed.energyQ[0]) - BigInt(this.#state.energyQ[i]);
    this.#state.grid[i] = seed.grid[0];
    this.#state.energyQ[i] = seed.energyQ[0];
  }
  setEnergy(x, y, z, q) {
    const i = this.#index(x, y, z);
    checkedInteger(q, 0, MAX_ENERGY_Q, "energyQ");
    this.#external += BigInt(q) - BigInt(this.#state.energyQ[i]);
    this.#state.energyQ[i] = q;
    this.#state.grid[i] = thermalView(this.#state.grid[i], q, cold);
  }
  copyStateInto(target) {
    const count = this.#state.grid.length;
    const values = ["grid", "energyQ"].map((k) => target && Object.getOwnPropertyDescriptor(target, k)?.value);
    if (values.some((v) => !(v instanceof Uint32Array) || arrayName.call(v) !== "Uint32Array" || arrayLength.call(v) !== count || !(arrayBuffer.call(v) instanceof ArrayBuffer))) throw new Error("State copy needs two owned Uint32Arrays of the volume cell count.");
    const [grid, energies] = values;
    if (arrayBuffer.call(grid) === arrayBuffer.call(energies) && Math.abs(arrayOffset.call(grid) - arrayOffset.call(energies)) < count * 4) throw new Error("State copy coordinates overlap.");
    Uint32Array.prototype.set.call(grid, this.#state.grid);
    Uint32Array.prototype.set.call(energies, this.#state.energyQ);
    return this.#tick;
  }
  snapshot() {
    return {
      schemaVersion: SCHEMA_VERSION_3D,
      rulesVersion: RULES_VERSION_3D,
      materialCatalogHash: MATERIAL_CATALOG_HASH_3D,
      width: this.width,
      height: this.height,
      depth: this.depth,
      tick: this.#tick,
      packedCells: Array.from(this.#state.grid),
      energyQ: Array.from(this.#state.energyQ)
    };
  }
  restore(snapshot) {
    const next = validateVolumeSnapshot$1(snapshot, this.#maximum);
    if (snapshot.width !== this.width || snapshot.height !== this.height || snapshot.depth !== this.depth) throw new Error("3D snapshot geometry differs from the field.");
    this.#state = next;
    this.#tick = snapshot.tick;
    this.#initial = this.#total();
    this.#external = 0n;
  }
  energyLedger() {
    return energyLedger(this.#state, cold);
  }
  energyBalance() {
    const currentQ = this.#total();
    return { initialQ: this.#initial, externalQ: this.#external, currentQ, driftQ: currentQ - this.#initial - this.#external };
  }
}
function createStateSpaceField3D(width, height, depth, fillMaterial = MAT.AIR) {
  return new CpuVolume(width, height, depth, fillMaterial);
}
function validateVolumeSnapshot(value) {
  return validateVolumeSnapshot$1(value);
}
const VOLUME_SHADER = `
struct Params { shape: vec4u, rule: vec4u, tick: vec4u }
@group(0) @binding(0) var<storage, read> cells: array<u32>;
@group(0) @binding(1) var<storage, read> energies: array<u32>;
@group(0) @binding(2) var<storage, read_write> nextCells: array<u32>;
@group(0) @binding(3) var<storage, read_write> nextEnergies: array<u32>;
@group(0) @binding(4) var<storage, read> cold: array<u32>;
@group(0) @binding(5) var<uniform> p: Params;
const MAX_Q = 0x3fffffffu;
fn prop(v: u32, f: u32) -> u32 { return cold[(v & 255u) * 24u + f]; }
fn temperature(v: u32, q: u32) -> u32 {
  let heat = q - prop(v,16u)*256u; let latent = prop(v,19u)*256u;
  var t = max(0, i32(heat)-i32(latent));
  let boil = prop(v,13u); let up = select(prop(v,12u),boil,boil!=0u);
  let ut = prop(v,select(2u,3u,boil!=0u))*256u;
  let freeze = prop(v,14u); let down = select(prop(v,15u),freeze,freeze!=0u);
  let dt = prop(v,select(9u,8u,freeze!=0u))*256u;
  if (up!=0u && heat>=latent+ut) { t=max(i32(ut),i32(heat)-i32(prop(up,19u)*256u)); }
  else if (down!=0u && heat<=latent+dt) { t=min(i32(dt),max(0,i32(heat)-i32(prop(down,19u)*256u))); }
  return u32(t);
}
fn thermal(v:u32,q:u32)->u32 { return (v&0xffff00ffu)|(min(255u,temperature(v,q)/256u)<<8u); }
fn transition(v:u32,q:u32)->u32 {
  let chemical=prop(v,16u)*256u;
  let boil=prop(v,13u); let up=select(prop(v,12u),boil,boil!=0u);
  if(up!=0u && q>=chemical+(prop(up,19u)+prop(v,select(2u,3u,boil!=0u)))*256u) {return up;}
  let freeze=prop(v,14u); let down=select(prop(v,15u),freeze,freeze!=0u);
  if(down!=0u && q<=chemical+(prop(down,19u)+prop(v,select(9u,8u,freeze!=0u)))*256u) {return down;}
  return v&255u;
}
fn pairEnergy(a:u32,b:u32,ea:u32,eb:u32)->u32 {
  let ta=temperature(a,ea); let tb=temperature(b,eb);
  let ca=prop(a,1u); let cb=prop(b,1u); var k=0u;
  if(ca+cb>0u){k=2u*ca*cb/(ca+cb);}
  let diff=u32(abs(i32(ta)-i32(tb)));
  var flux=min(diff/512u*k+(diff%512u*k+511u)/512u,diff/2u);
  if(ta>tb){flux=min(flux,min(ea-prop(a,16u)*256u,MAX_Q-eb)); return ea-flux;}
  flux=min(flux,min(eb-prop(b,16u)*256u,MAX_Q-ea)); return ea+flux;
}
fn phase(v:u32)->u32{return (v>>24u)&15u;}
fn fixed(v:u32)->bool{return phase(v)==0u||phase(v)==6u;}
fn liquid(v:u32)->bool{let s=phase(v);return s==2u||s==3u||s==7u;}
fn falling(v:u32)->bool{return phase(v)==1u||liquid(v);}
fn gas(v:u32)->bool{return phase(v)==4u;}
fn fall(s:u32,t:u32)->bool{return falling(cells[s])&&!fixed(cells[s])&&!fixed(cells[t])&&prop(cells[s],0u)>prop(cells[t],0u);}
fn rank(i:u32)->i32{return i32(temperature(cells[i],energies[i])/256u)*2-i32(prop(cells[i],0u));}
fn rise(s:u32,t:u32)->bool{return (cells[s]&255u)!=0u&&gas(cells[s])&&gas(cells[t])&&rank(s)>rank(t)+16;}
fn index(c:vec3i)->u32{return u32(c.x)+p.shape.x*(u32(c.y)+p.shape.y*u32(c.z));}
fn inside(c:vec3i)->bool{return all(c>=vec3i(0))&&all(c<vec3i(p.shape.xyz));}
fn hasFall(i:u32,c:vec3i)->bool{
  if(c.y+1>=i32(p.shape.y)){return false;}
  let b=c+vec3i(0,1,0); if(fall(i,index(b))){return true;}
  let offsets=array<vec3i,4>(vec3i(1,0,0),vec3i(-1,0,0),vec3i(0,0,1),vec3i(0,0,-1));
  for(var k=0u;k<4u;k++){let t=b+offsets[k];if(inside(t)&&fall(i,index(t))){return true;}}
  return false;
}
fn spread(s:u32,t:u32)->bool{return liquid(cells[s])&&gas(cells[t])&&prop(cells[s],0u)>prop(cells[t],0u);}
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) id:vec3u){
  let i=id.x; if(i>=p.shape.w){return;}
  let v=cells[i]; let q=energies[i]; var outV=v;var outQ=q;
  let kind=p.rule.x;
  if(kind==6u){let m=transition(v,q);if(m!=(v&255u)){outV=thermal((v&0xf0ff0000u)|m|(prop(m,20u)<<24u),q);}}
  else {
    let c=vec3i(vec3u(i%p.shape.x,(i/p.shape.x)%p.shape.y,i/(p.shape.x*p.shape.y)));
    let vertical=kind==0u||kind==1u||kind==3u;
    let axis=select(p.rule.y,1u,vertical); let lower=(u32(c[axis])&1u)!=p.rule.z;
    var delta=vec3i(0);delta[axis]=1;
    if(kind==1u){delta[p.rule.y]=i32(p.rule.w);}
    let a=c-select(vec3i(0),delta,lower); let b=a+delta;
    if(inside(a)&&inside(b)){
      let ai=index(a);let bi=index(b);var swap=false;
      if(kind==0u){swap=fall(ai,bi);}
      else if(kind==1u){swap=!fall(ai,index(a+vec3i(0,1,0)))&&fall(ai,bi);}
      else if(kind==2u){swap=(spread(ai,bi)&&!hasFall(ai,a))||(spread(bi,ai)&&!hasFall(bi,b));}
      else if(kind==3u){swap=rise(bi,ai);}
      else if(kind==4u){
        var hash=ai*374761393u+p.rule.y*668265263u+p.tick.x*1442695041u;
        hash=(hash^(hash>>13u))*1274126177u;
        let choose=((hash^(hash>>16u))&1u)==0u;
        let s=select(bi,ai,choose);let t=select(ai,bi,choose);let sy=select(b.y,a.y,choose);
        swap=(cells[s]&255u)!=0u&&gas(cells[s])&&gas(cells[t])&&(sy==0||!rise(s,s-p.shape.x))&&((cells[t]&255u)==0u||rank(s)>rank(t)+16);
      } else if(kind==5u){
        // Valid states already have normalized thermal bits. This is the same
        // exact no-op used by the CPU reference for equal material/energy pairs.
        if((cells[ai]&255u)!=(cells[bi]&255u)||energies[ai]!=energies[bi]){
          let eq=pairEnergy(cells[ai],cells[bi],energies[ai],energies[bi]);
          outQ=select(eq,energies[ai]+energies[bi]-eq,lower);outV=thermal(v,outQ);
        }
      }
      if(swap){let other=select(bi,ai,lower);outV=cells[other];outQ=energies[other];}
    }
  }
  nextCells[i]=outV;nextEnergies[i]=outQ;
}
`;
const ACCESS_SHADER = VOLUME_SHADER.slice(0, VOLUME_SHADER.indexOf("@compute")) + `
@group(0) @binding(6) var<storage, read> edits:array<vec4u>;
@group(0) @binding(7) var<storage, read_write> results:array<u32>;
@compute @workgroup_size(64) fn edit(@builtin(global_invocation_id) id:vec3u){
  if(id.x>=p.tick.y){return;}let e=edits[id.x];let old=nextEnergies[e.x];
  if(e.y==0u){nextCells[e.x]=e.z;nextEnergies[e.x]=e.w;}
  else{nextCells[e.x]=thermal(nextCells[e.x],e.w);nextEnergies[e.x]=e.w;}
  results[id.x*2u]=old;results[id.x*2u+1u]=e.w;
}
@compute @workgroup_size(64) fn query(@builtin(global_invocation_id) id:vec3u){
  let i=id.x;let size=p.rule.xyz; if(i>=size.x*size.y*size.z){return;}
  let c=p.tick.xyz+vec3u(i%size.x,(i/size.x)%size.y,i/(size.x*size.y));
  results[i]=cells[index(vec3i(c))];
}
`;
function chunkShaders(edge) {
  if (!edge) return { physics: VOLUME_SHADER, access: ACCESS_SHADER };
  const mapping = `
const EDGE=${edge}u;
fn linear(c:vec3i)->u32{return u32(c.x)+p.shape.x*(u32(c.y)+p.shape.y*u32(c.z));}
fn index(c:vec3i)->u32{
 let u=vec3u(c);let n=p.shape.xyz/EDGE;let k=u/EDGE;let local=u%EDGE;
 return (k.x+n.x*(k.y+n.y*k.z))*EDGE*EDGE*EDGE+local.x+EDGE*(local.y+EDGE*local.z);
}
fn coordinate(i:u32)->vec3i{
 let n=p.shape.xyz/EDGE;let k=i/(EDGE*EDGE*EDGE);let local=i%(EDGE*EDGE*EDGE);
 return vec3i(vec3u(k%n.x,(k/n.x)%n.y,k/(n.x*n.y))*EDGE+vec3u(local%EDGE,(local/EDGE)%EDGE,local/(EDGE*EDGE)));
}
`;
  const translate = (code) => code.replace("fn index(c:vec3i)->u32{return u32(c.x)+p.shape.x*(u32(c.y)+p.shape.y*u32(c.z));}", mapping).replace("let c=vec3i(vec3u(i%p.shape.x,(i/p.shape.x)%p.shape.y,i/(p.shape.x*p.shape.y)));", "let c=coordinate(i);").replace("var hash=ai*374761393u", "var hash=linear(a)*374761393u").replace("!rise(s,s-p.shape.x)", "!rise(s,index(select(b,a,choose)+vec3i(0,-1,0)))");
  const dirty = `
@group(0) @binding(6) var<storage,read_write> dirty:array<atomic<u32>>;
fn mark(c:vec3i){
 let n=p.shape.xyz/EDGE;let k=vec3u(c)/EDGE;
 atomicStore(&dirty[k.x+n.x*(k.y+n.y*k.z)],1u);
}
fn changed(c:vec3i){
 mark(c);
 for(var axis=0u;axis<3u;axis++){
  var t=c;t[axis]-=1;
  if(inside(t)&&u32(c[axis])%EDGE==0u){mark(t);}
  t=c;t[axis]+=1;
  if(inside(t)&&u32(t[axis])%EDGE==0u){mark(t);}
 }
}
`;
  const physics = translate(VOLUME_SHADER).replace("@compute @workgroup_size(64) fn main", dirty + "\n@compute @workgroup_size(64) fn main").replace("nextCells[i]=outV;nextEnergies[i]=outQ;", "if((v&255u)!=(outV&255u)){changed(coordinate(i));}\n  nextCells[i]=outV;nextEnergies[i]=outQ;");
  return { physics, access: translate(ACCESS_SHADER) };
}
function activeShaders(edge, chunks, activeEdge = Math.min(edge, 8)) {
  const base = chunkShaders(edge);
  const declarations = `
@group(0) @binding(7) var<storage,read_write> activity:array<atomic<u32>>;
@group(0) @binding(8) var<storage,read_write> indirect:array<atomic<u32>>;
@group(0) @binding(9) var<storage,read_write> otherIndirect:array<atomic<u32>>;
const CHUNKS=${chunks}u;
const ACTIVE_EDGE=${activeEdge}u;
const WORK_CELLS=ACTIVE_EDGE*ACTIVE_EDGE*ACTIVE_EDGE;
const AWAKE=16u;
const CERT=AWAKE+CHUNKS;
const LIST=CERT+CHUNKS;
const REASON=LIST+CHUNKS;
// Rebuild canonically at tick boundaries. Within a tick, append each newly
// awake tile once; the existing dispatch prefix remains immutable.
const PLAN_DIRTY=10u;
fn wake(c:vec3i,reason:u32){
 let n=vec3i(p.shape.xyz/ACTIVE_EDGE);let k=c/i32(ACTIVE_EDGE);let local=vec3u(c)%ACTIVE_EDGE;
 let lo=-vec3i(select(vec3u(0),vec3u(1),local<vec3u(2)));
 let hi=vec3i(select(vec3u(0),vec3u(1),local+vec3u(2)>=vec3u(ACTIVE_EDGE)));
 for(var z=lo.z;z<=hi.z;z++){for(var y=lo.y;y<=hi.y;y++){for(var x=lo.x;x<=hi.x;x++){
  let t=k+vec3i(x,y,z);if(all(t>=vec3i(0))&&all(t<n)){
   let j=u32(t.x+n.x*(t.y+n.y*t.z));
   if(atomicLoad(&activity[AWAKE+j])==0u){
    if(atomicOr(&activity[AWAKE+j],1u)==0u){
     let slot=atomicAdd(&activity[3],1u);atomicStore(&activity[LIST+slot],j);
     atomicMax(&indirect[0],(slot+1u)*WORK_CELLS/64u);atomicStore(&activity[PLAN_DIRTY],1u);
    }
   }
   if((atomicLoad(&activity[REASON+j])&reason)!=reason){atomicOr(&activity[REASON+j],reason);}
  }
 }}}
}
fn activeIndex(c:vec3i)->u32{let n=p.shape.xyz/ACTIVE_EDGE;let k=vec3u(c)/ACTIVE_EDGE;return k.x+n.x*(k.y+n.y*k.z);}
fn workIndex(id:u32)->u32{
 let n=p.shape.xyz/ACTIVE_EDGE;let k=atomicLoad(&activity[LIST+id/WORK_CELLS]);let l=id%WORK_CELLS;
 return index(vec3i(vec3u(k%n.x,(k/n.x)%n.y,k/(n.x*n.y))*ACTIVE_EDGE+vec3u(l%ACTIVE_EDGE,(l/ACTIVE_EDGE)%ACTIVE_EDGE,l/(ACTIVE_EDGE*ACTIVE_EDGE))));
}
fn quiet(i:u32)->bool{
 let v=cells[i];let q=energies[i];let c=coordinate(i);let temp=temperature(v,q);let immovable=fixed(v);
 if(thermal(v,q)!=v||transition(v,q)!=(v&255u)){return false;}
 let normals=array<vec3i,6>(vec3i(-1,0,0),vec3i(1,0,0),vec3i(0,-1,0),vec3i(0,1,0),vec3i(0,0,-1),vec3i(0,0,1));
 for(var f=0u;f<6u;f++){
  let t=c+normals[f];if(!inside(t)){continue;}let j=index(t);let other=cells[j];
  // Test the exact exchange, including zero integer flux and saturated energies.
  if(((v&255u)!=(other&255u)||q!=energies[j])&&temp!=temperature(other,energies[j])&&pairEnergy(v,other,q,energies[j])!=q){return false;}
  if(immovable){continue;}
  if(f==2u){if(rise(i,j)||fall(j,i)){return false;}}
  else if(f==3u){if(fall(i,j)||rise(j,i)){return false;}}
  else{
   if(spread(i,j)||spread(j,i)){return false;}
   if(gas(v)&&gas(other)&&(((v&255u)!=0u&&((other&255u)==0u||rank(i)>rank(j)+16))||((other&255u)!=0u&&((v&255u)==0u||rank(j)>rank(i)+16)))){return false;}
  }
 }
 if(immovable){return true;}
 let horizontal=array<vec3i,4>(vec3i(-1,0,0),vec3i(1,0,0),vec3i(0,0,-1),vec3i(0,0,1));
 for(var f=0u;f<4u;f++){
  let down=c+horizontal[f]+vec3i(0,1,0);if(inside(down)&&fall(i,index(down))){return false;}
  let up=c+horizontal[f]-vec3i(0,1,0);if(inside(up)&&fall(index(up),i)){return false;}
 }
 return true;
}
// Pack 32 activity flags per lane, prefix only 64 lane counts, then scatter
// contiguous blocks in canonical tile order. No physical pair or rule changes.
const MASKS=(CHUNKS+31u)/32u;
var<workgroup> awakeMasks:array<u32,128>;
var<workgroup> laneCounts:array<u32,64>;
var<workgroup> laneOffsets:array<u32,64>;
var<workgroup> rebuildList:u32;
fn dispatchSize(count:u32){
 atomicStore(&indirect[0],count*WORK_CELLS/64u);atomicStore(&indirect[1],1u);atomicStore(&indirect[2],1u);
 atomicStore(&otherIndirect[0],count*WORK_CELLS/64u);atomicStore(&otherIndirect[1],1u);atomicStore(&otherIndirect[2],1u);
}
@compute @workgroup_size(64) fn collectWork(@builtin(local_invocation_index) lane:u32){
 if(lane==0u){rebuildList=atomicExchange(&activity[PLAN_DIRTY],0u);}
 let rebuild=workgroupUniformLoad(&rebuildList);
 if(rebuild==0u){
  if(lane==0u){
   let count=atomicLoad(&activity[3]);dispatchSize(count);atomicStore(&activity[6],0u);atomicAdd(&activity[9],1u);
  }
  return;
 }
 for(var word=lane;word<MASKS;word+=64u){
  var bits=0u;
  for(var bit=0u;bit<32u;bit++){
   let k=word*32u+bit;if(k>=CHUNKS){break;}
   if(atomicLoad(&activity[AWAKE+k])!=0u){bits|=1u<<bit;}
  }
  awakeMasks[word]=bits;
 }
 workgroupBarrier();
 let block=(MASKS+63u)/64u;let start=lane*block;let end=min(start+block,MASKS);
 var length=0u;for(var word=start;word<end;word++){length+=countOneBits(awakeMasks[word]);}
 laneCounts[lane]=length;
 workgroupBarrier();
 if(lane==0u){
  var count=0u;for(var k=0u;k<64u;k++){laneOffsets[k]=count;count+=laneCounts[k];}
  atomicStore(&activity[3],count);atomicStore(&activity[6],0u);
  atomicAdd(&activity[8],1u);
  dispatchSize(count);
 }
 workgroupBarrier();
 var slot=laneOffsets[lane];
 for(var word=start;word<end;word++){
  var bits=awakeMasks[word];
  while(bits!=0u){let bit=firstTrailingBit(bits);atomicStore(&activity[LIST+slot],word*32u+bit);slot++;bits&=bits-1u;}
 }
}
@compute @workgroup_size(64) fn certify(@builtin(global_invocation_id) id:vec3u){
 if(id.x>=atomicLoad(&activity[3])*WORK_CELLS){return;}let i=workIndex(id.x);let k=activeIndex(coordinate(i));
 atomicAnd(&activity[CERT+k],1u);if(!quiet(i)){atomicOr(&activity[CERT+k],1u);}nextCells[i]=cells[i];nextEnergies[i]=energies[i];
}
@compute @workgroup_size(64) fn commitCert(@builtin(global_invocation_id) id:vec3u){
 let k=id.x;if(k>=CHUNKS){return;}
 // The following 26 passes reused/appended the prefix, without a planner dispatch.
 if(k==0u){atomicAdd(&activity[9],26u);}
 if(atomicLoad(&activity[CERT+k])==0u&&atomicExchange(&activity[AWAKE+k],0u)!=0u){atomicStore(&activity[PLAN_DIRTY],1u);}
 // Reset once after certification, rather than in all 27 work-list passes.
 // 2 means unvisited: a tile woken by the final phase must remain awake.
 atomicStore(&activity[CERT+k],2u);
 if(atomicLoad(&activity[AWAKE+k])==0u){atomicAdd(&activity[6],1u);}
}
`;
  function replace(code, from, to) {
    if (code.split(from).length !== 2) throw new Error("Sparse shader template differs from ca-3d-m1.");
    return code.replace(from, to);
  }
  let physics = replace(base.physics, "@compute @workgroup_size(64) fn main", declarations + "\n@compute @workgroup_size(64) fn main");
  physics = replace(physics, "fn main(@builtin(global_invocation_id) id:vec3u)", "fn main(@builtin(global_invocation_id) id:vec3u,@builtin(num_workgroups) groups:vec3u)");
  physics = replace(physics, "let i=id.x; if(i>=p.shape.w){return;}", "if(id.x==0u){atomicMax(&indirect[0],groups.x);let count=groups.x*64u/WORK_CELLS;atomicAdd(&activity[4],count);atomicMax(&activity[5],count);}\nlet i=workIndex(id.x);");
  physics = replace(physics, "else {\n    let c=coordinate(i);", "else if(kind==5u||!fixed(v)) {\n    let c=coordinate(i);");
  physics = replace(physics, "nextCells[i]=outV;nextEnergies[i]=outQ;", "if(v!=outV||q!=outQ){wake(coordinate(i),select(4u,select(2u,8u,kind==6u),(v&255u)!=(outV&255u)));}\n  nextCells[i]=outV;nextEnergies[i]=outQ;");
  return { physics, access: base.access };
}
const palette = Array.from({ length: 18 }, (_, i) => {
  const m = MATERIALS_3D.find((m2) => m2.id === i);
  return `vec3f(${[1, 3, 5].map((k) => m ? parseInt(m.color.slice(k, k + 2), 16) / 255 : 0).join(",")})`;
}).join(",");
const COMMON = `
struct Camera { eye:vec4f, right:vec4f, up:vec4f, forward:vec4f, projection:vec4f, shape:vec4u }
const normals=array<vec3i,6>(vec3i(-1,0,0),vec3i(1,0,0),vec3i(0,-1,0),vec3i(0,1,0),vec3i(0,0,-1),vec3i(0,0,1));
`;
const MESH = COMMON + `
@group(0) @binding(0) var<storage,read> grid:array<u32>;
@group(0) @binding(1) var<storage,read_write> faces:array<u32>;
struct Draw { vertices:u32, count:atomic<u32>, first:u32, instance:u32 }
@group(0) @binding(2) var<storage,read_write> args:Draw;
@group(0) @binding(3) var<uniform> camera:Camera;
@compute @workgroup_size(64) fn mesh(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;let shape=camera.shape.xyz;if(i>=shape.x*shape.y*shape.z){return;}
 let m=grid[i]&255u;if(m==0u){return;}
 let c=vec3i(vec3u(i%shape.x,(i/shape.x)%shape.y,i/(shape.x*shape.y)));
 for(var f=0u;f<6u;f++){
  let t=c+normals[f];var exposed=true;
  if(m!=9u&&all(t>=vec3i(0))&&all(t<vec3i(shape))){let n=grid[u32(t.x)+shape.x*(u32(t.y)+shape.y*u32(t.z))]&255u;exposed=n==0u||n==9u;}
  if(exposed){let slot=atomicAdd(&args.count,1u);faces[slot]=i*6u+f;}
 }
}`;
const DRAW = COMMON + `
@group(0) @binding(0) var<storage,read> grid:array<u32>;
@group(0) @binding(1) var<storage,read> faces:array<u32>;
@group(0) @binding(2) var<uniform> camera:Camera;
const colors=array<vec3f,18>(${palette});
struct Out{@builtin(position) position:vec4f,@location(0) color:vec3f,@location(1) fog:f32,@location(2) uv:vec2f}
@vertex fn vertex(@builtin(vertex_index) vertex:u32,@builtin(instance_index) instance:u32)->Out{
 let face=faces[instance];let i=face/6u;let f=face%6u;let shape=camera.shape.xyz;
 let c=vec3f(f32(i%shape.x),f32((i/shape.x)%shape.y),f32(i/(shape.x*shape.y)));
 let uvs=array<vec2f,6>(vec2f(0,0),vec2f(1,0),vec2f(1,1),vec2f(0,0),vec2f(1,1),vec2f(0,1));let uv=uvs[vertex];
 var local=vec3f(0);switch f{
 case 0u:{local=vec3f(0,uv.y,uv.x);}case 1u:{local=vec3f(1,uv.y,1-uv.x);}
 case 2u:{local=vec3f(uv.x,0,1-uv.y);}case 3u:{local=vec3f(uv.x,1,uv.y);}
 case 4u:{local=vec3f(1-uv.x,uv.y,0);}default:{local=vec3f(uv.x,uv.y,1);}}
 let v=grid[i];let m=v&255u;if(m==9u){local=vec3f(.39)+local*.22;}
 let p=c+local-camera.eye.xyz;let z=dot(p,camera.forward.xyz);
 var out:Out;out.position=vec4f(dot(p,camera.right.xyz)/camera.projection.x,dot(p,camera.up.xyz)/camera.projection.y,camera.projection.z*z+camera.projection.w,z);
 let light=.30+.70*max(0.,dot(vec3f(normals[f]),normalize(vec3f(.4,-.85,.3))));
 let heat=clamp((f32((v>>8u)&255u)-170.)/85.,0.,1.);
 var color=colors[m]*light+heat*vec3f(.3,.05,0);
 if(i==camera.shape.w){color=mix(color,vec3f(1,.7,.22),.38);}
 out.color=color;out.fog=clamp(z/90.,0.,.7);out.uv=uv;return out;
}
@fragment fn fragment(v:Out)->@location(0) vec4f{let edge=select(1.,.78,any(v.uv<vec2f(.02))||any(v.uv>vec2f(.98)));return vec4f(mix(v.color*edge,vec3f(.065,.10,.15),v.fog),1);}
`;
async function moduleFor(device, code) {
  const module = device.createShaderModule({ code });
  const info = await module.getCompilationInfo();
  const errors = info.messages.filter((m) => m.type === "error");
  if (errors.length) throw new Error(errors.map((m) => m.message).join("\n"));
  return module;
}
async function makeTerrainRenderer(device, canvas, state, profiler, tick = () => 0) {
  const context = canvas.getContext("webgpu");
  if (!context) throw new Error("Cannot create WebGPU canvas.");
  const format = navigator.gpu.getPreferredCanvasFormat();
  context.configure({ device, format, alphaMode: "opaque" });
  const meshModule = await moduleFor(device, MESH), drawModule = await moduleFor(device, DRAW);
  const mesh = await device.createComputePipelineAsync({ layout: "auto", compute: { module: meshModule, entryPoint: "mesh" } });
  const draw = await device.createRenderPipelineAsync({ layout: "auto", vertex: { module: drawModule, entryPoint: "vertex" }, fragment: { module: drawModule, entryPoint: "fragment", targets: [{ format }] }, primitive: { topology: "triangle-list" }, depthStencil: { format: "depth24plus", depthWriteEnabled: true, depthCompare: "less" } });
  const count = state().shape.reduce((a, b) => a * b, 1);
  const faces = device.createBuffer({ size: count * 6 * 4, usage: GPUBufferUsage.STORAGE });
  const args = device.createBuffer({ size: 16, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.INDIRECT | GPUBufferUsage.COPY_DST });
  const uniform = device.createBuffer({ size: 96, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
  let depth, width = 0, height = 0, closed = false;
  const data = new ArrayBuffer(96), f = new Float32Array(data), u = new Uint32Array(data), resetArgs = new Uint32Array([6, 0, 0, 0]);
  const bindings = /* @__PURE__ */ new Map();
  return {
    async render(camera) {
      if (closed) throw new Error("Terrain renderer is closed.");
      const vectors = [camera.eye, camera.right, camera.up, camera.forward].map((a) => {
        if (!a || a.length !== 3) throw new Error("Invalid terrain camera.");
        const copy = [a[0], a[1], a[2]];
        if (!copy.every(Number.isFinite)) throw new Error("Invalid terrain camera.");
        return copy;
      });
      if (camera.target !== void 0) checkedTarget(camera.target, count);
      if (canvas.width < 1 || canvas.height < 1) throw new Error("Canvas must have positive dimensions.");
      const trace = profiler?.begin("render", tick());
      if (!depth || width !== canvas.width || height !== canvas.height) {
        depth?.destroy();
        width = canvas.width;
        height = canvas.height;
        depth = device.createTexture({ size: [width, height], format: "depth24plus", usage: GPUTextureUsage.RENDER_ATTACHMENT });
      }
      const { grid, shape } = state();
      let groups = bindings.get(grid);
      if (!groups) {
        groups = { mesh: device.createBindGroup({ layout: mesh.getBindGroupLayout(0), entries: [grid, faces, args, uniform].map((buffer, binding) => ({ binding, resource: { buffer } })) }), draw: device.createBindGroup({ layout: draw.getBindGroupLayout(0), entries: [grid, faces, uniform].map((buffer, binding) => ({ binding, resource: { buffer } })) }) };
        bindings.set(grid, groups);
      }
      const near = 0.06, far = 160, tan = Math.tan(Math.PI / 6);
      f.set([...vectors[0], 0, ...vectors[1], 0, ...vectors[2], 0, ...vectors[3], 0, tan * width / height, tan, far / (far - near), -near * far / (far - near)]);
      u.set([...shape, camera.target ?? 4294967295], 20);
      device.queue.writeBuffer(uniform, 0, data);
      device.queue.writeBuffer(args, 0, resetArgs);
      profiler?.mark(trace, "preparedAt");
      device.pushErrorScope("validation");
      const encoder = device.createCommandEncoder();
      const compute = encoder.beginComputePass(profiler?.pass(trace, "mesh"));
      compute.setPipeline(mesh);
      compute.setBindGroup(0, groups.mesh);
      compute.dispatchWorkgroups(Math.ceil(count / 64));
      compute.end();
      const pass = encoder.beginRenderPass({ ...profiler?.pass(trace, "draw"), colorAttachments: [{ view: context.getCurrentTexture().createView(), clearValue: [0.065, 0.1, 0.15, 1], loadOp: "clear", storeOp: "store" }], depthStencilAttachment: { view: depth.createView(), depthClearValue: 1, depthLoadOp: "clear", depthStoreOp: "store" } });
      pass.setPipeline(draw);
      pass.setBindGroup(0, groups.draw);
      pass.drawIndirect(args, 0);
      pass.end();
      profiler?.resolve(encoder, trace);
      profiler?.mark(trace, "encodedAt");
      device.queue.submit([encoder.finish()]);
      profiler?.submitted(trace);
      const [error] = await Promise.all([device.popErrorScope(), device.queue.onSubmittedWorkDone().then(() => profiler?.mark(trace, "queueCompletedAt"))]);
      if (error) throw new Error(error.message);
      profiler?.mark(trace, "completedAt");
    },
    close() {
      if (closed) return;
      closed = true;
      depth?.destroy();
      faces.destroy();
      args.destroy();
      uniform.destroy();
      context.unconfigure();
      bindings.clear();
    }
  };
}
function checkedTarget(target, count) {
  if (!Number.isSafeInteger(target) || target < 0 || target >= count) throw new Error("Invalid highlighted cell.");
}
async function makeChunkRenderer(device, canvas, state, dirty, edge, profiler, tick = () => 0) {
  const context = canvas.getContext("webgpu");
  if (!context) throw new Error("Cannot create WebGPU canvas.");
  const shape = state().shape, count = shape.reduce((a, b) => a * b, 1), capacity = edge ** 3 * 6, chunks = count / edge ** 3;
  const format = navigator.gpu.getPreferredCanvasFormat();
  context.configure({ device, format, alphaMode: "opaque" });
  const mapping = `
const EDGE=${edge}u;
fn coordinate(i:u32)->vec3u{let n=camera.shape.xyz/EDGE;let k=i/(EDGE*EDGE*EDGE);let l=i%(EDGE*EDGE*EDGE);return vec3u(k%n.x,(k/n.x)%n.y,k/(n.x*n.y))*EDGE+vec3u(l%EDGE,(l/EDGE)%EDGE,l/(EDGE*EDGE));}
fn index(c:vec3u)->u32{let n=camera.shape.xyz/EDGE;let k=c/EDGE;let l=c%EDGE;return (k.x+n.x*(k.y+n.y*k.z))*EDGE*EDGE*EDGE+l.x+EDGE*(l.y+EDGE*l.z);}
fn linear(c:vec3u)->u32{return c.x+camera.shape.x*(c.y+camera.shape.y*c.z);}
`;
  const common = `struct Camera {eye:vec4f,right:vec4f,up:vec4f,forward:vec4f,projection:vec4f,shape:vec4u}
@group(0) @binding(0) var<storage,read> grid:array<u32>;
@group(0) @binding(1) var<storage,read_write> faces:array<u32>;
@group(0) @binding(2) var<storage,read_write> args:array<atomic<u32>>;
@group(0) @binding(3) var<uniform> camera:Camera;
@group(0) @binding(4) var<storage,read_write> dirty:array<atomic<u32>>;
@group(0) @binding(5) var<storage,read_write> rebuild:array<u32>;
@group(0) @binding(6) var<storage,read_write> work:array<u32>;
@group(0) @binding(7) var<storage,read_write> dispatch:array<u32>;
${mapping}
@compute @workgroup_size(1) fn reset(){
 var length=0u;
 for(var k=0u;k<${chunks}u;k++){
  let changed=atomicExchange(&dirty[k],0u);rebuild[k]=changed;
  if(changed!=0u){
   work[length]=k;length++;
   atomicStore(&args[k*4u],6u);atomicStore(&args[k*4u+1u],0u);atomicStore(&args[k*4u+2u],k*6u);atomicStore(&args[k*4u+3u],0u);
  }
 }
 dispatch[0]=${Math.ceil(edge ** 3 / 64)}u;dispatch[1]=length;dispatch[2]=1u;
}
@compute @workgroup_size(64) fn mesh(@builtin(global_invocation_id) id:vec3u){
 if(id.x>=EDGE*EDGE*EDGE){return;}let k=work[id.y];let i=k*EDGE*EDGE*EDGE+id.x;
 let m=grid[i]&255u;if(m==0u){return;}let c=vec3i(coordinate(i));
 let normals=array<vec3i,6>(vec3i(-1,0,0),vec3i(1,0,0),vec3i(0,-1,0),vec3i(0,1,0),vec3i(0,0,-1),vec3i(0,0,1));
 for(var f=0u;f<6u;f++){let t=c+normals[f];var exposed=true;
  if(m!=9u&&all(t>=vec3i(0))&&all(t<vec3i(camera.shape.xyz))){let n=grid[index(vec3u(t))]&255u;exposed=n==0u||n==9u;}
  if(exposed){let slot=atomicAdd(&args[k*4u+1u],1u);faces[k*${capacity}u+slot]=i*6u+f;}
 }
}`;
  const drawCode = DRAW.replace("const colors=", mapping + "\nconst colors=").replace("let face=faces[instance];", "let face=faces[(vertex/6u)*" + capacity + "u+instance];").replace("let c=vec3f(f32(i%shape.x),f32((i/shape.x)%shape.y),f32(i/(shape.x*shape.y)));", "let c=vec3f(coordinate(i));").replace("let uv=uvs[vertex];", "let uv=uvs[vertex%6u];").replace("if(i==camera.shape.w)", "if(linear(coordinate(i))==camera.shape.w)");
  async function module(code) {
    const m = device.createShaderModule({ code });
    const info = await m.getCompilationInfo();
    const errors = info.messages.filter((m2) => m2.type === "error");
    if (errors.length) throw new Error(errors.map((m2) => `${m2.lineNum}: ${m2.message}`).join("\n"));
    return m;
  }
  const meshModule = await module(common), drawModule = await module(drawCode);
  const reset = await device.createComputePipelineAsync({ layout: "auto", compute: { module: meshModule, entryPoint: "reset" } });
  const mesh = await device.createComputePipelineAsync({ layout: "auto", compute: { module: meshModule, entryPoint: "mesh" } });
  const draw = await device.createRenderPipelineAsync({ layout: "auto", vertex: { module: drawModule, entryPoint: "vertex" }, fragment: { module: drawModule, entryPoint: "fragment", targets: [{ format }] }, primitive: { topology: "triangle-list" }, depthStencil: { format: "depth24plus", depthWriteEnabled: true, depthCompare: "less" } });
  const buffer = (size, usage) => device.createBuffer({ size, usage });
  const faces = buffer(count * 24, GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC), args = buffer(chunks * 16, GPUBufferUsage.STORAGE | GPUBufferUsage.INDIRECT | GPUBufferUsage.COPY_SRC), rebuild = buffer(chunks * 4, GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC), uniform = buffer(96, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST);
  const work = buffer(chunks * 4, GPUBufferUsage.STORAGE), dispatch = buffer(12, GPUBufferUsage.STORAGE | GPUBufferUsage.INDIRECT | GPUBufferUsage.COPY_SRC);
  device.queue.writeBuffer(dirty, 0, new Uint32Array(chunks).fill(1));
  const resetGroup = device.createBindGroup({ layout: reset.getBindGroupLayout(0), entries: [{ binding: 2, resource: { buffer: args } }, { binding: 4, resource: { buffer: dirty } }, { binding: 5, resource: { buffer: rebuild } }, { binding: 6, resource: { buffer: work } }, { binding: 7, resource: { buffer: dispatch } }] });
  const bindings = /* @__PURE__ */ new Map();
  const data = new ArrayBuffer(96), f = new Float32Array(data), u = new Uint32Array(data), near = 0.06, far = 160, tan = Math.tan(Math.PI / 6);
  const n = shape.map((v) => v / edge), radius = Math.sqrt(3) * edge / 2, centers = new Float64Array(chunks * 3);
  for (let k = 0; k < chunks; k++) {
    centers[k * 3] = (k % n[0] + 0.5) * edge;
    centers[k * 3 + 1] = (Math.floor(k / n[0]) % n[1] + 0.5) * edge;
    centers[k * 3 + 2] = (Math.floor(k / (n[0] * n[1])) + 0.5) * edge;
  }
  let depth, width = 0, height = 0, closed = false;
  let appearance = "diagnostic", natural;
  function encode(encoder, camera, grid, trace, gpuCamera) {
    if (closed) throw new Error("Terrain renderer is closed.");
    const vectors = [camera.eye, camera.right, camera.up, camera.forward].map((a) => {
      if (!a || a.length !== 3) throw new Error("Invalid terrain camera.");
      const v = [a[0], a[1], a[2]];
      if (!v.every(Number.isFinite)) throw new Error("Invalid terrain camera.");
      return v;
    });
    if (camera.target !== void 0 && (!Number.isSafeInteger(camera.target) || camera.target < 0 || camera.target >= count)) throw new Error("Invalid target.");
    if (canvas.width < 1 || canvas.height < 1) throw new Error("Canvas must have positive dimensions.");
    if (!depth || width !== canvas.width || height !== canvas.height) {
      depth?.destroy();
      width = canvas.width;
      height = canvas.height;
      depth = device.createTexture({ size: [width, height], format: "depth24plus", usage: GPUTextureUsage.RENDER_ATTACHMENT });
    }
    let groups = bindings.get(grid);
    if (!groups) {
      groups = { mesh: device.createBindGroup({ layout: mesh.getBindGroupLayout(0), entries: [{ binding: 0, resource: { buffer: grid } }, { binding: 1, resource: { buffer: faces } }, { binding: 2, resource: { buffer: args } }, { binding: 3, resource: { buffer: uniform } }, { binding: 6, resource: { buffer: work } }] }), draw: device.createBindGroup({ layout: draw.getBindGroupLayout(0), entries: [grid, faces, uniform].map((buffer2, binding) => ({ binding, resource: { buffer: buffer2 } })) }) };
      bindings.set(grid, groups);
    }
    for (let i = 0; i < 4; i++) f.set(vectors[i], i * 4);
    f.set([tan * width / height, tan, far / (far - near), -near * far / (far - near)], 16);
    u.set([...shape, camera.target ?? 4294967295], 20);
    device.queue.writeBuffer(uniform, 0, data);
    profiler?.mark(trace, gpuCamera ? "renderPreparedAt" : "preparedAt");
    if (gpuCamera) {
      encoder.copyBufferToBuffer(gpuCamera, 64, uniform, 0, 16);
      encoder.copyBufferToBuffer(gpuCamera, 80, uniform, 92, 4);
    }
    const compute = encoder.beginComputePass(profiler?.pass(trace, "mesh"));
    compute.setPipeline(reset);
    compute.setBindGroup(0, resetGroup);
    compute.dispatchWorkgroups(1);
    compute.setPipeline(mesh);
    compute.setBindGroup(0, groups.mesh);
    compute.dispatchWorkgroupsIndirect(dispatch, 0);
    compute.end();
    const output = context.getCurrentTexture().createView(), beauty = appearance === "naturalistic" ? natural : void 0;
    const prepared = beauty?.prepare(encoder, grid, width, height, profiler, trace);
    const pass = encoder.beginRenderPass({ ...profiler?.pass(trace, "draw"), colorAttachments: [{ view: prepared?.view ?? output, clearValue: beauty ? [0.028, 0.045, 0.06, 1] : [0.065, 0.1, 0.15, 1], loadOp: "clear", storeOp: "store" }], depthStencilAttachment: { view: depth.createView(), depthClearValue: 1, depthLoadOp: "clear", depthStoreOp: "store" } });
    pass.setPipeline(beauty?.draw ?? draw);
    pass.setBindGroup(0, prepared?.group ?? groups.draw);
    const bound = radius + (gpuCamera ? 4 : 0), horizontal = tan * width / height, horizontalRadius = bound * Math.hypot(1, horizontal), verticalRadius = bound * Math.hypot(1, tan);
    for (let k = 0; k < chunks; k++) {
      const cx = centers[k * 3] - vectors[0][0], cy = centers[k * 3 + 1] - vectors[0][1], cz = centers[k * 3 + 2] - vectors[0][2];
      const z = cx * vectors[3][0] + cy * vectors[3][1] + cz * vectors[3][2];
      const x = cx * vectors[1][0] + cy * vectors[1][1] + cz * vectors[1][2], y = cx * vectors[2][0] + cy * vectors[2][1] + cz * vectors[2][2];
      if (z + bound < near || z - bound > far || Math.abs(x) > z * horizontal + horizontalRadius || Math.abs(y) > z * tan + verticalRadius) continue;
      pass.drawIndirect(args, k * 16);
    }
    pass.end();
    beauty?.finish(encoder, output, profiler, trace);
  }
  const renderer = {
    async setAppearance(value) {
      if (closed) throw new Error("Terrain renderer is closed.");
      if (value !== "diagnostic" && value !== "naturalistic") throw new Error("Invalid terrain appearance.");
      if (value === "naturalistic" && !natural) {
        const { makeCavernAppearance } = await import("./cavern-appearance-DsnBTSZJ.js");
        natural = await makeCavernAppearance(device, format, shape, edge, capacity, faces, uniform);
      }
      appearance = value;
    },
    validateCamera(camera) {
      if (closed) throw new Error("Terrain renderer is closed.");
      for (const a of [camera.eye, camera.right, camera.up, camera.forward]) if (!a || a.length !== 3 || ![a[0], a[1], a[2]].every(Number.isFinite)) throw new Error("Invalid terrain camera.");
      if (camera.target !== void 0 && (!Number.isSafeInteger(camera.target) || camera.target < 0 || camera.target >= count)) throw new Error("Invalid target.");
      if (canvas.width < 1 || canvas.height < 1) throw new Error("Canvas must have positive dimensions.");
    },
    encode(encoder, camera, grid, gpuCamera, trace) {
      encode(encoder, camera, grid, trace, gpuCamera);
    },
    async render(camera) {
      renderer.validateCamera(camera);
      const trace = profiler?.begin("render", tick());
      device.pushErrorScope("validation");
      const encoder = device.createCommandEncoder();
      encode(encoder, camera, state().grid, trace);
      profiler?.resolve(encoder, trace);
      profiler?.mark(trace, "encodedAt");
      device.queue.submit([encoder.finish()]);
      profiler?.submitted(trace);
      const results = await Promise.allSettled([device.popErrorScope(), device.queue.onSubmittedWorkDone().then(() => profiler?.mark(trace, "queueCompletedAt"))]);
      for (const r of results) {
        if (r.status === "rejected") throw r.reason;
        if (r.value) throw new Error(r.value.message);
      }
      profiler?.mark(trace, "completedAt");
    },
    async inspectMesh() {
      if (closed) throw new Error("Terrain renderer is closed.");
      const meshBytes = chunks * 20 + count * 24, bytes = meshBytes + 12, read = buffer(bytes, GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ), e = device.createCommandEncoder();
      e.copyBufferToBuffer(args, 0, read, 0, chunks * 16);
      e.copyBufferToBuffer(rebuild, 0, read, chunks * 16, chunks * 4);
      e.copyBufferToBuffer(faces, 0, read, chunks * 20, count * 24);
      e.copyBufferToBuffer(dispatch, 0, read, meshBytes, 12);
      device.queue.submit([e.finish()]);
      try {
        await read.mapAsync(GPUMapMode.READ);
        const words = new Uint32Array(read.getMappedRange()), result = [];
        for (let k = 0; k < chunks; k++) result.push(Array.from(words.subarray(chunks * 5 + k * capacity, chunks * 5 + k * capacity + words[k * 4 + 1])).sort((a, b) => a - b));
        return { faces: result, rebuilt: Array.from(words.subarray(chunks * 4, chunks * 5)), meshDispatch: Array.from(words.subarray(meshBytes / 4, meshBytes / 4 + 3)) };
      } finally {
        if (read.mapState === "mapped") read.unmap();
        read.destroy();
      }
    },
    close() {
      if (closed) return;
      closed = true;
      natural?.close();
      depth?.destroy();
      faces.destroy();
      args.destroy();
      rebuild.destroy();
      uniform.destroy();
      work.destroy();
      dispatch.destroy();
      context.unconfigure();
      bindings.clear();
    }
  };
  return renderer;
}
function gameplayShader(shape, edge, sparse, rules, air) {
  const [w, h, d] = shape, active = Math.min(edge, 8), tiles = w * h * d / active ** 3;
  const thermal = VOLUME_SHADER.slice(VOLUME_SHADER.indexOf("fn prop("), VOLUME_SHADER.indexOf("fn phase("));
  return `
const SHAPE=vec3i(${w},${h},${d});const EDGE=${edge}u;const ACTIVE=${active}u;
const MAX_Q=0x3fffffffu;
@group(0) @binding(0) var<storage,read_write> cells:array<u32>;
@group(0) @binding(1) var<storage,read_write> energies:array<u32>;
@group(0) @binding(2) var<storage,read> cold:array<u32>;
// player[0..8], status[9], event flags[10], look[11..13], cache origin[14..16].
@group(0) @binding(3) var<storage,read_write> actor:array<i32>;
@group(0) @binding(4) var<storage,read_write> cache:array<u32>;
@group(0) @binding(5) var<storage,read_write> result:array<u32>;
struct Command {controls:vec4i,lookTick:vec4i,view:vec4i}
@group(0) @binding(6) var<uniform> command:Command;
@group(0) @binding(7) var<storage,read_write> dirty:array<atomic<u32>>;
${sparse ? "@group(0) @binding(8) var<storage,read_write> activity:array<atomic<u32>>;" : ""}
${thermal}
fn index(c:vec3i)->u32{let u=vec3u(c);let n=vec3u(SHAPE)/EDGE;let k=u/EDGE;let l=u%EDGE;return (k.x+n.x*(k.y+n.y*k.z))*EDGE*EDGE*EDGE+l.x+EDGE*(l.y+EDGE*l.z);}
// WGSL signed division truncates; voxel coordinates require mathematical floor.
fn floorQ(v:i32)->i32{return select((v-255)/256,v/256,v>=0);}
fn floorVector(v:vec3i)->vec3i{return vec3i(floorQ(v.x),floorQ(v.y),floorQ(v.z));}
fn origin()->vec3i{return vec3i(actor[14],actor[15],actor[16]);}
fn eye()->vec3i{return vec3i(actor[0],actor[1]-400,actor[2]);}
fn cachedCell(c:vec3i)->u32{
 if(any(c<vec3i(0))||any(c>=SHAPE)){return 1u;}
 let l=c-origin();if(any(l<vec3i(0))||any(l>=vec3i(16))){result[25]=1u;return 1u;}
 return cache[u32(l.x+16*(l.y+16*l.z))];
}
fn ray(look:vec3i)->vec4i{
 var previous=vec3i(-1000000);
 for(var n=0;n<=160;n++){
  let c=floorVector(eye()+look*n/32);if(all(c==previous)){continue;}previous=c;
  if(any(c<vec3i(0))||any(c>=SHAPE)||any(c<origin())||any(c>=origin()+vec3i(16))){return vec4i(0,0,0,-1);}
  let m=i32(cachedCell(c)&255u);if(m!=0&&m!=9){return vec4i(c,m);}
 }
 return vec4i(0,0,0,-1);
}
fn solid(v:u32)->bool{let p=(v>>24u)&15u;return p==0u||p==1u||p==6u;}
fn overlaps(p:vec3i)->bool{
 let lo=floorVector(p-vec3i(77,448,77));let hi=floorVector(p+vec3i(76,-1,76));
 for(var z=lo.z;z<=hi.z;z++){for(var y=lo.y;y<=hi.y;y++){for(var x=lo.x;x<=hi.x;x++){if(solid(cachedCell(vec3i(x,y,z)))){return true;}}}}
 return false;
}
fn position()->vec3i{return vec3i(actor[0],actor[1],actor[2]);}
fn sweep(axis:u32,velocity:i32)->bool{
 let direction=sign(velocity);var remaining=abs(velocity);
 // Speeds are bounded by 150 Q; retain the CPU's segmented sweep semantics.
 while(remaining>0){
  let distance=min(remaining,256);let start=actor[axis];actor[axis]=start+distance*direction;
  if(overlaps(position())){
   var low=0;var high=distance;
   while(low+1<high){let mid=(low+high)/2;actor[axis]=start+mid*direction;if(overlaps(position())){high=mid;}else{low=mid;}}
   actor[axis]=start+low*direction;return true;
  }
  remaining-=distance;
 }
 return false;
}
fn emit(kind:u32,count:u32,location:vec3i){
 let slot=result[14];if(slot>=4u){result[25]=2u;return;}let base=32u+slot*8u;
 result[base]=kind;result[base+1u]=u32(command.lookTick.w);result[base+2u]=count;
 result[base+3u]=u32(location.x);result[base+4u]=u32(location.y);result[base+5u]=u32(location.z);result[14]=slot+1u;
}
fn mark(c:vec3i){let n=vec3u(SHAPE)/EDGE;let k=vec3u(c)/EDGE;atomicStore(&dirty[k.x+n.x*(k.y+n.y*k.z)],1u);}
fn changed(c:vec3i){
 mark(c);for(var a=0u;a<3u;a++){for(var sign=-1;sign<=1;sign+=2){var t=c;t[a]+=sign;
  if(all(t>=vec3i(0))&&all(t<SHAPE)&&(u32(c[a])/EDGE!=u32(t[a])/EDGE)){mark(t);}
 }}
}
fn wakeEdit(c:vec3i){${sparse ? `
 let n=SHAPE/i32(ACTIVE);let k=c/i32(ACTIVE);let l=vec3u(c)%ACTIVE;
 let lo=-vec3i(select(vec3u(0),vec3u(1),l<vec3u(2)));let hi=vec3i(select(vec3u(0),vec3u(1),l+vec3u(2)>=vec3u(ACTIVE)));
 atomicStore(&activity[10],1u);
 for(var z=lo.z;z<=hi.z;z++){for(var y=lo.y;y<=hi.y;y++){for(var x=lo.x;x<=hi.x;x++){
  let t=k+vec3i(x,y,z);if(all(t>=vec3i(0))&&all(t<n)){let j=u32(t.x+n.x*(t.y+n.y*t.z));atomicStore(&activity[16u+j],1u);atomicOr(&activity[${16 + 3 * tiles}u+j],16u);}
 }}}
 ` : ""}}
fn beginFrame(){for(var k=0u;k<128u;k++){result[k]=0u;}if(actor[7]>0){actor[7]--;}}
// A known no-tool command must not acquire write access to the terrain or activity buffers.
@compute @workgroup_size(1) fn noTools(){beginFrame();}
@compute @workgroup_size(1) fn tools(){
 beginFrame();
 if(command.controls.w==0||actor[7]!=0||actor[9]==2){return;}
 let hit=ray(command.lookTick.xyz);if(hit.w<0){return;}
 var count=0u;
 for(var z=hit.z-1;z<=hit.z+1;z++){for(var y=hit.y-1;y<=hit.y+1;y++){for(var x=hit.x-1;x<=hit.x+1;x++){
  let c=vec3i(x,y,z);if(any(c<vec3i(1))||x>=SHAPE.x-1||z>=SHAPE.z-1||y>=${rules.toolCeiling}){continue;}
  let m=cachedCell(c)&255u;let carve=command.controls.w==1&&(m==${MAT.STONE}u||m==${MAT.GLASS}u||m==${MAT.SAND}u||m==${MAT.ICE}u);
  let freeze=command.controls.w==2&&(m==${MAT.WATER}u||m==${MAT.ICE}u);if(!carve&&!freeze){continue;}
  let i=index(c);let old=energies[i];var q=0u;
  if(carve){cells[i]=${air[0]}u;q=${air[1]}u;changed(c);}else{cells[i]=thermal(cells[i],0u);}
  energies[i]=q;result[64u+count*2u]=old;result[65u+count*2u]=q;count++;wakeEdit(c);
 }}}
 result[15]=count;
 if(count>0u){actor[7]=6;if(command.controls.w==1){actor[10]|=1;}emit(u32(command.controls.w),count,hit.xyz);}
}
@compute @workgroup_size(64) fn cacheRegion(@builtin(global_invocation_id) id:vec3u){
 if(id.x>=4096u){return;}
 // Every lane derives the same origin from immutable position coordinates.
 // Only lane zero stores metadata; no lane reads it during this dispatch.
 let o=clamp(floorVector(position()-vec3i(0,224,0))-vec3i(8),vec3i(0),SHAPE-vec3i(16));
 if(id.x==0u){actor[14]=o.x;actor[15]=o.y;actor[16]=o.z;}
 let c=o+vec3i(i32(id.x%16u),i32((id.x/16u)%16u),i32(id.x/256u));cache[id.x]=cells[index(c)];
}
fn output(){
 for(var k=0u;k<14u;k++){result[k]=bitcast<u32>(actor[k]);}
 let e=vec3f(eye())/256.0;result[16]=bitcast<u32>(e.x);result[17]=bitcast<u32>(e.y);result[18]=bitcast<u32>(e.z);result[19]=0u;
 let hit=ray(command.view.xyz);result[20]=0xffffffffu;
 if(hit.w>=0){result[20]=u32(hit.x+SHAPE.x*(hit.y+SHAPE.y*hit.z));result[21]=u32(hit.w);result[22]=u32(hit.x);result[23]=u32(hit.y);result[24]=u32(hit.z);}
}
@compute @workgroup_size(1) fn locomotion(){
 actor[11]=command.lookTick.x;actor[12]=command.lookTick.y;actor[13]=command.lookTick.z;
 if(actor[9]!=2){
  if(overlaps(position())){
   var freed=false;for(var d=1;d<=3;d++){if(!overlaps(position()-vec3i(0,d*256,0))){actor[1]-=d*256;actor[3]=0;freed=true;break;}}
   if(!freed){actor[9]=2;emit(3u,0u,vec3i(0));}
  }
  if(actor[9]!=2){
   let wet=(cachedCell(floorVector(position()-vec3i(0,128,0)))&255u)==2u;actor[5]=i32(wet);
   if(command.controls.z!=0&&((actor[4]!=0&&actor[6]==0)||wet)){actor[3]=select(-115,-65,wet);}
   actor[3]=min(select(150,45,wet),actor[3]+select(8,4,wet));let speed=select(48,28,wet);
   let blockedX=sweep(0u,command.controls.x*speed/256);let blockedZ=sweep(2u,command.controls.y*speed/256);actor[8]=i32(blockedX||blockedZ);
   let hit=sweep(1u,actor[3]);let falling=actor[3]>0;if(hit){actor[3]=0;}
   actor[4]=i32((hit&&falling)||overlaps(position()+vec3i(0,1,0)));
   let under=cachedCell(floorVector(position()))&255u;
   if(actor[4]!=0&&under==${MAT.ICE}u&&(actor[10]&2)==0){actor[10]|=2;emit(4u,0u,vec3i(0));}
   if(actor[9]==0&&actor[0]>=${rules.goal.minX}&&actor[1]<=${rules.goal.maxY}&&actor[2]>=${rules.goal.minZ}&&actor[2]<=${rules.goal.maxZ}&&(actor[10]&3)==3){actor[9]=1;emit(5u,0u,vec3i(0));}
   if(actor[1]>${rules.fallY}){actor[9]=2;emit(6u,0u,vec3i(0));}
  }
 }
 actor[6]=command.controls.z;output();
}
@compute @workgroup_size(1) fn present(){for(var k=0u;k<128u;k++){result[k]=0u;}output();}
`;
}
const statuses = ["playing", "won", "lost"];
const tools = ["none", "carve", "freeze"];
function look(v) {
  if (!Array.isArray(v) || v.length !== 3) throw new Error("Invalid gameplay look.");
  const owned = [v[0], v[1], v[2]];
  for (const n of owned) checkedInteger(n, -256, 256, "look");
  const length = owned.reduce((s, n) => s + n * n, 0);
  if (length < 250 ** 2 || length > 262 ** 2) throw new Error("Invalid gameplay look length.");
  return owned;
}
function checkedGameplayState(state, shape) {
  if (!state || Object.keys(state).sort().join(",") !== "carved,iceWalk,look,player,status") throw new Error("Invalid gameplay state.");
  const p = state.player;
  if (!p || Object.keys(p).sort().join(",") !== "blocked,cooldown,grounded,jumpHeld,vy,wet,x,y,z") throw new Error("Invalid gameplay player.");
  checkedInteger(p.x, 77, shape[0] * 256 - 77, "player x");
  checkedInteger(p.y, 448, shape[1] * 256, "player y");
  checkedInteger(p.z, 77, shape[2] * 256 - 77, "player z");
  checkedInteger(p.vy, -150, 150, "player velocity");
  checkedInteger(p.cooldown, 0, 6, "cooldown");
  for (const v of [p.grounded, p.wet, p.jumpHeld, p.blocked, state.carved, state.iceWalk]) if (typeof v !== "boolean") throw new Error("Invalid gameplay flag.");
  if (!statuses.includes(state.status)) throw new Error("Invalid gameplay status.");
  return { player: { ...p }, look: look(state.look), status: state.status, carved: state.carved, iceWalk: state.iceWalk };
}
function checkedGameplayRules(rules, shape) {
  if (!rules || Object.keys(rules).sort().join(",") !== "fallY,goal,toolCeiling" || !rules.goal || Object.keys(rules.goal).sort().join(",") !== "maxY,maxZ,minX,minZ") throw new Error("Invalid gameplay rules.");
  const g = rules.goal;
  checkedInteger(g.minX, 0, shape[0] * 256, "goal x");
  checkedInteger(g.maxY, 0, shape[1] * 256, "goal y");
  checkedInteger(g.minZ, 0, shape[2] * 256, "goal z");
  checkedInteger(g.maxZ, g.minZ, shape[2] * 256, "goal max z");
  checkedInteger(rules.fallY, 448, shape[1] * 256, "fall threshold");
  checkedInteger(rules.toolCeiling, 1, shape[1] - 1, "tool ceiling");
  return { ...rules, goal: { ...g } };
}
function checkedGameplayCommand(c, tick) {
  if (!c || Object.keys(c).sort().join(",") !== "jump,look,moveX,moveZ,tick,tool") throw new Error("Invalid gameplay command.");
  checkedInteger(c.tick, tick, tick, "command tick");
  checkedInteger(c.tick, 1, 7200, "gameplay tick");
  checkedInteger(c.moveX, -256, 256, "moveX");
  checkedInteger(c.moveZ, -256, 256, "moveZ");
  if (c.moveX ** 2 + c.moveZ ** 2 > 257 ** 2 || typeof c.jump !== "boolean" || !tools.includes(c.tool)) throw new Error("Invalid gameplay input.");
  return { ...c, look: look(c.look) };
}
async function makeGameplayResources(device, shape, edge, cold2, dirty, activity, rules, profiler) {
  const seed = createStateSpaceField3D(1, 1, 1).snapshot();
  const module = device.createShaderModule({ code: gameplayShader(shape, edge, Boolean(activity), rules, [seed.packedCells[0], seed.energyQ[0]]) });
  const errors = (await module.getCompilationInfo()).messages.filter((m) => m.type === "error");
  if (errors.length) throw new Error(errors.map((m) => `${m.lineNum}: ${m.message}`).join("\n"));
  const pipelines = {};
  for (const entryPoint of ["tools", "noTools", "cacheRegion", "locomotion", "present"]) pipelines[entryPoint] = await device.createComputePipelineAsync({ layout: "auto", compute: { module, entryPoint } });
  const buffers = [];
  const buffer = (size, usage) => {
    const b = device.createBuffer({ size, usage });
    buffers.push(b);
    return b;
  };
  const storage2 = GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC;
  const actor = buffer(128, storage2), cache = buffer(4096 * 4, storage2), result = buffer(512, storage2), read = buffer(512, GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ), uniform = buffer(48, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST);
  const params = new Int32Array(12), groups = /* @__PURE__ */ new Map();
  function bindings(grid, energy) {
    let g = groups.get(grid);
    if (g) return g;
    g = {};
    const resources = [grid, energy, cold2, actor, cache, result, uniform, dirty, activity];
    const entries = { tools: [0, 1, 2, 3, 4, 5, 6, 7, ...activity ? [8] : []], noTools: [3, 5], cacheRegion: [0, 3, 4], locomotion: [3, 4, 5, 6], present: [3, 4, 5, 6] };
    for (const name of Object.keys(pipelines)) g[name] = device.createBindGroup({ layout: pipelines[name].getBindGroupLayout(0), entries: entries[name].map((binding) => ({ binding, resource: { buffer: resources[binding] } })) });
    groups.set(grid, g);
    return g;
  }
  function dispatch(encoder, name, grid, energy, count = 1, trace, label = name) {
    const pass = encoder.beginComputePass(profiler.pass(trace, label));
    pass.setPipeline(pipelines[name]);
    pass.setBindGroup(0, bindings(grid, energy)[name]);
    pass.dispatchWorkgroups(count);
    pass.end();
  }
  return {
    result,
    read,
    writeState(s) {
      const p = s.player, a = new Int32Array(32);
      a.set([p.x, p.y, p.z, p.vy, +p.grounded, +p.wet, +p.jumpHeld, p.cooldown, +p.blocked, statuses.indexOf(s.status), +s.carved | +s.iceWalk << 1, ...s.look]);
      device.queue.writeBuffer(actor, 0, a);
    },
    prepare(c, view = c.look) {
      const v = look(view);
      params.set([c.moveX, c.moveZ, +c.jump, tools.indexOf(c.tool), ...c.look, c.tick, ...v, 0]);
      device.queue.writeBuffer(uniform, 0, params);
    },
    initialize(e, grid, energy) {
      dispatch(e, "cacheRegion", grid, energy, 64);
    },
    tools(e, grid, energy, canEdit, trace) {
      dispatch(e, canEdit ? "tools" : "noTools", grid, energy, 1, trace, "tools");
    },
    controller(e, grid, energy, trace) {
      dispatch(e, "cacheRegion", grid, energy, 64, trace, "collisionCache");
      dispatch(e, "locomotion", grid, energy, 1, trace, "controller");
    },
    present(e, grid, energy, trace) {
      dispatch(e, "present", grid, energy, 1, trace, "controller");
    },
    decode(words, tick) {
      if (words[25] || words[14] > 4 || words[15] > 27) throw new Error(`GPU gameplay rejected its bounded neighborhood (${words[25]}).`);
      const signed = new Int32Array(words.buffer, words.byteOffset, words.length), types = ["carved", "cooled", "trapped", "ice-walk", "crossed", "fell"];
      const state = checkedGameplayState({ player: { x: signed[0], y: signed[1], z: signed[2], vy: signed[3], grounded: Boolean(words[4]), wet: Boolean(words[5]), jumpHeld: Boolean(words[6]), cooldown: words[7], blocked: Boolean(words[8]) }, status: statuses[words[9]], carved: Boolean(words[10] & 1), iceWalk: Boolean(words[10] & 2), look: [signed[11], signed[12], signed[13]] }, shape);
      const events = [];
      for (let i = 0; i < words[14]; i++) {
        const b = 32 + i * 8, type = types[words[b] - 1];
        if (!type || words[b + 1] !== tick) throw new Error("Invalid GPU gameplay event.");
        events.push({ tick, type, ...words[b] <= 2 ? { cells: words[b + 2], target: [words[b + 3], words[b + 4], words[b + 5]] } : {} });
      }
      return { ...state, tick, events, target: words[20] === 4294967295 ? null : { cell: [words[22], words[23], words[24]], material: words[21] }, submissions: 1, completionBoundaries: 1, actorReadbackBytes: 512 };
    },
    close() {
      for (const b of buffers) b.destroy();
      groups.clear();
    }
  };
}
class LatencyProfiler {
  enabled;
  gpuTimestamps;
  gpuTimingRequested;
  #slots = [];
  #records = [];
  #pending = /* @__PURE__ */ new Set();
  #next = 0;
  constructor(device, enabled = false, gpuTiming = false) {
    this.enabled = enabled;
    this.gpuTimingRequested = enabled && gpuTiming;
    this.gpuTimestamps = this.gpuTimingRequested && device.features.has("timestamp-query");
    if (this.gpuTimestamps) for (let i = 0; i < 3; i++) this.#slots.push({
      query: device.createQuerySet({ type: "timestamp", count: 16 }),
      resolve: device.createBuffer({ size: 256, usage: GPUBufferUsage.QUERY_RESOLVE | GPUBufferUsage.COPY_SRC }),
      read: device.createBuffer({ size: 256, usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ }),
      busy: false
    });
  }
  begin(kind, tick) {
    if (!this.enabled) return;
    const slot = this.#slots.find((s) => !s.busy);
    if (slot) slot.busy = true;
    const record = {
      id: ++this.#next,
      kind,
      tick,
      cpu: { startedAt: performance.now() },
      gpu: { status: slot ? "pending" : this.gpuTimestamps ? "busy" : this.gpuTimingRequested ? "unsupported" : "disabled", ms: {} }
    };
    this.#records.push(record);
    if (this.#records.length > 32) this.#records.shift();
    return { record, slot, labels: [] };
  }
  mark(trace, name) {
    if (trace) trace.record.cpu[name] = performance.now();
  }
  pass(trace, label) {
    if (!trace?.slot) return {};
    if (trace.labels.length >= 8) throw new Error("Latency query capacity exceeded.");
    const index = trace.labels.length * 2;
    trace.labels.push(label);
    return { timestampWrites: { querySet: trace.slot.query, beginningOfPassWriteIndex: index, endOfPassWriteIndex: index + 1 } };
  }
  resolve(encoder, trace) {
    if (!trace?.slot || !trace.labels.length) return;
    encoder.resolveQuerySet(trace.slot.query, 0, trace.labels.length * 2, trace.slot.resolve, 0);
    encoder.copyBufferToBuffer(trace.slot.resolve, 0, trace.slot.read, 0, trace.labels.length * 16);
  }
  submitted(trace) {
    this.mark(trace, "submittedAt");
    if (!trace?.slot) return;
    const slot = trace.slot;
    if (!trace.labels.length) {
      slot.busy = false;
      trace.record.gpu.status = "complete";
      return;
    }
    const pending = slot.read.mapAsync(GPUMapMode.READ, 0, trace.labels.length * 16).then(() => {
      const times = new BigUint64Array(slot.read.getMappedRange(0, trace.labels.length * 16));
      for (let i = 0; i < trace.labels.length; i++) {
        if (times[i * 2 + 1] < times[i * 2]) throw new Error("Non-monotonic GPU timestamps.");
        trace.record.gpu.ms[trace.labels[i]] = Number(times[i * 2 + 1] - times[i * 2]) / 1e6;
      }
      trace.record.gpu.status = "complete";
    }).catch((error) => {
      trace.record.gpu.status = "error";
      trace.record.gpu.error = String(error);
    }).finally(() => {
      if (slot.read.mapState === "mapped") slot.read.unmap();
      slot.busy = false;
      this.#pending.delete(pending);
    });
    this.#pending.add(pending);
  }
  snapshot(afterId = 0) {
    if (!Number.isSafeInteger(afterId) || afterId < 0) throw new Error("Invalid latency cursor.");
    return {
      enabled: this.enabled,
      gpuTimingRequested: this.gpuTimingRequested,
      gpuTimestamps: this.gpuTimestamps,
      capacity: 32,
      records: this.#records.filter((r) => r.id > afterId).map((r) => ({ ...r, cpu: { ...r.cpu }, gpu: { ...r.gpu, ms: { ...r.gpu.ms } } }))
    };
  }
  /** For receipt finalization only, after the measured loop has stopped. */
  async settle() {
    await Promise.all(this.#pending);
  }
  close() {
    for (const s of this.#slots) {
      s.query.destroy();
      s.resolve.destroy();
      s.read.destroy();
    }
  }
}
const EMPTY_EDITS = new Uint32Array(0);
const KINDS = ["gravity", "diagonal", "liquid", "buoyancy", "gas", "heat", "phase"];
const total = (values) => {
  let sum = 0;
  for (let i = 0; i < values.length; i++) sum += values[i];
  return BigInt(sum);
};
const storage = () => GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST;
async function compile(device, code) {
  const module = device.createShaderModule({ code });
  const info = await module.getCompilationInfo(), errors = info.messages.filter((m) => m.type === "error");
  if (errors.length) throw new Error(errors.map((m) => `${m.lineNum}:${m.linePos} ${m.message}`).join("\n"));
  return module;
}
class ResidentVolume {
  width;
  height;
  depth;
  backendInfo;
  #device;
  #pipeline;
  #edit;
  #query;
  #buffers = [];
  #cells;
  #energy;
  #cold;
  #uniform;
  #slots = 29;
  #groups = [];
  #current = 0;
  #editData;
  #editResult;
  #editRead;
  #queryResult;
  #queryRead;
  #fullRead;
  #tick = 0;
  #initial;
  #external = 0n;
  #busy = false;
  #fault = "";
  #closed = false;
  #renderers = [];
  #worldRenderer = false;
  #config;
  #dirty;
  #activity;
  #activityRead;
  #indirect = [];
  #activeEdge = 0;
  #stageGroups = {};
  #stages;
  #lastTicks = 0;
  #activityCache;
  #activityZeros = new Uint32Array(0);
  #profiler;
  #params = new Uint32Array(29 * 64);
  #queryGroups = [];
  #editGroups = [];
  #revision = 0;
  #gameplay;
  #chunkRenderers = /* @__PURE__ */ new Map();
  constructor(w, h, d, initial, device, pipeline, edit, query, info, config, stages) {
    this.#profiler = new LatencyProfiler(device, config.profiling, config.gpuTiming);
    this.#config = config;
    this.width = w;
    this.height = h;
    this.depth = d;
    this.#device = device;
    this.backendInfo = Object.freeze(info);
    for (const key of ["width", "height", "depth", "backendInfo"]) Object.defineProperty(this, key, { writable: false, configurable: false });
    this.#pipeline = pipeline;
    this.#edit = edit;
    this.#query = query;
    this.#stages = stages;
    const bytes = w * h * d * 4;
    const buffer = (size, usage) => {
      const b = device.createBuffer({ size, usage });
      this.#buffers.push(b);
      return b;
    };
    this.#cells = [buffer(bytes, storage()), buffer(bytes, storage())];
    this.#energy = [buffer(bytes, storage()), buffer(bytes, storage())];
    this.#dirty = buffer(Math.max(1, config.chunkSize ? w * h * d / config.chunkSize ** 3 : 1) * 4, storage());
    this.#invalidate();
    if (config.sparse) {
      this.#activeEdge = Math.min(config.chunkSize, 8);
      const chunks = w * h * d / this.#activeEdge ** 3;
      this.#activityZeros = new Uint32Array(chunks);
      this.#activity = buffer((16 + 4 * chunks) * 4, storage());
      this.#indirect = [buffer(12, storage() | GPUBufferUsage.INDIRECT), buffer(12, storage() | GPUBufferUsage.INDIRECT)];
      this.#activityRead = buffer((16 + 4 * chunks) * 4 + this.#dirty.size, GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ);
      this.#wakeAll();
      this.#stageGroups.collectWork = device.createBindGroup({ layout: stages.collectWork.getBindGroupLayout(0), entries: [{ binding: 7, resource: { buffer: this.#activity } }, { binding: 8, resource: { buffer: this.#indirect[0] } }, { binding: 9, resource: { buffer: this.#indirect[1] } }] });
    }
    const cold2 = buildColdTable();
    this.#cold = buffer(cold2.byteLength, storage());
    device.queue.writeBuffer(this.#cold, 0, cold2);
    this.#uniform = buffer(this.#slots * 256, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST);
    this.#editData = buffer(64 * 16, storage());
    this.#editResult = buffer(64 * 8, storage());
    this.#editRead = buffer(64 * 8, GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ);
    this.#queryResult = buffer(4096 * 4, storage());
    this.#queryRead = buffer(4096 * 4, GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ);
    this.#fullRead = buffer(bytes * 2, GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ);
    this.#initial = total(initial.energyQ);
    device.queue.writeBuffer(this.#cells[0], 0, this.#pack(initial.packedCells));
    device.queue.writeBuffer(this.#energy[0], 0, this.#pack(initial.energyQ));
    if (config.sparse) {
      device.queue.writeBuffer(this.#cells[1], 0, this.#pack(initial.packedCells));
      device.queue.writeBuffer(this.#energy[1], 0, this.#pack(initial.energyQ));
    }
    this.#bind();
    device.addEventListener("uncapturederror", (event) => {
      this.#fault = event.error.message;
    });
    void device.lost.then((info2) => {
      this.#fault = info2.message || info2.reason;
    });
  }
  #address(x, y, z) {
    const e = this.#config.chunkSize, w = this.width, h = this.height;
    return e ? (Math.floor(x / e) + w / e * (Math.floor(y / e) + h / e * Math.floor(z / e))) * e ** 3 + x % e + e * (y % e + e * (z % e)) : x + w * (y + h * z);
  }
  #pack(source) {
    const out = new Uint32Array(source.length);
    let i = 0;
    for (let z = 0; z < this.depth; z++) for (let y = 0; y < this.height; y++) for (let x = 0; x < this.width; x++) out[this.#address(x, y, z)] = source[i++];
    return out;
  }
  #unpack(source) {
    const out = new Uint32Array(source.length);
    let i = 0;
    for (let z = 0; z < this.depth; z++) for (let y = 0; y < this.height; y++) for (let x = 0; x < this.width; x++) out[i++] = source[this.#address(x, y, z)];
    return out;
  }
  #invalidateEdits(edits) {
    const e = this.#config.chunkSize;
    if (!e) return;
    const n = [this.width / e, this.height / e, this.depth / e], seen = /* @__PURE__ */ new Set();
    for (let i = 0; i < edits.length; i += 4) {
      if (edits[i + 1] === 1) continue;
      const k = Math.floor(edits[i] / e ** 3), l = edits[i] % e ** 3;
      const c = [k % n[0], Math.floor(k / n[0]) % n[1], Math.floor(k / (n[0] * n[1]))], local = [l % e, Math.floor(l / e) % e, Math.floor(l / e ** 2)];
      seen.add(k);
      for (let a = 0; a < 3; a++) for (const sign of [-1, 1]) if ((sign < 0 ? local[a] === 0 : local[a] === e - 1) && c[a] + sign >= 0 && c[a] + sign < n[a]) {
        const other = [...c];
        other[a] += sign;
        seen.add(other[0] + n[0] * (other[1] + n[1] * other[2]));
      }
    }
    for (const k of seen) this.#device.queue.writeBuffer(this.#dirty, k * 4, new Uint32Array([1]));
  }
  #wakeAll() {
    if (!this.#activity) return;
    const n = (this.#activity.size / 4 - 16) / 4;
    this.#device.queue.writeBuffer(this.#activity, 16 * 4, new Uint32Array(n).fill(1));
    this.#device.queue.writeBuffer(this.#activity, (16 + n) * 4, new Uint32Array(n).fill(2));
    this.#device.queue.writeBuffer(this.#activity, 40, new Uint32Array([1]));
    this.#device.queue.writeBuffer(this.#activity, (16 + 3 * n) * 4, new Uint32Array(n).fill(32));
  }
  #wakeEdits(edits) {
    if (!this.#activity) return;
    const e = this.#activeEdge, b = this.#config.chunkSize, bn = [this.width / b, this.height / b, this.depth / b], n = [this.width / e, this.height / e, this.depth / e], count = n[0] * n[1] * n[2], seen = /* @__PURE__ */ new Set();
    for (let i = 0; i < edits.length; i += 4) {
      const k = Math.floor(edits[i] / b ** 3), l = edits[i] % b ** 3, g = [k % bn[0] * b + l % b, Math.floor(k / bn[0]) % bn[1] * b + Math.floor(l / b) % b, Math.floor(k / (bn[0] * bn[1])) * b + Math.floor(l / b ** 2)], c = g.map((v) => Math.floor(v / e)), local = g.map((v) => v % e);
      for (let z = local[2] < 2 ? -1 : 0; z <= (local[2] >= e - 2 ? 1 : 0); z++) for (let y = local[1] < 2 ? -1 : 0; y <= (local[1] >= e - 2 ? 1 : 0); y++) for (let x = local[0] < 2 ? -1 : 0; x <= (local[0] >= e - 2 ? 1 : 0); x++) {
        const t = [c[0] + x, c[1] + y, c[2] + z];
        if (t.every((v, a) => v >= 0 && v < n[a])) seen.add(t[0] + n[0] * (t[1] + n[1] * t[2]));
      }
    }
    if (seen.size) this.#device.queue.writeBuffer(this.#activity, 40, new Uint32Array([1]));
    for (const k of seen) {
      this.#device.queue.writeBuffer(this.#activity, (16 + k) * 4, new Uint32Array([1]));
      this.#device.queue.writeBuffer(this.#activity, (16 + 3 * count + k) * 4, new Uint32Array([16]));
    }
  }
  #invalidate() {
    this.#device.queue.writeBuffer(this.#dirty, 0, new Uint32Array(this.#dirty.size / 4).fill(1));
  }
  get tick() {
    return this.#tick;
  }
  async prepareActivity() {
    if (!this.#activity) return;
    const params = this.#parameters(1);
    this.#shape(params, 0);
    this.#device.queue.writeBuffer(this.#uniform, 0, params);
    this.#device.pushErrorScope("validation");
    const e = this.#device.createCommandEncoder(), pass = e.beginComputePass();
    pass.setPipeline(this.#stages.collectWork);
    pass.setBindGroup(0, this.#stageGroups.collectWork);
    pass.dispatchWorkgroups(1);
    pass.setPipeline(this.#stages.certify);
    pass.setBindGroup(0, this.#groups[0], [0]);
    pass.dispatchWorkgroupsIndirect(this.#indirect[0], 0);
    pass.setPipeline(this.#stages.commitCert);
    pass.dispatchWorkgroups(Math.ceil(this.width * this.height * this.depth / this.#activeEdge ** 3 / 64));
    pass.end();
    await this.#finish(e);
    this.#device.queue.writeBuffer(this.#activity, 16, new Uint32Array(6));
    await this.#device.queue.onSubmittedWorkDone();
  }
  #available() {
    if (this.#closed || this.#fault || this.#busy) throw new Error(this.#closed ? "3D GPU field is closed." : this.#fault || "3D GPU field has an operation in flight.");
  }
  async #run(operation) {
    this.#available();
    this.#busy = true;
    try {
      return await operation();
    } finally {
      this.#busy = false;
    }
  }
  #bind() {
    this.#groups = [0, 1].map((i) => this.#device.createBindGroup({ layout: this.#pipeline.getBindGroupLayout(0), entries: [this.#cells[i], this.#energy[i], this.#cells[1 - i], this.#energy[1 - i], this.#cold, this.#uniform, this.#dirty, ...this.#activity ? [this.#activity, this.#indirect[1 - i]] : []].map((buffer, binding) => ({ binding, resource: { buffer, ...binding === 5 ? { size: 48 } : {} } })) }));
    this.#queryGroups = [0, 1].map((i) => this.#device.createBindGroup({ layout: this.#query.getBindGroupLayout(0), entries: [
      { binding: 0, resource: { buffer: this.#cells[i] } },
      { binding: 5, resource: { buffer: this.#uniform, offset: 256, size: 48 } },
      { binding: 7, resource: { buffer: this.#queryResult } }
    ] }));
    this.#editGroups = [0, 1].map((i) => this.#device.createBindGroup({ layout: this.#edit.getBindGroupLayout(0), entries: [
      [2, this.#cells[i]],
      [3, this.#energy[i]],
      [4, this.#cold],
      [5, this.#uniform],
      [6, this.#editData],
      [7, this.#editResult]
    ].map(([binding, buffer]) => ({ binding, resource: { buffer, ...binding === 5 ? { offset: 0, size: 48 } : {} } })) }));
  }
  inspectLatency(afterId = 0) {
    return this.#profiler.snapshot(afterId);
  }
  settleLatency() {
    return this.#profiler.settle();
  }
  #parameters(slots) {
    if (slots > this.#slots) {
      this.#uniform.destroy();
      this.#slots = slots;
      this.#uniform = this.#device.createBuffer({ size: slots * 256, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
      this.#buffers.push(this.#uniform);
      this.#params = new Uint32Array(slots * 64);
      this.#bind();
    }
    this.#params.fill(0, 0, slots * 64);
    return this.#params.subarray(0, slots * 64);
  }
  #shape(params, slot) {
    params.set([this.width, this.height, this.depth, this.width * this.height * this.depth], slot * 64);
  }
  #region(region) {
    if (region === void 0) return;
    if (!region || !Array.isArray(region.origin) || !Array.isArray(region.size) || region.origin.length !== 3 || region.size.length !== 3) throw new Error("Region needs three origin and size coordinates.");
    const shape = [this.width, this.height, this.depth], origin = [], size = [];
    for (let i = 0; i < 3; i++) {
      size.push(checkedInteger(region.size[i], 1, shape[i], "region size"));
      origin.push(checkedInteger(region.origin[i], 0, shape[i] - size[i], "region origin"));
    }
    checkedInteger(size[0] * size[1] * size[2], 1, 4096, "region cell count");
    return { origin, size };
  }
  #edits(edits = []) {
    if (!Array.isArray(edits)) throw new Error("A commit supports at most 64 unique cell edits.");
    const count = checkedInteger(edits.length, 0, 64, "edit count");
    if (count === 0) return EMPTY_EDITS;
    const seen = /* @__PURE__ */ new Set(), data = new Uint32Array(count * 4);
    let seed;
    for (let k = 0; k < count; k++) {
      const e = edits[k];
      if (!e || typeof e !== "object") throw new Error("Invalid volume edit.");
      checkedInteger(e.x, 0, this.width - 1, "x");
      checkedInteger(e.y, 0, this.height - 1, "y");
      checkedInteger(e.z, 0, this.depth - 1, "z");
      const i = e.x + this.width * (e.y + this.height * e.z);
      if (seen.has(i)) throw new Error("Duplicate edit coordinate.");
      seen.add(i);
      const keys = Object.keys(e).sort().join(",");
      if ("material" in e) {
        if (!["material,x,y,z", "material,thermal,x,y,z"].includes(keys)) throw new Error("Unknown placement edit field.");
        seed ??= this.#config.cpu(1, 1, 1);
        seed.setCell(0, 0, 0, e.material, e.thermal);
        const s = seed.sample(0, 0, 0);
        data.set([this.#address(e.x, e.y, e.z), 0, seed.grid[0], s.energyQ], k * 4);
      } else {
        if (keys !== "energyQ,x,y,z") throw new Error("Unknown energy edit field.");
        checkedInteger(e.energyQ, 0, MAX_ENERGY_Q, "energyQ");
        data.set([this.#address(e.x, e.y, e.z), 1, 0, e.energyQ], k * 4);
      }
    }
    return data;
  }
  async #finish(encoder, reads = [], trace) {
    this.#profiler.resolve(encoder, trace);
    this.#profiler.mark(trace, "encodedAt");
    this.#device.queue.submit([encoder.finish()]);
    this.#profiler.submitted(trace);
    const validation = this.#device.popErrorScope().then((error) => {
      this.#profiler.mark(trace, "validationCompletedAt");
      return error;
    });
    const mappings = Promise.allSettled(reads.map((r) => r.buffer.mapAsync(GPUMapMode.READ, 0, r.bytes))).then((results2) => {
      this.#profiler.mark(trace, "readbacksReadyAt");
      for (const r of results2) if (r.status === "rejected") throw r.reason;
    });
    const results = await Promise.allSettled([validation, this.#device.queue.onSubmittedWorkDone().then(() => this.#profiler.mark(trace, "queueCompletedAt")), mappings]);
    try {
      const failed = results.find((r) => r.status === "rejected");
      if (failed?.status === "rejected") throw failed.reason;
      const error = results[0].status === "fulfilled" && results[0].value;
      if (error) throw new Error(error.message);
      if (this.#fault) throw new Error(this.#fault);
      return reads.map((r) => new Uint32Array(r.buffer.getMappedRange(0, r.bytes).slice(0)));
    } catch (error) {
      this.#fault = String(error);
      throw error;
    } finally {
      reads.forEach((r) => {
        if (r.buffer.mapState === "mapped") r.buffer.unmap();
      });
    }
  }
  #encodePhysics(encoder, slot, current, trace) {
    const compute = encoder.beginComputePass(this.#profiler.pass(trace, "physicsPlanningAndCertification"));
    const chunks = this.width * this.height * this.depth / (this.#activeEdge || this.#config.chunkSize || 1) ** 3;
    const stage = (name, groups) => {
      compute.setPipeline(this.#stages[name]);
      if (this.#stageGroups[name]) compute.setBindGroup(0, this.#stageGroups[name]);
      compute.dispatchWorkgroups(groups);
    };
    for (let s = 2; s < slot; s++) {
      compute.setBindGroup(0, this.#groups[current], [s * 256]);
      if (this.#activity && (s - 2) % 27 === 0) stage("collectWork", 1);
      compute.setPipeline(this.#pipeline);
      compute.setBindGroup(0, this.#groups[current], [s * 256]);
      if (this.#activity) compute.dispatchWorkgroupsIndirect(this.#indirect[current], 0);
      else compute.dispatchWorkgroups(Math.ceil(this.width * this.height * this.depth / 64));
      current = 1 - current;
      if (this.#activity && (s - 1) % 27 === 0) {
        compute.setBindGroup(0, this.#groups[current], [0]);
        compute.setPipeline(this.#stages.certify);
        compute.dispatchWorkgroupsIndirect(this.#indirect[current], 0);
        stage("commitCert", Math.ceil(chunks / 64));
      }
    }
    compute.end();
    return current;
  }
  async step(ticks = 1, options = {}) {
    checkedInteger(ticks, 0, 1024, "ticks per request");
    checkedInteger(this.#tick + ticks, 0, Number.MAX_SAFE_INTEGER, "end tick");
    if (!options || typeof options !== "object" || Array.isArray(options) || Object.keys(options).some((k) => k !== "edits" && k !== "region")) throw new Error("Invalid GPU step options.");
    const region = this.#region(options.region), edits = this.#edits(options.edits);
    return this.#run(async () => {
      const trace = this.#profiler.begin("step", this.#tick + ticks);
      if (ticks || edits.length) this.#activityCache = void 0;
      const params = this.#parameters(ticks * 27 + 2);
      this.#shape(params, 0);
      params[9] = edits.length / 4;
      if (region) {
        this.#shape(params, 1);
        params.set(region.size, 68);
        params.set(region.origin, 72);
      }
      let slot = 2;
      for (let t = 0; t < ticks; t++) for (const pass of volumeSchedule(this.#tick + t)) {
        this.#shape(params, slot);
        params.set([KINDS.indexOf(pass.kind), pass.axis, pass.parity, pass.direction >>> 0, this.#tick + t >>> 0], slot * 64 + 4);
        slot++;
      }
      this.#device.queue.writeBuffer(this.#uniform, 0, params);
      if (this.#activity && ticks && edits.length) this.#device.queue.writeBuffer(this.#activity, (16 + 3 * this.#activityZeros.length) * 4, this.#activityZeros);
      if (edits.length) {
        this.#device.queue.writeBuffer(this.#editData, 0, edits);
        this.#invalidateEdits(edits);
        this.#wakeEdits(edits);
      }
      this.#profiler.mark(trace, "preparedAt");
      this.#device.pushErrorScope("validation");
      const encoder = this.#device.createCommandEncoder();
      if (this.#activity && ticks) {
        encoder.clearBuffer(this.#activity, 16, 24);
        if (!edits.length) encoder.clearBuffer(this.#activity, (16 + 3 * this.#activityZeros.length) * 4, this.#activityZeros.byteLength);
      }
      let current = this.#current;
      if (edits.length) {
        const pass = encoder.beginComputePass(this.#profiler.pass(trace, "edits"));
        pass.setPipeline(this.#edit);
        pass.setBindGroup(0, this.#editGroups[current]);
        pass.dispatchWorkgroups(1);
        pass.end();
      }
      current = this.#encodePhysics(encoder, slot, current, trace);
      if (region) {
        const pass = encoder.beginComputePass(this.#profiler.pass(trace, "collisionQuery"));
        pass.setPipeline(this.#query);
        pass.setBindGroup(0, this.#queryGroups[current]);
        pass.dispatchWorkgroups(Math.ceil(region.size.reduce((a, b) => a * b, 1) / 64));
        pass.end();
      }
      const reads = [];
      if (edits.length) {
        const bytes = edits.length * 2;
        encoder.copyBufferToBuffer(this.#editResult, 0, this.#editRead, 0, bytes);
        reads.push({ buffer: this.#editRead, bytes });
      }
      if (region) {
        const bytes = region.size.reduce((a, b) => a * b, 1) * 4;
        encoder.copyBufferToBuffer(this.#queryResult, 0, this.#queryRead, 0, bytes);
        reads.push({ buffer: this.#queryRead, bytes });
      }
      const interval = this.#config.activityReadbackInterval ?? 0;
      const sampleActivity = Boolean(this.#activity && ticks && interval && (this.#tick + ticks) % interval === 0);
      if (sampleActivity) {
        const bytes = this.#encodeActivityRead(encoder);
        reads.push({ buffer: this.#activityRead, bytes });
      }
      const values = await this.#finish(encoder, reads, trace);
      if (edits.length) {
        const deltas = values.shift();
        for (let i = 0; i < deltas.length; i += 2) this.#external += BigInt(deltas[i + 1]) - BigInt(deltas[i]);
      }
      this.#current = current;
      this.#tick += ticks;
      if (ticks) this.#lastTicks = ticks;
      if (ticks || edits.length) this.#revision++;
      if (sampleActivity) this.#activityCache = values.pop();
      this.#profiler.mark(trace, "completedAt");
      return region ? { origin: [...region.origin], size: [...region.size], grid: values[0], tick: this.#tick } : void 0;
    });
  }
  async queryRegion(region) {
    const checked = this.#region(region);
    if (!checked) throw new Error("A region is required.");
    return await this.step(0, { region: checked });
  }
  async #snapshot(current = this.#current) {
    const bytes = this.width * this.height * this.depth * 4;
    this.#device.pushErrorScope("validation");
    const encoder = this.#device.createCommandEncoder();
    encoder.copyBufferToBuffer(this.#cells[current], 0, this.#fullRead, 0, bytes);
    encoder.copyBufferToBuffer(this.#energy[current], 0, this.#fullRead, bytes, bytes);
    const [words] = await this.#finish(encoder, [{ buffer: this.#fullRead, bytes: bytes * 2 }]);
    const template = this.#config.cpu(1, 1, 1).snapshot();
    const result = { ...template, width: this.width, height: this.height, depth: this.depth, tick: this.#tick, packedCells: Array.from(this.#unpack(words.subarray(0, bytes / 4))), energyQ: Array.from(this.#unpack(words.subarray(bytes / 4))) };
    this.#config.validate(result);
    return result;
  }
  async snapshot() {
    return this.#run(() => this.#snapshot());
  }
  async restore(snapshot) {
    const state = this.#config.validate(snapshot);
    if (snapshot.width !== this.width || snapshot.height !== this.height || snapshot.depth !== this.depth) throw new Error("3D snapshot geometry differs from the field.");
    const tick = snapshot.tick;
    return this.#run(async () => {
      this.#activityCache = void 0;
      this.#device.queue.writeBuffer(this.#cells[0], 0, this.#pack(state.grid));
      this.#device.queue.writeBuffer(this.#energy[0], 0, this.#pack(state.energyQ));
      if (this.#activity) {
        this.#device.queue.writeBuffer(this.#cells[1], 0, this.#pack(state.grid));
        this.#device.queue.writeBuffer(this.#energy[1], 0, this.#pack(state.energyQ));
        this.#device.queue.writeBuffer(this.#activity, 16, new Uint32Array(6));
        this.#wakeAll();
      }
      await this.#device.queue.onSubmittedWorkDone();
      if (this.#activity) await this.prepareActivity();
      this.#current = 0;
      this.#tick = tick;
      this.#initial = total(state.energyQ);
      this.#external = 0n;
      this.#lastTicks = 0;
      this.#invalidate();
      this.#revision++;
    });
  }
  async sample(x, y, z) {
    checkedInteger(x, 0, this.width - 1, "x");
    checkedInteger(y, 0, this.height - 1, "y");
    checkedInteger(z, 0, this.depth - 1, "z");
    const cpu = this.#config.cpu(this.width, this.height, this.depth);
    cpu.restore(await this.snapshot());
    return cpu.sample(x, y, z);
  }
  async setCell(x, y, z, material2, thermal) {
    await this.step(0, { edits: [{ x, y, z, material: material2, ...thermal === void 0 ? {} : { thermal } }] });
  }
  async setEnergy(x, y, z, energyQ) {
    await this.step(0, { edits: [{ x, y, z, energyQ }] });
  }
  async energyBalance() {
    const s = await this.snapshot();
    const currentQ = total(s.energyQ);
    return { initialQ: this.#initial, externalQ: this.#external, currentQ, driftQ: currentQ - this.#initial - this.#external };
  }
  async inspectPass(passIndex) {
    checkedInteger(passIndex, 0, 26, "pass index");
    return this.#run(async () => {
      this.#activityCache = void 0;
      const p = volumeSchedule(this.#tick)[passIndex], params = this.#parameters(1);
      this.#shape(params, 0);
      params.set([KINDS.indexOf(p.kind), p.axis, p.parity, p.direction >>> 0, this.#tick >>> 0], 4);
      this.#device.queue.writeBuffer(this.#uniform, 0, params);
      this.#device.pushErrorScope("validation");
      const e = this.#device.createCommandEncoder();
      const pass = e.beginComputePass();
      pass.setBindGroup(0, this.#groups[this.#current], [0]);
      if (this.#activity) {
        this.#wakeAll();
        pass.setPipeline(this.#stages.collectWork);
        pass.setBindGroup(0, this.#stageGroups.collectWork);
        pass.dispatchWorkgroups(1);
      }
      pass.setPipeline(this.#pipeline);
      pass.setBindGroup(0, this.#groups[this.#current], [0]);
      if (this.#activity) pass.dispatchWorkgroupsIndirect(this.#indirect[this.#current], 0);
      else pass.dispatchWorkgroups(Math.ceil(this.width * this.height * this.depth / 64));
      pass.end();
      await this.#finish(e);
      const result = await this.#snapshot(1 - this.#current);
      this.#wakeAll();
      return result;
    });
  }
  #encodeActivityRead(e) {
    e.copyBufferToBuffer(this.#activity, 0, this.#activityRead, 0, this.#activity.size);
    e.copyBufferToBuffer(this.#dirty, 0, this.#activityRead, this.#activity.size, this.#dirty.size);
    return this.#activity.size + this.#dirty.size;
  }
  #activityInfo(words) {
    const storageChunks = this.#config.chunkSize ? this.width * this.height * this.depth / this.#config.chunkSize ** 3 : 1, count = this.#activity ? this.width * this.height * this.depth / this.#activeEdge ** 3 : storageChunks, dense = count * 27 * this.#lastTicks, activityChunkSize = this.#activeEdge || this.#config.chunkSize || this.width;
    if (!this.#activity) return { mode: "dense", tick: this.#tick, totalChunks: count, activityChunkSize, storageChunks, awake: Array(count).fill(1), wakeReasons: Array(count).fill(0), dispatchedChunks: dense, denseChunks: dense, peakChunks: count, sleepingChunks: 0 };
    if (!words) throw new Error("Missing activity readback.");
    const awake = Array.from(words.subarray(16, 16 + count));
    return { mode: "sparse", tick: this.#tick, totalChunks: count, activityChunkSize, storageChunks, awake, wakeReasons: Array.from(words.subarray(16 + 3 * count, 16 + 4 * count)), terrainDirty: Array.from(words.subarray(16 + 4 * count)), dispatchedChunks: words[4], denseChunks: dense, peakChunks: words[5], sleepingChunks: awake.filter((v) => v === 0).length, plannerBuilds: words[8], plannerReuses: words[9] };
  }
  async inspectActivity() {
    return this.#run(async () => {
      if (!this.#activity || this.#activityCache) return this.#activityInfo(this.#activityCache);
      this.#device.pushErrorScope("validation");
      const e = this.#device.createCommandEncoder();
      const bytes = this.#encodeActivityRead(e);
      const [words] = await this.#finish(e, [{ buffer: this.#activityRead, bytes }]);
      return this.#activityInfo(words);
    });
  }
  async createGameplay(initial, rules) {
    if (!this.#config.chunkSize || Math.min(this.width, this.height, this.depth) < 16) throw new Error("Resident gameplay requires chunked dimensions of at least 16.");
    if (this.#gameplay) throw new Error("A field supports one resident gameplay controller.");
    const shape = [this.width, this.height, this.depth];
    let state = checkedGameplayState(initial, shape);
    const checkedRules = checkedGameplayRules(rules, shape);
    return this.#run(async () => {
      const resources = await makeGameplayResources(this.#device, shape, this.#config.chunkSize, this.#cold, this.#dirty, this.#activity, checkedRules, this.#profiler);
      let closed = false, revision = this.#revision;
      const initialize = async (s) => {
        resources.writeState(s);
        this.#device.pushErrorScope("validation");
        const e = this.#device.createCommandEncoder();
        resources.initialize(e, this.#cells[this.#current], this.#energy[this.#current]);
        await this.#finish(e);
        state = s;
        revision = this.#revision;
      };
      const available = () => {
        if (closed) throw new Error("Resident gameplay is closed.");
        if (revision !== this.#revision) throw new Error("Terrain changed outside resident gameplay; restore the actor before continuing.");
      };
      const execute = async (command, presentation) => {
        available();
        const c = command ? checkedGameplayCommand(command, this.#tick + 1) : { tick: this.#tick, moveX: 0, moveZ: 0, jump: false, tool: "none", look: state.look };
        let renderer, camera;
        if (presentation) {
          renderer = this.#chunkRenderers.get(presentation.renderer);
          if (!renderer) throw new Error("Renderer does not belong to this field.");
          const view = presentation.camera;
          if (!view || Object.keys(view).some((k) => !["forward", "right", "up"].includes(k))) throw new Error("Resident view contains unsupported fields.");
          camera = { eye: [state.player.x / 256, (state.player.y - 400) / 256, state.player.z / 256], forward: Array.from(view.forward ?? []), right: Array.from(view.right ?? []), up: Array.from(view.up ?? []) };
          renderer.validateCamera(camera);
          const axes = [camera.forward, camera.right, camera.up];
          for (let i = 0; i < 3; i++) for (let j = i; j < 3; j++) {
            const dot = axes[i].reduce((sum, v, k) => sum + v * axes[j][k], 0);
            if (Math.abs(dot - (i === j ? 1 : 0)) > 1e-5) throw new Error("Resident camera axes must be orthonormal.");
          }
        }
        return this.#run(async () => {
          const view = camera ? camera.forward.map((v) => Math.round(v * 256)) : c.look;
          resources.prepare(c, view);
          const trace = this.#profiler.begin("gameplay", c.tick);
          let slot = 2;
          if (command) {
            const params = this.#parameters(29);
            this.#shape(params, 0);
            for (const p of volumeSchedule(this.#tick)) {
              this.#shape(params, slot);
              params.set([KINDS.indexOf(p.kind), p.axis, p.parity, p.direction >>> 0, this.#tick >>> 0], slot * 64 + 4);
              slot++;
            }
            this.#device.queue.writeBuffer(this.#uniform, 0, params);
          }
          this.#profiler.mark(trace, "preparedAt");
          this.#device.pushErrorScope("validation");
          const e = this.#device.createCommandEncoder();
          let current = this.#current;
          if (command) {
            if (this.#activity) {
              e.clearBuffer(this.#activity, 16, 24);
              e.clearBuffer(this.#activity, (16 + 3 * this.#activityZeros.length) * 4, this.#activityZeros.byteLength);
            }
            resources.tools(e, this.#cells[current], this.#energy[current], c.tool !== "none" && state.player.cooldown <= 1 && state.status !== "lost", trace);
            current = this.#encodePhysics(e, slot, current, trace);
            resources.controller(e, this.#cells[current], this.#energy[current], trace);
          } else resources.present(e, this.#cells[current], this.#energy[current], trace);
          if (renderer && camera) renderer.encode(e, camera, this.#cells[current], resources.result, trace);
          e.copyBufferToBuffer(resources.result, 0, resources.read, 0, 512);
          const reads = [{ buffer: resources.read, bytes: 512 }], interval = this.#config.activityReadbackInterval ?? 0;
          const sampleActivity = Boolean(this.#activity && command && interval && c.tick % interval === 0);
          if (sampleActivity) reads.push({ buffer: this.#activityRead, bytes: this.#encodeActivityRead(e) });
          const values = await this.#finish(e, reads, trace);
          let commit;
          try {
            commit = resources.decode(values[0], c.tick);
          } catch (error) {
            this.#fault = String(error);
            throw error;
          }
          if (command) {
            for (let i = 0; i < values[0][15]; i++) this.#external += BigInt(values[0][65 + i * 2]) - BigInt(values[0][64 + i * 2]);
            this.#current = current;
            this.#tick = c.tick;
            this.#lastTicks = 1;
            this.#revision++;
            revision = this.#revision;
          }
          this.#activityCache = sampleActivity ? values[1] : void 0;
          state = { player: { ...commit.player }, look: [...commit.look], status: commit.status, carved: commit.carved, iceWalk: commit.iceWalk };
          this.#profiler.mark(trace, "completedAt");
          return commit;
        });
      };
      const driver = {
        step: (c, p) => execute(checkedGameplayCommand(c, this.#tick + 1), p),
        present: (p) => {
          if (!p) throw new Error("A gameplay presentation is required.");
          return execute(void 0, p);
        },
        restore: (s) => {
          if (closed) throw new Error("Resident gameplay is closed.");
          const checked = checkedGameplayState(s, shape);
          return this.#run(() => initialize(checked));
        },
        close: () => {
          if (closed) return;
          if (this.#busy) throw new Error("Cannot close gameplay with an operation in flight.");
          closed = true;
          resources.close();
          this.#gameplay = void 0;
        }
      };
      try {
        await initialize(state);
        this.#gameplay = driver;
        return Object.freeze(driver);
      } catch (error) {
        resources.close();
        throw error;
      }
    });
  }
  async createRenderer(canvas) {
    if (this.#config.chunkSize && this.#worldRenderer) throw new Error("A world supports one terrain cache per field.");
    return this.#run(async () => {
      this.#activityCache = void 0;
      const renderer = this.#config.chunkSize ? await makeChunkRenderer(this.#device, canvas, () => ({ grid: this.#cells[this.#current], shape: [this.width, this.height, this.depth] }), this.#dirty, this.#config.chunkSize, this.#profiler, () => this.#tick) : await makeTerrainRenderer(this.#device, canvas, () => ({ grid: this.#cells[this.#current], shape: [this.width, this.height, this.depth] }), this.#profiler, () => this.#tick);
      let rendererClosed = false;
      const wrapped = { ...renderer.setAppearance ? { setAppearance: (value) => this.#run(() => renderer.setAppearance(value)) } : {}, render: (camera) => this.#run(() => {
        this.#activityCache = void 0;
        return renderer.render(camera);
      }), close: () => {
        if (rendererClosed) return;
        if (this.#busy) throw new Error("Cannot close terrain with an operation in flight.");
        renderer.close();
        rendererClosed = true;
        this.#worldRenderer = false;
        this.#chunkRenderers.delete(wrapped);
      }, ...renderer.inspectMesh ? { inspectMesh: () => this.#run(() => renderer.inspectMesh()) } : {} };
      this.#renderers.push(wrapped);
      this.#worldRenderer = Boolean(this.#config.chunkSize);
      if (this.#config.chunkSize) this.#chunkRenderers.set(wrapped, renderer);
      return wrapped;
    });
  }
  close() {
    if (this.#closed) return;
    if (this.#busy) throw new Error("Cannot close a field with an operation in flight.");
    this.#closed = true;
    this.#gameplay?.close();
    this.#renderers.forEach((r) => r.close());
    this.#profiler.close();
    this.#buffers.forEach((b) => b.destroy());
    this.#device.destroy();
  }
}
async function createResidentVolume(initial, config) {
  const { width, height, depth } = initial;
  if (!globalThis.navigator?.gpu) throw new Error("WebGPU is required for GPU 3D fields.");
  const adapter = await navigator.gpu.requestAdapter();
  if (!adapter) throw new Error("No WebGPU adapter.");
  if (config.profiling !== void 0 && typeof config.profiling !== "boolean") throw new Error("Invalid profiling option.");
  if (config.gpuTiming !== void 0 && typeof config.gpuTiming !== "boolean") throw new Error("Invalid GPU timing option.");
  const device = await adapter.requestDevice({ requiredFeatures: config.profiling && config.gpuTiming && adapter.features.has("timestamp-query") ? ["timestamp-query"] : [] });
  try {
    const shaders = config.sparse ? activeShaders(config.chunkSize, width * height * depth / Math.min(config.chunkSize, 8) ** 3) : chunkShaders(config.chunkSize);
    const shape = `const SHAPE=vec4u(${width}u,${height}u,${depth}u,${width * height * depth}u);
`;
    const specialize = (code) => shape + code.replaceAll("p.shape", "SHAPE");
    const module = await compile(device, specialize(shaders.physics)), access = await compile(device, specialize(shaders.access));
    const layout = device.createBindGroupLayout({ entries: [0, 1, 2, 3, 4, 5, 6, ...config.sparse ? [7, 8] : []].map((binding) => ({ binding, visibility: GPUShaderStage.COMPUTE, buffer: binding === 5 ? { type: "uniform", hasDynamicOffset: true, minBindingSize: 48 } : { type: binding === 2 || binding === 3 || binding === 6 || binding === 7 || binding === 8 ? "storage" : "read-only-storage" } })) });
    const pipeline = await device.createComputePipelineAsync({ layout: device.createPipelineLayout({ bindGroupLayouts: [layout] }), compute: { module, entryPoint: "main" } });
    const edit = await device.createComputePipelineAsync({ layout: "auto", compute: { module: access, entryPoint: "edit" } });
    const query = await device.createComputePipelineAsync({ layout: "auto", compute: { module: access, entryPoint: "query" } });
    const stages = {};
    if (config.sparse) for (const entryPoint of ["collectWork", "certify", "commitCert"]) stages[entryPoint] = await device.createComputePipelineAsync({ label: "active-" + entryPoint, layout: entryPoint === "collectWork" ? "auto" : device.createPipelineLayout({ bindGroupLayouts: [layout] }), compute: { module, entryPoint } });
    const info = adapter.info;
    const field = new ResidentVolume(width, height, depth, initial, device, pipeline, edit, query, { vendor: info.vendor, architecture: info.architecture, device: info.device, description: info.description, isFallbackAdapter: info.isFallbackAdapter }, config, stages);
    if (config.sparse) await field.prepareActivity();
    return field;
  } catch (error) {
    device.destroy();
    throw error;
  }
}
async function createGpuField3D(width, height, depth, fillMaterial = 0, options = {}) {
  if (options.profiling !== void 0 && typeof options.profiling !== "boolean") throw new Error("Invalid profiling option.");
  if (options.gpuTiming !== void 0 && typeof options.gpuTiming !== "boolean") throw new Error("Invalid GPU timing option.");
  const initial = createStateSpaceField3D(width, height, depth, fillMaterial).snapshot();
  return createResidentVolume(initial, { chunkSize: 0, profiling: options.profiling, gpuTiming: options.gpuTiming, cpu: createStateSpaceField3D, validate: validateVolumeSnapshot });
}
export {
  createGpuField3D
};
