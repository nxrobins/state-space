const MATERIAL_CATALOG_HASH = "f5e8af40e58281e2e8b5d343fddbc849c1daecfa54d4a51ea10d4b3bf9ce5ce7";
const PHASE_SHIFT = 24;
const COLD_TABLE_STRIDE = 24;
const COLD_TABLE_ENTRIES = 256;
const COLD_DENSITY = 0;
const COLD_CONDUCTIVITY = 1;
const COLD_MELT_POINT = 2;
const COLD_BOIL_POINT = 3;
const COLD_FREEZE_POINT = 8;
const COLD_CONDENSE_POINT = 9;
const COLD_MELTS_INTO = 12;
const COLD_BOILS_INTO = 13;
const COLD_FREEZES_INTO = 14;
const COLD_CONDENSES_INTO = 15;
const COLD_FUEL_ENERGY = 16;
const COLD_PHASE_ENERGY = 19;
const COLD_DEFAULT_PHASE = 20;
const COLD_STRIDE = COLD_TABLE_STRIDE;
function freezeDefinition(value) {
  if (value !== null && typeof value === "object") {
    for (const child of Object.values(value)) freezeDefinition(child);
    Object.freeze(value);
  }
  return value;
}
const MAT = freezeDefinition({
  "AIR": 0,
  "STONE": 1,
  "WATER": 2,
  "SAND": 3,
  "FIRE": 4,
  "METAL": 5,
  "OIL": 6,
  "WOOD": 7,
  "ICE": 8,
  "STEAM": 9,
  "LAVA": 10,
  "GLASS": 11,
  "PLAYER": 12,
  "ASH": 13,
  "SMOKE": 14,
  "OIL_VAPOR": 15,
  "MOLTEN_METAL": 16,
  "MOLTEN_GLASS": 17
});
const PHASE = freezeDefinition({
  "SOLID": 0,
  "POWDER": 1,
  "LIQUID": 2,
  "VISCOUS": 3,
  "GAS": 4,
  "PLASMA": 5,
  "FROZEN": 6,
  "MOLTEN": 7,
  "BURNING": 8,
  "CONDENSING": 9,
  "EVAPORATING": 10,
  "SUBLIMATING": 11
});
freezeDefinition({
  "BURNING": 1,
  "CONDUCTING": 2,
  "PRESSURIZED": 4,
  "PLAYER_OWNED": 8
});
freezeDefinition({
  "0": "air",
  "1": "stone",
  "2": "water",
  "3": "sand",
  "4": "fire",
  "5": "metal",
  "6": "oil",
  "7": "wood",
  "8": "ice",
  "9": "steam",
  "10": "lava",
  "11": "glass",
  "12": "player",
  "13": "ash",
  "14": "smoke",
  "15": "oil_vapor",
  "16": "molten_metal",
  "17": "molten_glass"
});
freezeDefinition({
  "0": "#0d0d14",
  "1": "#808080",
  "2": "#2659cc",
  "3": "#c2b280",
  "4": "#ff6610",
  "5": "#b3b8bf",
  "6": "#331f0d",
  "7": "#8c5926",
  "8": "#bfe6f2",
  "9": "#d9d9e6",
  "10": "#ff4d00",
  "11": "#b3d9e6",
  "12": "#33cc66",
  "13": "#4d4740",
  "14": "#66666b",
  "15": "#b4a178",
  "16": "#ffb665",
  "17": "#f6d5aa"
});
freezeDefinition({
  "0": 4,
  "1": 0,
  "2": 2,
  "3": 1,
  "4": 4,
  "5": 0,
  "6": 3,
  "7": 0,
  "8": 6,
  "9": 4,
  "10": 3,
  "11": 0,
  "12": 0,
  "13": 1,
  "14": 4,
  "15": 4,
  "16": 7,
  "17": 7
});
freezeDefinition({
  "0": 20,
  "1": 20,
  "2": 25,
  "3": 20,
  "4": 255,
  "5": 20,
  "6": 22,
  "7": 20,
  "8": 5,
  "9": 120,
  "10": 250,
  "11": 20,
  "12": 20,
  "13": 30,
  "14": 40,
  "15": 120,
  "16": 250,
  "17": 250
});
const COLD_ROWS = freezeDefinition([
  [
    0,
    1,
    5,
    0,
    0,
    0,
    0,
    255,
    3704094720,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    4,
    1,
    0,
    0
  ],
  [
    1,
    200,
    30,
    220,
    255,
    0,
    0,
    0,
    2155872456,
    210,
    0,
    30,
    0,
    10,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    200,
    180
  ],
  [
    2,
    100,
    60,
    0,
    100,
    0,
    0,
    0,
    2151677982,
    15,
    90,
    0,
    40,
    0,
    9,
    8,
    0,
    0,
    0,
    0,
    15,
    2,
    0,
    0,
    0
  ],
  [
    3,
    180,
    20,
    200,
    255,
    0,
    0,
    150,
    2999058612,
    0,
    0,
    25,
    0,
    11,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    0,
    0,
    0
  ],
  [
    4,
    0,
    255,
    0,
    0,
    0,
    255,
    255,
    1694497290,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    4,
    0,
    0,
    0
  ],
  [
    5,
    220,
    200,
    230,
    255,
    0,
    0,
    0,
    3031695580,
    220,
    0,
    35,
    0,
    16,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    255,
    185
  ],
  [
    6,
    90,
    10,
    0,
    80,
    120,
    200,
    0,
    505938070,
    0,
    70,
    0,
    30,
    0,
    15,
    0,
    0,
    150,
    14,
    4,
    0,
    3,
    0,
    0,
    0
  ],
  [
    7,
    120,
    15,
    0,
    0,
    180,
    150,
    30,
    1519059104,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    80,
    13,
    4,
    0,
    0,
    0,
    24,
    120
  ],
  [
    8,
    100,
    40,
    30,
    100,
    0,
    0,
    0,
    3871866900,
    0,
    0,
    15,
    0,
    2,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    6,
    0,
    12,
    12
  ],
  [
    9,
    5,
    50,
    0,
    0,
    0,
    0,
    255,
    3705410565,
    0,
    90,
    0,
    0,
    0,
    0,
    0,
    2,
    0,
    0,
    0,
    55,
    4,
    0,
    0,
    0
  ],
  [
    10,
    210,
    150,
    0,
    255,
    0,
    50,
    0,
    1358947940,
    210,
    0,
    0,
    0,
    0,
    0,
    1,
    0,
    0,
    0,
    0,
    30,
    3,
    0,
    0,
    0
  ],
  [
    11,
    170,
    25,
    240,
    255,
    0,
    0,
    0,
    3704094730,
    235,
    0,
    30,
    0,
    17,
    0,
    0,
    0,
    0,
    0,
    0,
    25,
    0,
    0,
    48,
    190
  ],
  [
    12,
    100,
    30,
    0,
    0,
    0,
    0,
    0,
    3362004530,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    32,
    0
  ],
  [
    13,
    150,
    10,
    0,
    0,
    0,
    0,
    100,
    1684275380,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    0,
    0,
    0
  ],
  [
    14,
    3,
    30,
    0,
    0,
    0,
    0,
    255,
    1684277840,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    4,
    0,
    0,
    0
  ],
  [
    15,
    2,
    30,
    0,
    0,
    120,
    200,
    0,
    505938070,
    0,
    70,
    0,
    0,
    0,
    0,
    0,
    6,
    150,
    14,
    4,
    30,
    4,
    0,
    0,
    0
  ],
  [
    16,
    220,
    200,
    0,
    0,
    0,
    0,
    0,
    3031695580,
    220,
    0,
    0,
    0,
    0,
    0,
    5,
    0,
    0,
    0,
    0,
    35,
    7,
    0,
    0,
    0
  ],
  [
    17,
    170,
    40,
    0,
    0,
    0,
    0,
    0,
    3704094730,
    235,
    0,
    0,
    0,
    0,
    0,
    11,
    0,
    0,
    0,
    0,
    55,
    7,
    0,
    0,
    0
  ]
]);
const DEFAULT_CATALOG = freezeDefinition({
  "schema_version": 4,
  "cold_stride": 24,
  "capacity": 256,
  "bit_fields": {
    "material": {
      "shift": 0,
      "bits": 8,
      "signed": false
    },
    "thermal": {
      "shift": 8,
      "bits": 8,
      "signed": false
    },
    "kinetic_x": {
      "shift": 16,
      "bits": 4,
      "signed": true
    },
    "kinetic_y": {
      "shift": 20,
      "bits": 4,
      "signed": true
    },
    "phase": {
      "shift": 24,
      "bits": 4,
      "signed": false
    },
    "flags": {
      "shift": 28,
      "bits": 4,
      "signed": false
    }
  },
  "phases": {
    "SOLID": 0,
    "POWDER": 1,
    "LIQUID": 2,
    "VISCOUS": 3,
    "GAS": 4,
    "PLASMA": 5,
    "FROZEN": 6,
    "MOLTEN": 7,
    "BURNING": 8,
    "CONDENSING": 9,
    "EVAPORATING": 10,
    "SUBLIMATING": 11
  },
  "flags": {
    "BURNING": 1,
    "CONDUCTING": 2,
    "PRESSURIZED": 4,
    "PLAYER_OWNED": 8
  },
  "cold_fields": [
    "density",
    "conductivity",
    "melt_point",
    "boil_point",
    "flash_point",
    "reactivity",
    "porosity",
    "optical",
    "freeze_point",
    "condense_point",
    "latent_heat_melt",
    "latent_heat_boil",
    "melts_into",
    "boils_into",
    "freezes_into",
    "condenses_into",
    "fuel_energy",
    "burns_into",
    "smoke_product",
    "phase_energy",
    "default_phase",
    "oxidizer",
    "cohesion",
    "softening"
  ],
  "materials": [
    {
      "id": 0,
      "name": "air",
      "default_thermal": 20,
      "color": "#0d0d14",
      "properties": {
        "density": 1,
        "conductivity": 5,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 255,
        "optical": 3704094720,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 4,
        "oxidizer": 1,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 1,
      "name": "stone",
      "default_thermal": 20,
      "color": "#808080",
      "properties": {
        "density": 200,
        "conductivity": 30,
        "melt_point": 220,
        "boil_point": 255,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 2155872456,
        "freeze_point": 210,
        "condense_point": 0,
        "latent_heat_melt": 30,
        "latent_heat_boil": 0,
        "melts_into": 10,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 0,
        "oxidizer": 0,
        "cohesion": 200,
        "softening": 180
      }
    },
    {
      "id": 2,
      "name": "water",
      "default_thermal": 25,
      "color": "#2659cc",
      "properties": {
        "density": 100,
        "conductivity": 60,
        "melt_point": 0,
        "boil_point": 100,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 2151677982,
        "freeze_point": 15,
        "condense_point": 90,
        "latent_heat_melt": 0,
        "latent_heat_boil": 40,
        "melts_into": 0,
        "boils_into": 9,
        "freezes_into": 8,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 15,
        "default_phase": 2,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 3,
      "name": "sand",
      "default_thermal": 20,
      "color": "#c2b280",
      "properties": {
        "density": 180,
        "conductivity": 20,
        "melt_point": 200,
        "boil_point": 255,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 150,
        "optical": 2999058612,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 25,
        "latent_heat_boil": 0,
        "melts_into": 11,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 1,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 4,
      "name": "fire",
      "default_thermal": 255,
      "color": "#ff6610",
      "properties": {
        "density": 0,
        "conductivity": 255,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 255,
        "porosity": 255,
        "optical": 1694497290,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 4,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 5,
      "name": "metal",
      "default_thermal": 20,
      "color": "#b3b8bf",
      "properties": {
        "density": 220,
        "conductivity": 200,
        "melt_point": 230,
        "boil_point": 255,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3031695580,
        "freeze_point": 220,
        "condense_point": 0,
        "latent_heat_melt": 35,
        "latent_heat_boil": 0,
        "melts_into": 16,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 0,
        "oxidizer": 0,
        "cohesion": 255,
        "softening": 185
      }
    },
    {
      "id": 6,
      "name": "oil",
      "default_thermal": 22,
      "color": "#331f0d",
      "properties": {
        "density": 90,
        "conductivity": 10,
        "melt_point": 0,
        "boil_point": 80,
        "flash_point": 120,
        "reactivity": 200,
        "porosity": 0,
        "optical": 505938070,
        "freeze_point": 0,
        "condense_point": 70,
        "latent_heat_melt": 0,
        "latent_heat_boil": 30,
        "melts_into": 0,
        "boils_into": 15,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 150,
        "burns_into": 14,
        "smoke_product": 4,
        "phase_energy": 0,
        "default_phase": 3,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 7,
      "name": "wood",
      "default_thermal": 20,
      "color": "#8c5926",
      "properties": {
        "density": 120,
        "conductivity": 15,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 180,
        "reactivity": 150,
        "porosity": 30,
        "optical": 1519059104,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 80,
        "burns_into": 13,
        "smoke_product": 4,
        "phase_energy": 0,
        "default_phase": 0,
        "oxidizer": 0,
        "cohesion": 24,
        "softening": 120
      }
    },
    {
      "id": 8,
      "name": "ice",
      "default_thermal": 5,
      "color": "#bfe6f2",
      "properties": {
        "density": 100,
        "conductivity": 40,
        "melt_point": 30,
        "boil_point": 100,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3871866900,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 15,
        "latent_heat_boil": 0,
        "melts_into": 2,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 6,
        "oxidizer": 0,
        "cohesion": 12,
        "softening": 12
      }
    },
    {
      "id": 9,
      "name": "steam",
      "default_thermal": 120,
      "color": "#d9d9e6",
      "properties": {
        "density": 5,
        "conductivity": 50,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 255,
        "optical": 3705410565,
        "freeze_point": 0,
        "condense_point": 90,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 2,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 55,
        "default_phase": 4,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 10,
      "name": "lava",
      "default_thermal": 250,
      "color": "#ff4d00",
      "properties": {
        "density": 210,
        "conductivity": 150,
        "melt_point": 0,
        "boil_point": 255,
        "flash_point": 0,
        "reactivity": 50,
        "porosity": 0,
        "optical": 1358947940,
        "freeze_point": 210,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 1,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 30,
        "default_phase": 3,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 11,
      "name": "glass",
      "default_thermal": 20,
      "color": "#b3d9e6",
      "properties": {
        "density": 170,
        "conductivity": 25,
        "melt_point": 240,
        "boil_point": 255,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3704094730,
        "freeze_point": 235,
        "condense_point": 0,
        "latent_heat_melt": 30,
        "latent_heat_boil": 0,
        "melts_into": 17,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 25,
        "default_phase": 0,
        "oxidizer": 0,
        "cohesion": 48,
        "softening": 190
      }
    },
    {
      "id": 12,
      "name": "player",
      "default_thermal": 20,
      "color": "#33cc66",
      "properties": {
        "density": 100,
        "conductivity": 30,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3362004530,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 0,
        "oxidizer": 0,
        "cohesion": 32,
        "softening": 0
      }
    },
    {
      "id": 13,
      "name": "ash",
      "default_thermal": 30,
      "color": "#4d4740",
      "properties": {
        "density": 150,
        "conductivity": 10,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 100,
        "optical": 1684275380,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 1,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 14,
      "name": "smoke",
      "default_thermal": 40,
      "color": "#66666b",
      "properties": {
        "density": 3,
        "conductivity": 30,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 255,
        "optical": 1684277840,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 4,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 15,
      "name": "oil_vapor",
      "default_thermal": 120,
      "color": "#b4a178",
      "properties": {
        "density": 2,
        "conductivity": 30,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 120,
        "reactivity": 200,
        "porosity": 0,
        "optical": 505938070,
        "freeze_point": 0,
        "condense_point": 70,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 6,
        "fuel_energy": 150,
        "burns_into": 14,
        "smoke_product": 4,
        "phase_energy": 30,
        "default_phase": 4,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 16,
      "name": "molten_metal",
      "default_thermal": 250,
      "color": "#ffb665",
      "properties": {
        "density": 220,
        "conductivity": 200,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3031695580,
        "freeze_point": 220,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 5,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 35,
        "default_phase": 7,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 17,
      "name": "molten_glass",
      "default_thermal": 250,
      "color": "#f6d5aa",
      "properties": {
        "density": 170,
        "conductivity": 40,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3704094730,
        "freeze_point": 235,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 11,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 55,
        "default_phase": 7,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    }
  ],
  "structure_fields": {
    "integrity": {
      "shift": 0,
      "bits": 8
    },
    "bond_left": {
      "shift": 8,
      "bits": 1
    },
    "bond_right": {
      "shift": 9,
      "bits": 1
    },
    "bond_up": {
      "shift": 10,
      "bits": 1
    },
    "bond_down": {
      "shift": 11,
      "bits": 1
    },
    "anchor": {
      "shift": 12,
      "bits": 1
    },
    "fresh": {
      "shift": 13,
      "bits": 1
    },
    "moved": {
      "shift": 14,
      "bits": 1
    },
    "pressure": {
      "shift": 16,
      "bits": 16
    }
  }
});
function buildColdTable() {
  const buffer = new Uint32Array(COLD_TABLE_ENTRIES * COLD_STRIDE);
  for (const [id, ...props] of COLD_ROWS) buffer.set(props, id * COLD_STRIDE);
  return buffer;
}
const typedArrayName = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(Uint32Array.prototype), Symbol.toStringTag).get;
const typedArrayPrototype = Object.getPrototypeOf(Uint32Array.prototype);
Object.getOwnPropertyDescriptor(typedArrayPrototype, "length").get;
Object.getOwnPropertyDescriptor(typedArrayPrototype, "buffer").get;
Object.getOwnPropertyDescriptor(typedArrayPrototype, "byteOffset").get;
function checkedInteger(value, minimum, maximum, name) {
  if (!Number.isSafeInteger(value) || value < minimum || value > maximum) {
    throw new Error(`${name} must be an integer in [${minimum}, ${maximum}].`);
  }
  return value;
}
function validatePackedCells(values, length) {
  if (!values || values.length !== length) {
    throw new Error(`Engine snapshot cell length mismatch: expected ${length}, received ${values?.length}.`);
  }
  if (values instanceof Uint32Array && typedArrayName.call(values) === "Uint32Array") {
    const copy = new Uint32Array(values);
    if (copy.length !== length) throw new Error("Engine snapshot cell length mismatch.");
    return copy;
  }
  for (let index = 0; index < length; index += 1) {
    const value = values[index];
    if (!Number.isSafeInteger(value) || value < 0 || value > 4294967295) {
      checkedInteger(value, 0, 4294967295, `packedCells[${index}]`);
    }
  }
  return Uint32Array.from(values);
}
const sameKeys = (value, keys, label) => {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).length !== keys.length || keys.some((key) => !Object.hasOwn(value, key))) {
    throw new Error(`${label} has missing or unexpected fields.`);
  }
};
const integer = (value, min, max, label) => {
  if (typeof value !== "number") throw new Error(`${label} must be a number.`);
  checkedInteger(value, min, max, label);
};
function canonicalCatalog(catalog) {
  const stable = (value) => {
    if (Array.isArray(value)) return `[${value.map(stable).join(",")}]`;
    if (value && typeof value === "object") {
      return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stable(value[key])}`).join(",")}}`;
    }
    return JSON.stringify(value);
  };
  return stable({ ...catalog, materials: [...catalog.materials].sort((a, b) => a.id - b.id) });
}
function validateCatalog(value) {
  sameKeys(value, Object.keys(DEFAULT_CATALOG), "Catalog");
  const catalog = value;
  integer(catalog.schema_version, 4, 4, "schema_version");
  integer(catalog.capacity, 256, 256, "capacity");
  integer(catalog.cold_stride, 24, 24, "cold_stride");
  sameKeys(catalog.structure_fields, Object.keys(DEFAULT_CATALOG.structure_fields), "structure_fields");
  for (const [name, expected] of Object.entries(DEFAULT_CATALOG.structure_fields)) {
    const field = catalog.structure_fields[name];
    sameKeys(field, ["shift", "bits"], `structure_fields.${name}`);
    integer(field.shift, expected.shift, expected.shift, `${name}.shift`);
    integer(field.bits, expected.bits, expected.bits, `${name}.bits`);
  }
  sameKeys(catalog.bit_fields, Object.keys(DEFAULT_CATALOG.bit_fields), "bit_fields");
  for (const [name, expected] of Object.entries(DEFAULT_CATALOG.bit_fields)) {
    const field = catalog.bit_fields[name];
    sameKeys(field, ["shift", "bits", "signed"], `bit_fields.${name}`);
    if (field.shift !== expected.shift || field.bits !== expected.bits || field.signed !== expected.signed) throw new Error("Packed layout requires a new schema version.");
  }
  for (const [label, table] of [["phases", catalog.phases], ["flags", catalog.flags]]) {
    if (!table || typeof table !== "object" || Array.isArray(table)) throw new Error(`Invalid ${label}.`);
    const values = /* @__PURE__ */ new Set();
    for (const [name, id] of Object.entries(table)) {
      if (!/^[A-Z][A-Z_0-9]*$/.test(name)) throw new Error(`Invalid ${label} symbol.`);
      integer(id, label === "phases" ? 0 : 1, 15, name);
      if (values.has(id) || label === "flags" && (id & id - 1) !== 0) throw new Error(`Invalid ${label} value.`);
      values.add(id);
    }
    for (const [name, id] of Object.entries(DEFAULT_CATALOG[label])) {
      if (table[name] !== id) throw new Error(`Changing existing ${label} requires a new schema version.`);
    }
    if (label === "flags" && Object.keys(table).length !== Object.keys(DEFAULT_CATALOG.flags).length) throw new Error("Invalid flags.");
  }
  if (!Array.isArray(catalog.cold_fields) || catalog.cold_fields.length !== DEFAULT_CATALOG.cold_fields.length || Array.from(catalog.cold_fields).some((name, i) => name !== DEFAULT_CATALOG.cold_fields[i])) throw new Error("Cold table offsets require a new schema version.");
  if (!Array.isArray(catalog.materials) || !catalog.materials.length) throw new Error("materials must be a nonempty array.");
  const records = /* @__PURE__ */ new Map(), names = /* @__PURE__ */ new Set();
  for (const record of catalog.materials) {
    sameKeys(record, ["id", "name", "default_thermal", "color", "properties"], "Material");
    integer(record.id, 0, 255, "material.id");
    if (typeof record.name !== "string" || !/^[a-z][a-z_0-9]*$/.test(record.name)) throw new Error("Invalid material name.");
    if (records.has(record.id) || names.has(record.name)) throw new Error("Duplicate material ID or name.");
    if (typeof record.color !== "string" || !/^#[0-9a-fA-F]{6}$/.test(record.color)) throw new Error("Invalid material color.");
    integer(record.default_thermal, 0, 255, "default_thermal");
    sameKeys(record.properties, catalog.cold_fields, "Material properties");
    for (const [name, property] of Object.entries(record.properties)) integer(property, 0, name === "optical" ? 4294967295 : 255, name);
    if (!Object.values(catalog.phases).includes(record.properties.default_phase)) throw new Error("Undefined default phase.");
    if (![0, 1].includes(record.properties.oxidizer)) throw new Error("oxidizer must be 0 or 1.");
    if (record.properties.softening && !record.properties.cohesion) throw new Error("Softening requires nonzero cohesion.");
    records.set(record.id, record);
    names.add(record.name);
  }
  for (const builtin2 of DEFAULT_CATALOG.materials) {
    if (records.get(builtin2.id)?.name !== builtin2.name) throw new Error("Changing existing material IDs requires a new schema version.");
  }
  const up = (p) => [p.boils_into || p.melts_into, p.boils_into ? p.boil_point : p.melt_point];
  const down = (p) => [p.freezes_into || p.condenses_into, p.freezes_into ? p.freeze_point : p.condense_point];
  for (const record of records.values()) {
    const p = record.properties;
    for (const name of ["melts_into", "boils_into", "freezes_into", "condenses_into", "burns_into", "smoke_product"]) {
      if (!records.has(p[name])) throw new Error(`Undefined target ${record.name}.${name}.`);
    }
    for (const [threshold, target] of [["melt_point", "melts_into"], ["boil_point", "boils_into"], ["freeze_point", "freezes_into"], ["condense_point", "condenses_into"]]) {
      if (p[target] && !p[threshold]) throw new Error("Transition target requires a threshold.");
    }
    if (p.melts_into && p.boils_into || p.freezes_into && p.condenses_into) throw new Error("Only one upward and downward phase interval is supported.");
    if (p.fuel_energy && (!p.flash_point || !p.burns_into || !p.smoke_product)) throw new Error("Incomplete combustion definition.");
    if (p.oxidizer && (p.fuel_energy || p.phase_energy)) throw new Error("Oxidizer must have zero chemical and phase offsets.");
    const upward = up(p), downward = down(p);
    if (upward[0] && downward[0] && downward[1] >= upward[1]) throw new Error("Material phase intervals overlap.");
    for (const [transition, direction] of [[upward, 1], [downward, -1]]) {
      const [id, threshold] = transition;
      if (!id) continue;
      const target = records.get(id).properties;
      const difference = target.phase_energy - p.phase_energy;
      if (difference * direction <= 0) throw new Error("Phase energy must change monotonically.");
      if (direction > 0 && difference !== p[p.boils_into ? "latent_heat_boil" : "latent_heat_melt"]) throw new Error("Declared latent heat must equal the phase energy difference.");
      if (target.fuel_energy !== p.fuel_energy || target.oxidizer !== p.oxidizer) throw new Error("Phase changes must preserve chemical and oxidizer identity.");
      const reverse = direction > 0 ? down(target) : up(target);
      if (reverse[0] && (reverse[0] !== record.id || (direction > 0 ? reverse[1] >= threshold : threshold >= reverse[1]))) {
        throw new Error("Reverse phase edges require original identity and positive hysteresis.");
      }
    }
    if (p.fuel_energy) {
      for (const id of [p.burns_into, p.smoke_product]) {
        const product = records.get(id).properties;
        if (product.fuel_energy || product.oxidizer || product.phase_energy) throw new Error("Combustion products must be inert with zero phase offset.");
      }
    }
  }
}
const registries = /* @__PURE__ */ new WeakSet();
class ValidatedRegistry {
  hash;
  materialIds;
  #catalog;
  #records;
  #cold;
  constructor(catalog, hash) {
    this.hash = hash;
    this.#catalog = catalog;
    this.#records = new Map(catalog.materials.map((record) => [record.id, record]));
    this.materialIds = Object.freeze([...this.#records.keys()].sort((a, b) => a - b));
    this.#cold = new Uint32Array(catalog.capacity * catalog.cold_stride);
    for (const record of catalog.materials) {
      this.#cold.set(catalog.cold_fields.map((name) => record.properties[name]), record.id * catalog.cold_stride);
      Object.freeze(record.properties);
      Object.freeze(record);
    }
    registries.add(this);
    Object.freeze(this);
  }
  has(material2) {
    return this.#records.has(material2);
  }
  material(material2) {
    integer(material2, 0, 255, "material");
    const record = this.#records.get(material2);
    if (!record) throw new Error(`Undefined material: ${material2}`);
    return record;
  }
  toCatalog() {
    return structuredClone(this.#catalog);
  }
  coldTable() {
    return this.#cold.slice();
  }
  extend(materials) {
    return createMaterialRegistry({ ...this.toCatalog(), materials: [...this.toCatalog().materials, ...materials] });
  }
}
const builtin = structuredClone(DEFAULT_CATALOG);
validateCatalog(builtin);
const DEFAULT_REGISTRY = new ValidatedRegistry(builtin, MATERIAL_CATALOG_HASH);
async function createMaterialRegistry(value) {
  const catalog = structuredClone(value);
  validateCatalog(catalog);
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(canonicalCatalog(catalog)));
  const hash = Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
  return new ValidatedRegistry(catalog, hash);
}
const ENERGY_SCALE = 256;
const MAX_ENERGY_Q = 1073741823;
const prop = (v, cold2, field) => cold2[(v & 255) * COLD_STRIDE + field];
function temperatureQ(voxel, energy, cold2) {
  const heat = energy - prop(voxel, cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE;
  const phase2 = prop(voxel, cold2, COLD_PHASE_ENERGY) * ENERGY_SCALE;
  let temperature = Math.max(0, heat - phase2);
  const boil = prop(voxel, cold2, COLD_BOILS_INTO);
  const up = boil || prop(voxel, cold2, COLD_MELTS_INTO);
  const upTemperature = prop(voxel, cold2, boil ? COLD_BOIL_POINT : COLD_MELT_POINT) * ENERGY_SCALE;
  const freeze = prop(voxel, cold2, COLD_FREEZES_INTO);
  const down = freeze || prop(voxel, cold2, COLD_CONDENSES_INTO);
  const downTemperature = prop(voxel, cold2, freeze ? COLD_FREEZE_POINT : COLD_CONDENSE_POINT) * ENERGY_SCALE;
  if (up && heat >= phase2 + upTemperature) {
    temperature = Math.max(upTemperature, heat - prop(up, cold2, COLD_PHASE_ENERGY) * ENERGY_SCALE);
  } else if (down && heat <= phase2 + downTemperature) {
    temperature = Math.min(downTemperature, Math.max(0, heat - prop(down, cold2, COLD_PHASE_ENERGY) * ENERGY_SCALE));
  }
  return temperature;
}
function thermalView(voxel, energy, cold2) {
  return (voxel & 4294902015 | Math.min(255, Math.floor(temperatureQ(voxel, energy, cold2) / ENERGY_SCALE)) << 8) >>> 0;
}
function seedState(values, cold2 = buildColdTable(), registry = DEFAULT_REGISTRY) {
  const grid = validatePackedCells(values, values.length);
  const energyQ = new Uint32Array(grid.length);
  for (let i = 0; i < grid.length; i += 1) {
    const v = grid[i];
    if (!registry.has(v & 255)) throw new Error("Undefined material in initial state.");
    energyQ[i] = ((v >>> 8 & 255) + prop(v, cold2, COLD_PHASE_ENERGY) + prop(v, cold2, COLD_FUEL_ENERGY)) * ENERGY_SCALE;
    grid[i] = thermalView(v, energyQ[i], cold2);
  }
  return { grid, energyQ };
}
function validateEnergyState(cells, energies, length, cold2 = buildColdTable(), registry = DEFAULT_REGISTRY) {
  const grid = validatePackedCells(cells, length);
  const energyQ = validatePackedCells(energies, length);
  for (let i = 0; i < length; i += 1) {
    const v = grid[i];
    if (!registry.has(v & 255)) throw new Error("Undefined material in simulation state.");
    const minimum = prop(v, cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE;
    if (energyQ[i] < minimum || energyQ[i] > MAX_ENERGY_Q) checkedInteger(energyQ[i], minimum, MAX_ENERGY_Q, `energyQ[${i}]`);
    if (thermalView(v, energyQ[i], cold2) !== v) throw new Error("Packed thermal view disagrees with conserved energy.");
  }
  return { grid, energyQ };
}
function exchangeEnergy(a, b, ea, eb, cold2) {
  const ta = temperatureQ(a, ea, cold2), tb = temperatureQ(b, eb, cold2);
  const ca = prop(a, cold2, COLD_CONDUCTIVITY), cb = prop(b, cold2, COLD_CONDUCTIVITY);
  const k = ca + cb ? Math.floor(2 * ca * cb / (ca + cb)) : 0;
  const difference = Math.abs(ta - tb);
  let flux = Math.floor(difference / 512) * k + Math.floor((difference % 512 * k + 511) / 512);
  flux = Math.min(flux, Math.floor(difference / 2));
  if (ta > tb) {
    flux = Math.min(flux, ea - prop(a, cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE, MAX_ENERGY_Q - eb);
    return [ea - flux, eb + flux];
  }
  flux = Math.min(flux, eb - prop(b, cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE, MAX_ENERGY_Q - ea);
  return [ea + flux, eb - flux];
}
function phaseMaterial(v, energy, cold2) {
  const chemical = prop(v, cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE;
  const boil = prop(v, cold2, COLD_BOILS_INTO);
  const up = boil || prop(v, cold2, COLD_MELTS_INTO);
  if (up) {
    const boundary = chemical + (prop(up, cold2, COLD_PHASE_ENERGY) + prop(v, cold2, boil ? COLD_BOIL_POINT : COLD_MELT_POINT)) * ENERGY_SCALE;
    if (energy >= boundary) return up;
  }
  const freeze = prop(v, cold2, COLD_FREEZES_INTO);
  const down = freeze || prop(v, cold2, COLD_CONDENSES_INTO);
  if (down) {
    const boundary = chemical + (prop(down, cold2, COLD_PHASE_ENERGY) + prop(v, cold2, freeze ? COLD_FREEZE_POINT : COLD_CONDENSE_POINT)) * ENERGY_SCALE;
    if (energy <= boundary) return down;
  }
  return v & 255;
}
function rewriteMaterial(voxel, material2, energy, cold2) {
  const packed = (voxel & 4043243520 | material2 | prop(material2, cold2, COLD_DEFAULT_PHASE) << PHASE_SHIFT) >>> 0;
  return thermalView(packed, energy, cold2);
}
function energyLedger(state, cold2 = buildColdTable()) {
  let sensibleQ = 0n, latentQ = 0n, chemicalQ = 0n;
  for (let i = 0; i < state.grid.length; i += 1) {
    const chemical = prop(state.grid[i], cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE;
    const sensible = temperatureQ(state.grid[i], state.energyQ[i], cold2);
    sensibleQ += BigInt(sensible);
    chemicalQ += BigInt(chemical);
    latentQ += BigInt(state.energyQ[i] - chemical - sensible);
  }
  return { sensibleQ, latentQ, chemicalQ, totalQ: sensibleQ + latentQ + chemicalQ };
}
const SCHEMA_VERSION_3D = 1;
const RULES_VERSION_3D = "ca-3d-m1";
const MAX_CELLS_3D = 32768;
const MATERIAL_CATALOG_HASH_3D = DEFAULT_REGISTRY.hash;
const cold = buildColdTable();
const arrayPrototype = Object.getPrototypeOf(Uint32Array.prototype);
const arrayLength = Object.getOwnPropertyDescriptor(arrayPrototype, "length").get;
const arrayBuffer = Object.getOwnPropertyDescriptor(arrayPrototype, "buffer").get;
const arrayOffset = Object.getOwnPropertyDescriptor(arrayPrototype, "byteOffset").get;
const arrayName = Object.getOwnPropertyDescriptor(arrayPrototype, Symbol.toStringTag).get;
const MATERIALS_3D = Object.freeze([
  MAT.AIR,
  MAT.STONE,
  MAT.SAND,
  MAT.WATER,
  MAT.ICE,
  MAT.STEAM,
  MAT.LAVA,
  MAT.GLASS,
  MAT.MOLTEN_GLASS
].map((id) => DEFAULT_REGISTRY.material(id)));
const supported = new Set(MATERIALS_3D.map((m) => m.id));
const material = (v) => v & 255;
const phase = (v) => v >>> PHASE_SHIFT & 15;
const fixed = (v) => phase(v) === PHASE.SOLID || phase(v) === PHASE.FROZEN;
const liquid = (v) => phase(v) === PHASE.LIQUID || phase(v) === PHASE.VISCOUS || phase(v) === PHASE.MOLTEN;
const falling = (v) => phase(v) === PHASE.POWDER || liquid(v);
const gas = (v) => phase(v) === PHASE.GAS;
const density = (v) => cold[material(v) * COLD_STRIDE + COLD_DENSITY];
function dimensions(w, h, d, maximum = MAX_CELLS_3D) {
  for (const [key, value] of [["width", w], ["height", h], ["depth", d]]) checkedInteger(value, 1, maximum, key);
  return checkedInteger(w * h * d, 1, maximum, "volume cell count");
}
function requireMaterial(id) {
  checkedInteger(id, 0, 255, "material");
  if (!supported.has(id)) throw new Error("Material is not supported by ca-3d-m1.");
}
function placement(id, thermal) {
  requireMaterial(id);
  const record = DEFAULT_REGISTRY.material(id);
  checkedInteger(thermal ?? record.default_thermal, 0, 255, "thermal");
  return seedState([id | (thermal ?? record.default_thermal) << 8 | record.properties.default_phase << PHASE_SHIFT]);
}
function validateState(cells, energies, count) {
  const state = validateEnergyState(cells, energies, count);
  for (const v of state.grid) {
    requireMaterial(material(v));
    if ((v & 4043243520) !== 0 || phase(v) !== DEFAULT_REGISTRY.material(material(v)).properties.default_phase) {
      throw new Error("3D M1 requires the material default phase and zero velocity/flags.");
    }
  }
  return state;
}
function validateVolumeSnapshot(value, maximum = MAX_CELLS_3D) {
  const keys = ["schemaVersion", "rulesVersion", "materialCatalogHash", "width", "height", "depth", "tick", "packedCells", "energyQ"];
  if (!value || typeof value !== "object" || Object.keys(value).length !== keys.length || keys.some((k) => !Object.hasOwn(value, k))) {
    throw new Error("3D snapshot contains missing or unexpected fields.");
  }
  if (value.schemaVersion !== SCHEMA_VERSION_3D || value.rulesVersion !== RULES_VERSION_3D || value.materialCatalogHash !== MATERIAL_CATALOG_HASH_3D) {
    throw new Error("Incompatible 3D snapshot version or catalog.");
  }
  checkedInteger(value.tick, 0, Number.MAX_SAFE_INTEGER, "tick");
  return validateState(value.packedCells, value.energyQ, dimensions(value.width, value.height, value.depth, maximum));
}
function choice(index, axis, tick) {
  let h = Math.imul(index, 374761393) + Math.imul(axis, 668265263) + Math.imul(tick >>> 0, 1442695041) >>> 0;
  h = Math.imul(h ^ h >>> 13, 1274126177) >>> 0;
  return ((h ^ h >>> 16) & 1) === 0;
}
function volumeSchedule(tick) {
  checkedInteger(tick, 0, Number.MAX_SAFE_INTEGER, "tick");
  const passes = [];
  const pairs = (kind, axis, direction = 1) => {
    for (const parity of [0, 1]) passes.push({ kind, axis, parity, direction });
  };
  pairs("gravity", 1);
  const directions = [[0, 1], [0, -1], [2, 1], [2, -1]];
  for (let k = 0; k < 4; k++) {
    const [axis, direction] = directions[(k + tick % 4) % 4];
    pairs("diagonal", axis, direction);
  }
  const axes = tick % 2 ? [2, 0] : [0, 2];
  for (const axis of axes) pairs("liquid", axis);
  pairs("buoyancy", 1);
  for (const axis of axes) pairs("gas", axis);
  for (const axis of [0, 1, 2]) pairs("heat", axis);
  passes.push({ kind: "phase", axis: 0, parity: 0, direction: 1 });
  return passes;
}
function executePass(input, output, w, h, d, tick, pass) {
  const aGrid = input.grid, aEnergy = input.energyQ, bGrid = output.grid, bEnergy = output.energyQ;
  bGrid.set(aGrid);
  bEnergy.set(aEnergy);
  const layer = w * h;
  const bound = (index) => fixed(aGrid[index]);
  const canFall = (source, target) => falling(aGrid[source]) && !bound(source) && !bound(target) && density(aGrid[source]) > density(aGrid[target]);
  const gasRank = (i) => Math.floor(temperatureQ(aGrid[i], aEnergy[i], cold) / 256) * 2 - density(aGrid[i]);
  const canRise = (s, t) => material(aGrid[s]) !== MAT.AIR && gas(aGrid[s]) && gas(aGrid[t]) && gasRank(s) > gasRank(t) + 16;
  const swap = (s, t) => {
    bGrid[s] = aGrid[t];
    bGrid[t] = aGrid[s];
    bEnergy[s] = aEnergy[t];
    bEnergy[t] = aEnergy[s];
  };
  const hasFall = (i, x, y, z) => y + 1 < h && (canFall(i, i + w) || x > 0 && canFall(i, i + w - 1) || x + 1 < w && canFall(i, i + w + 1) || z > 0 && canFall(i, i + w - layer) || z + 1 < d && canFall(i, i + w + layer));
  if (pass.kind === "phase") {
    for (let i = 0; i < aGrid.length; i++) {
      const next = phaseMaterial(aGrid[i], aEnergy[i], cold);
      if (next !== material(aGrid[i])) bGrid[i] = rewriteMaterial(aGrid[i], next, aEnergy[i], cold);
    }
    return;
  }
  const vertical = ["gravity", "diagonal", "buoyancy"].includes(pass.kind);
  const pairAxis = vertical ? 1 : pass.axis;
  for (let z = pairAxis === 2 ? pass.parity : 0; z < d; z += pairAxis === 2 ? 2 : 1) {
    for (let y = pairAxis === 1 ? pass.parity : 0; y < h; y += pairAxis === 1 ? 2 : 1) {
      for (let x = pairAxis === 0 ? pass.parity : 0; x < w; x += pairAxis === 0 ? 2 : 1) {
        let tx = x + (pairAxis === 0 ? 1 : 0), ty = y + (pairAxis === 1 ? 1 : 0), tz = z + (pairAxis === 2 ? 1 : 0);
        if (pass.kind === "diagonal") {
          tx += pass.axis === 0 ? pass.direction : 0;
          tz += pass.axis === 2 ? pass.direction : 0;
        }
        if (tx < 0 || tx >= w || ty >= h || tz < 0 || tz >= d) continue;
        const a = x + w * (y + h * z), b = tx + w * (ty + h * tz);
        if (pass.kind === "gravity") {
          if (canFall(a, b)) swap(a, b);
        } else if (pass.kind === "diagonal") {
          if (!canFall(a, a + w) && canFall(a, b)) swap(a, b);
        } else if (pass.kind === "buoyancy") {
          if (canRise(b, a)) swap(a, b);
        } else if (pass.kind === "liquid") {
          const spread = (s, t) => liquid(aGrid[s]) && gas(aGrid[t]) && density(aGrid[s]) > density(aGrid[t]);
          if (spread(a, b) && !hasFall(a, x, y, z) || spread(b, a) && !hasFall(b, tx, ty, tz)) swap(a, b);
        } else if (pass.kind === "gas") {
          const [s, t, sy] = choice(a, pass.axis, tick) ? [a, b, y] : [b, a, ty];
          if (material(aGrid[s]) !== MAT.AIR && gas(aGrid[s]) && gas(aGrid[t]) && (sy === 0 || !canRise(s, s - w)) && (material(aGrid[t]) === MAT.AIR || gasRank(s) > gasRank(t) + 16)) swap(s, t);
        } else if (pass.kind === "heat") {
          if (material(aGrid[a]) === material(aGrid[b]) && aEnergy[a] === aEnergy[b]) continue;
          [bEnergy[a], bEnergy[b]] = exchangeEnergy(aGrid[a], aGrid[b], aEnergy[a], aEnergy[b], cold);
          bGrid[a] = thermalView(aGrid[a], bEnergy[a], cold);
          bGrid[b] = thermalView(aGrid[b], bEnergy[b], cold);
        }
      }
    }
  }
}
class CpuVolume {
  width;
  height;
  depth;
  #state;
  #spare;
  #tick = 0;
  #initial = 0n;
  #external = 0n;
  #maximum;
  constructor(w, h, d, fill, maximum = MAX_CELLS_3D) {
    const count = dimensions(w, h, d, maximum), seed = placement(fill);
    this.#maximum = maximum;
    this.width = w;
    this.height = h;
    this.depth = d;
    for (const key of ["width", "height", "depth"]) Object.defineProperty(this, key, { writable: false, configurable: false });
    this.#state = { grid: new Uint32Array(count).fill(seed.grid[0]), energyQ: new Uint32Array(count).fill(seed.energyQ[0]) };
    this.#spare = { grid: new Uint32Array(count), energyQ: new Uint32Array(count) };
    this.#initial = this.#total();
  }
  get tick() {
    return this.#tick;
  }
  get grid() {
    return this.#state.grid.slice();
  }
  get energyQ() {
    return this.#state.energyQ.slice();
  }
  #total() {
    let sum = 0;
    for (const q of this.#state.energyQ) sum += q;
    return BigInt(sum);
  }
  #index(x, y, z) {
    checkedInteger(x, 0, this.width - 1, "x");
    checkedInteger(y, 0, this.height - 1, "y");
    checkedInteger(z, 0, this.depth - 1, "z");
    return x + this.width * (y + this.height * z);
  }
  step(ticks = 1) {
    checkedInteger(ticks, 0, 1024, "ticks per request");
    checkedInteger(this.#tick + ticks, 0, Number.MAX_SAFE_INTEGER, "end tick");
    for (let n = 0; n < ticks; n++) {
      for (const pass of volumeSchedule(this.#tick)) {
        executePass(this.#state, this.#spare, this.width, this.height, this.depth, this.#tick, pass);
        [this.#state, this.#spare] = [this.#spare, this.#state];
      }
      this.#tick++;
    }
  }
  sample(x, y, z) {
    const i = this.#index(x, y, z), v = this.#state.grid[i], energyQ = this.#state.energyQ[i];
    return {
      material: material(v),
      materialName: DEFAULT_REGISTRY.material(material(v)).name,
      phase: phase(v),
      thermal: v >>> 8 & 255,
      temperatureQ: temperatureQ(v, energyQ, cold),
      energyQ
    };
  }
  setCell(x, y, z, id, thermal) {
    const i = this.#index(x, y, z), seed = placement(id, thermal);
    this.#external += BigInt(seed.energyQ[0]) - BigInt(this.#state.energyQ[i]);
    this.#state.grid[i] = seed.grid[0];
    this.#state.energyQ[i] = seed.energyQ[0];
  }
  setEnergy(x, y, z, q) {
    const i = this.#index(x, y, z);
    checkedInteger(q, 0, MAX_ENERGY_Q, "energyQ");
    this.#external += BigInt(q) - BigInt(this.#state.energyQ[i]);
    this.#state.energyQ[i] = q;
    this.#state.grid[i] = thermalView(this.#state.grid[i], q, cold);
  }
  copyStateInto(target) {
    const count = this.#state.grid.length;
    const values = ["grid", "energyQ"].map((k) => target && Object.getOwnPropertyDescriptor(target, k)?.value);
    if (values.some((v) => !(v instanceof Uint32Array) || arrayName.call(v) !== "Uint32Array" || arrayLength.call(v) !== count || !(arrayBuffer.call(v) instanceof ArrayBuffer))) throw new Error("State copy needs two owned Uint32Arrays of the volume cell count.");
    const [grid, energies] = values;
    if (arrayBuffer.call(grid) === arrayBuffer.call(energies) && Math.abs(arrayOffset.call(grid) - arrayOffset.call(energies)) < count * 4) throw new Error("State copy coordinates overlap.");
    Uint32Array.prototype.set.call(grid, this.#state.grid);
    Uint32Array.prototype.set.call(energies, this.#state.energyQ);
    return this.#tick;
  }
  snapshot() {
    return {
      schemaVersion: SCHEMA_VERSION_3D,
      rulesVersion: RULES_VERSION_3D,
      materialCatalogHash: MATERIAL_CATALOG_HASH_3D,
      width: this.width,
      height: this.height,
      depth: this.depth,
      tick: this.#tick,
      packedCells: Array.from(this.#state.grid),
      energyQ: Array.from(this.#state.energyQ)
    };
  }
  restore(snapshot) {
    const next = validateVolumeSnapshot(snapshot, this.#maximum);
    if (snapshot.width !== this.width || snapshot.height !== this.height || snapshot.depth !== this.depth) throw new Error("3D snapshot geometry differs from the field.");
    this.#state = next;
    this.#tick = snapshot.tick;
    this.#initial = this.#total();
    this.#external = 0n;
  }
  energyLedger() {
    return energyLedger(this.#state, cold);
  }
  energyBalance() {
    const currentQ = this.#total();
    return { initialQ: this.#initial, externalQ: this.#external, currentQ, driftQ: currentQ - this.#initial - this.#external };
  }
}
const WORLD_VERSION_3D = "finite-chunks-1";
const MAX_WORLD_CELLS_3D = 64 ** 3;
function worldGeometry(options = {}) {
  if (!options || typeof options !== "object" || Array.isArray(options) || Object.keys(options).some((k) => !["width", "height", "depth", "chunkSize", "fillMaterial"].includes(k))) throw new Error("Invalid world options.");
  const { width = 64, height = 64, depth = 64, chunkSize = 32 } = options;
  for (const n of [width, height, depth]) checkedInteger(n, 1, 64, "world dimension");
  checkedInteger(chunkSize, 1, 32, "chunk size");
  if (chunkSize & chunkSize - 1 || [width, height, depth].some((n) => n % chunkSize) || width * height * depth / chunkSize ** 3 > 64) throw new Error("World requires power-of-two chunks, complete chunks and at most 64 chunks.");
  return { width, height, depth, chunkSize };
}
const referenceVolume = (w, h, d, fill = 0) => new CpuVolume(w, h, d, fill, MAX_WORLD_CELLS_3D);
const validateWorldFlat = (value) => validateVolumeSnapshot(value, MAX_WORLD_CELLS_3D);
function chunkSnapshot(flat, geometry) {
  const { width: w, height: h, depth: d, chunkSize: e } = geometry, chunks = [];
  for (let z = 0; z < d; z += e) for (let y = 0; y < h; y += e) for (let x = 0; x < w; x += e) {
    const packedCells = [], energyQ = [];
    for (let cz = z; cz < z + e; cz++) for (let cy = y; cy < y + e; cy++) for (let cx = x; cx < x + e; cx++) {
      const i = cx + w * (cy + h * cz);
      packedCells.push(flat.packedCells[i]);
      energyQ.push(flat.energyQ[i]);
    }
    chunks.push({ origin: [x, y, z], packedCells, energyQ });
  }
  const { schemaVersion, rulesVersion, materialCatalogHash, tick } = flat;
  return { schemaVersion, worldVersion: WORLD_VERSION_3D, rulesVersion, materialCatalogHash, ...geometry, tick, chunks };
}
function validateWorldSnapshot(value) {
  const keys = "chunkSize,chunks,depth,height,materialCatalogHash,rulesVersion,schemaVersion,tick,width,worldVersion";
  if (!value || typeof value !== "object" || Object.keys(value).sort().join(",") !== keys || value.worldVersion !== WORLD_VERSION_3D) throw new Error("Incompatible world snapshot.");
  for (const n of [value.width, value.height, value.depth, value.chunkSize]) checkedInteger(n, 1, 64, "snapshot dimension");
  const { width: w, height: h, depth: d, chunkSize: e } = worldGeometry({ width: value.width, height: value.height, depth: value.depth, chunkSize: value.chunkSize });
  const template = referenceVolume(1, 1, 1).snapshot(), packedCells = new Array(w * h * d), energyQ = new Array(w * h * d);
  if (!Array.isArray(value.chunks) || value.chunks.length !== w * h * d / e ** 3) throw new Error("Missing world chunks.");
  let k = 0;
  for (let z = 0; z < d; z += e) for (let y = 0; y < h; y += e) for (let x = 0; x < w; x += e) {
    const c = value.chunks[k++];
    if (!c || Object.keys(c).sort().join(",") !== "energyQ,origin,packedCells" || !Array.isArray(c.origin) || c.origin.length !== 3 || c.origin[0] !== x || c.origin[1] !== y || c.origin[2] !== z || !Array.isArray(c.packedCells) || !Array.isArray(c.energyQ) || c.packedCells.length !== e ** 3 || c.energyQ.length !== e ** 3) throw new Error("Invalid or noncanonical world chunk.");
    let j = 0;
    for (let cz = z; cz < z + e; cz++) for (let cy = y; cy < y + e; cy++) for (let cx = x; cx < x + e; cx++) {
      const i = cx + w * (cy + h * cz);
      packedCells[i] = c.packedCells[j];
      energyQ[i] = c.energyQ[j++];
    }
  }
  const flat = { ...template, width: w, height: h, depth: d, tick: value.tick, schemaVersion: value.schemaVersion, rulesVersion: value.rulesVersion, materialCatalogHash: value.materialCatalogHash, packedCells, energyQ };
  validateWorldFlat(flat);
  return flat;
}
function checkedWorldRegion(request, geometry) {
  if (!request || !Array.isArray(request.origin) || !Array.isArray(request.size) || request.origin.length !== 3 || request.size.length !== 3) throw new Error("Region needs three origin and size coordinates.");
  const shape = [geometry.width, geometry.height, geometry.depth], origin = [], size = [];
  for (let i = 0; i < 3; i++) {
    size.push(checkedInteger(request.size[i], 1, shape[i], "region size"));
    origin.push(checkedInteger(request.origin[i], 0, shape[i] - size[i], "region origin"));
  }
  checkedInteger(size[0] * size[1] * size[2], 1, 4096, "region cell count");
  return { origin, size };
}
class CpuWorld3D {
  width;
  height;
  depth;
  chunkSize;
  #field;
  constructor(options = {}) {
    const g = worldGeometry(options);
    this.width = g.width;
    this.height = g.height;
    this.depth = g.depth;
    this.chunkSize = g.chunkSize;
    this.#field = referenceVolume(this.width, this.height, this.depth, options.fillMaterial);
    for (const k of ["width", "height", "depth", "chunkSize"]) Object.defineProperty(this, k, { writable: false, configurable: false });
  }
  get tick() {
    return this.#field.tick;
  }
  get grid() {
    return this.#field.grid;
  }
  get energyQ() {
    return this.#field.energyQ;
  }
  sample(x, y, z) {
    return this.#field.sample(x, y, z);
  }
  setCell(x, y, z, material2, thermal) {
    this.#field.setCell(x, y, z, material2, thermal);
  }
  setEnergy(x, y, z, q) {
    this.#field.setEnergy(x, y, z, q);
  }
  copyStateInto(target) {
    return this.#field.copyStateInto(target);
  }
  energyLedger() {
    return this.#field.energyLedger();
  }
  energyBalance() {
    return this.#field.energyBalance();
  }
  snapshot() {
    return chunkSnapshot(this.#field.snapshot(), this);
  }
  restore(value) {
    const flat = validateWorldSnapshot(value);
    if (flat.width !== this.width || flat.height !== this.height || flat.depth !== this.depth) throw new Error("World geometry differs.");
    this.#field.restore(flat);
  }
  queryRegion(request) {
    const { origin, size } = checkedWorldRegion(request, this), grid = new Uint32Array(size[0] * size[1] * size[2]), source = this.#field.grid;
    let k = 0;
    for (let z = 0; z < size[2]; z++) for (let y = 0; y < size[1]; y++) for (let x = 0; x < size[0]; x++) grid[k++] = source[x + origin[0] + this.width * (y + origin[1] + this.height * (z + origin[2]))];
    return { origin: [...origin], size: [...size], grid, tick: this.tick };
  }
  step(ticks = 1, options = {}) {
    checkedInteger(ticks, 0, 32, "world ticks per request");
    checkedInteger(this.tick + ticks, 0, Number.MAX_SAFE_INTEGER, "end tick");
    if (!options || typeof options !== "object" || Array.isArray(options) || Object.keys(options).some((k) => !["edits", "region"].includes(k))) throw new Error("Invalid world step options.");
    const region = options.region === void 0 ? void 0 : checkedWorldRegion(options.region, this), edits = options.edits === void 0 ? [] : options.edits;
    if (!Array.isArray(edits)) throw new Error("Invalid edits.");
    checkedInteger(edits.length, 0, 64, "edit count");
    const seen = /* @__PURE__ */ new Set(), seed = referenceVolume(1, 1, 1), owned = [];
    for (let k = 0; k < edits.length; k++) {
      const e = edits[k];
      if (!e || typeof e !== "object") throw new Error("Invalid edit.");
      checkedInteger(e.x, 0, this.width - 1, "x");
      checkedInteger(e.y, 0, this.height - 1, "y");
      checkedInteger(e.z, 0, this.depth - 1, "z");
      const i = e.x + this.width * (e.y + this.height * e.z);
      if (seen.has(i)) throw new Error("Duplicate edit.");
      seen.add(i);
      const keys = Object.keys(e).sort().join(",");
      if ("material" in e) {
        if (!["material,x,y,z", "material,thermal,x,y,z"].includes(keys)) throw new Error("Invalid placement.");
        seed.setCell(0, 0, 0, e.material, e.thermal);
      } else {
        if (keys !== "energyQ,x,y,z") throw new Error("Invalid energy edit.");
        seed.setEnergy(0, 0, 0, e.energyQ);
      }
      owned.push({ ...e });
    }
    for (const e of owned) if ("material" in e) this.setCell(e.x, e.y, e.z, e.material, e.thermal);
    else this.setEnergy(e.x, e.y, e.z, e.energyQ);
    this.#field.step(ticks);
    return region ? this.queryRegion(region) : void 0;
  }
}
function createStateSpaceWorld3D(options = {}) {
  return new CpuWorld3D(options);
}
export {
  CpuWorld3D,
  MAT,
  MATERIALS_3D,
  MAX_ENERGY_Q,
  MAX_WORLD_CELLS_3D,
  PHASE,
  RULES_VERSION_3D,
  WORLD_VERSION_3D,
  createStateSpaceWorld3D,
  validateWorldSnapshot
};
