/** Numeric validation shared by portable backends. */
export declare const MAX_CELLS = 1073741823;
/** Validate caller-owned output storage before writing any coordinate. */
export declare function stateCopyTargets(target: object, count: number): Uint32Array[];
export declare function checkedInteger(value: number, minimum: number, maximum: number, name: string): number;
export declare function validateDimensions(width: number, height: number): number;
export declare function validatePackedCells(values: ArrayLike<number>, length: number): Uint32Array;
