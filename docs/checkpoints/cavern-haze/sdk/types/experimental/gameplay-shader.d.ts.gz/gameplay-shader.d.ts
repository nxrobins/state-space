import type { GameplayRules3D } from './gameplay-view.js';
/** Same integer controller/order as the CPU examples; terrain law is untouched. */
export declare function gameplayShader(shape: readonly number[], edge: number, sparse: boolean, rules: GameplayRules3D, air: readonly number[]): string;
