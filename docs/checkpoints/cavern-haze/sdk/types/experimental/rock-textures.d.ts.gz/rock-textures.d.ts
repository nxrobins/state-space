export declare const ROCK_TEXTURES: readonly string[];
