/** Bounded presentation diagnostics. Never used to choose physical work. */
import type { LatencyRecord, LatencySnapshot } from './3d-view.js';
type Slot = {
    query: GPUQuerySet;
    resolve: GPUBuffer;
    read: GPUBuffer;
    busy: boolean;
};
export type Trace = {
    record: LatencyRecord;
    slot?: Slot;
    labels: string[];
};
export declare class LatencyProfiler {
    #private;
    readonly enabled: boolean;
    readonly gpuTimestamps: boolean;
    readonly gpuTimingRequested: boolean;
    constructor(device: GPUDevice, enabled?: boolean, gpuTiming?: boolean);
    begin(kind: LatencyRecord['kind'], tick: number): Trace | undefined;
    mark(trace: Trace | undefined, name: string): void;
    pass(trace: Trace | undefined, label: string): GPUComputePassDescriptor;
    resolve(encoder: GPUCommandEncoder, trace?: Trace): void;
    submitted(trace?: Trace): void;
    snapshot(afterId?: number): LatencySnapshot;
    /** For receipt finalization only, after the measured loop has stopped. */
    settle(): Promise<void>;
    close(): void;
}
export {};
