import { type LatencyProfiler } from './latency.js';
import { type TerrainRenderer } from './3d-view.js';
export declare const MESH: string;
export declare const DRAW: string;
export declare function makeTerrainRenderer(device: GPUDevice, canvas: HTMLCanvasElement, state: () => {
    grid: GPUBuffer;
    shape: number[];
}, profiler?: LatencyProfiler, tick?: () => number): Promise<TerrainRenderer>;
