/** M4 dense CPU oracle and snapshot envelope. Sparse GPU metadata is derived, never saved. */
import { type VolumeSnapshot, type StateSpaceField3D } from './3d-core.js';
import type { GpuStepOptions3D, Region3D, RegionRequest3D } from './3d-gpu-core.js';
export { MAT, PHASE, MATERIALS_3D, MAX_ENERGY_Q, RULES_VERSION_3D } from './3d.js';
export declare const ACTIVE_WORLD_VERSION_3D = "finite-active-1";
export declare const MAX_ACTIVE_WORLD_CELLS_3D: number;
export type ActiveWorldOptions3D = {
    width?: number;
    height?: number;
    depth?: number;
    chunkSize?: number;
    fillMaterial?: number;
};
export type ActiveWorldGeometry3D = {
    width: number;
    height: number;
    depth: number;
    chunkSize: number;
};
export type ActiveWorldChunk3D = {
    origin: number[];
    packedCells: number[];
    energyQ: number[];
};
export type ActiveWorldSnapshot3D = {
    schemaVersion: number;
    worldVersion: string;
    rulesVersion: string;
    materialCatalogHash: string;
    width: number;
    height: number;
    depth: number;
    chunkSize: number;
    tick: number;
    chunks: ActiveWorldChunk3D[];
};
export declare function activeWorldGeometry(options?: ActiveWorldOptions3D): ActiveWorldGeometry3D;
/** Internal monolithic oracle uses precisely the shipped volume law and global schedule. */
export declare const activeReferenceVolume: (w: number, h: number, d: number, fill?: number) => StateSpaceField3D;
export declare const validateActiveWorldFlat: (value: VolumeSnapshot) => import("./3d-core.js").VolumeState;
export declare function activeChunkSnapshot(flat: VolumeSnapshot, geometry: ActiveWorldGeometry3D): ActiveWorldSnapshot3D;
/** Returns an owned, canonical monolithic copy, after validating the complete world. */
export declare function validateActiveWorldSnapshot(value: ActiveWorldSnapshot3D): VolumeSnapshot;
export declare function checkedActiveWorldRegion(request: RegionRequest3D, geometry: ActiveWorldGeometry3D): RegionRequest3D;
export declare class CpuActiveWorld3D {
    #private;
    readonly width: number;
    readonly height: number;
    readonly depth: number;
    readonly chunkSize: number;
    constructor(options?: ActiveWorldOptions3D);
    get tick(): number;
    get grid(): Uint32Array<ArrayBufferLike>;
    get energyQ(): Uint32Array<ArrayBufferLike>;
    sample(x: number, y: number, z: number): import("./3d-core.js").VolumeSample;
    setCell(x: number, y: number, z: number, material: number, thermal?: number): void;
    setEnergy(x: number, y: number, z: number, q: number): void;
    copyStateInto(target: Parameters<StateSpaceField3D['copyStateInto']>[0]): number;
    energyLedger(): {
        sensibleQ: bigint;
        latentQ: bigint;
        chemicalQ: bigint;
        totalQ: bigint;
    };
    energyBalance(): {
        initialQ: bigint;
        externalQ: bigint;
        currentQ: bigint;
        driftQ: bigint;
    };
    snapshot(): ActiveWorldSnapshot3D;
    restore(value: ActiveWorldSnapshot3D): void;
    queryRegion(request: RegionRequest3D): Region3D;
    step(ticks?: number, options?: GpuStepOptions3D): Region3D | undefined;
}
export declare function createStateSpaceActiveWorld3D(options?: ActiveWorldOptions3D): CpuActiveWorld3D;
