/** Independent integer pressure reference. See docs/PRESSURE.md. */
import type { StructuralRules } from './structure.js';
export declare const PRESSURE_MASK = 4294901760;
export declare const MOVED = 16384;
export declare function fluidKind(packed: number): number;
export declare function updatePressure(grid: Uint32Array, energy: Uint32Array, words: Uint32Array, width: number, height: number, rules: StructuralRules): Uint32Array;
export declare function pressureLoad(words: Uint32Array, i: number, width: number): number;
