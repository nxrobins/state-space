import { type StructuralState, type StructuralStateInput } from './structure.js';
import { type MaterialRegistry } from './registry.js';
/** Private solver rows: an exact cold-table copy, then derived thermal rows. */
export declare function solverTables(registry: MaterialRegistry): Uint32Array;
/** Copies and checks every coordinate before committing state or planning. */
export declare function validateCompiledStructure(input: StructuralStateInput, width: number, height: number, registry: MaterialRegistry): StructuralState;
/** Internal GPU readback boundary. These Uint32Arrays are owned by the field;
 * validate every completed state without allocating another three copies.
 * Public inputs must go through validateCompiledStructure instead. */
export declare function validateOwnedStructure(input: StructuralState, width: number, height: number, registry: MaterialRegistry): StructuralState;
/** Internal transport into a field's reusable plan storage. Inputs have already
 * passed completed-state validation; diagnostic/public plans keep owning copies. */
export declare function compiledTransportInto(input: StructuralState, width: number, height: number, registry: MaterialRegistry, sources: Uint32Array, structure: Uint32Array): void;
/** Takes ownership through validation, then returns independent output storage.
 * `committed` is only for a field's own committed state, which was validated
 * once at commit; any other input, including GPU readbacks, is validated here. */
export declare function compiledStructuralPlan(input: StructuralState, width: number, height: number, registry: MaterialRegistry, committed?: boolean): {
    sources: Uint32Array;
    structure: Uint32Array;
    apply(): StructuralState;
};
