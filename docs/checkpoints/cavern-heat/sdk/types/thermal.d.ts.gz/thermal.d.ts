import { type MaterialRegistry } from './registry.js';
export declare const ENERGY_SCALE = 256;
export declare const MAX_ENERGY_Q = 1073741823;
export interface PhysicsState {
    grid: Uint32Array;
    energyQ: Uint32Array;
}
export declare function temperatureQ(voxel: number, energy: number, cold: Uint32Array): number;
export declare function thermalView(voxel: number, energy: number, cold: Uint32Array): number;
export declare function seedState(values: ArrayLike<number>, cold?: Uint32Array, registry?: MaterialRegistry): PhysicsState;
export declare function validateEnergyState(cells: ArrayLike<number>, energies: ArrayLike<number>, length: number, cold?: Uint32Array, registry?: MaterialRegistry): PhysicsState;
export declare function exchangeEnergy(a: number, b: number, ea: number, eb: number, cold: Uint32Array): [number, number];
export declare function phaseMaterial(v: number, energy: number, cold: Uint32Array): number;
export declare function rewriteMaterial(voxel: number, material: number, energy: number, cold: Uint32Array): number;
export declare function energyLedger(state: PhysicsState, cold?: Uint32Array): {
    sensibleQ: bigint;
    latentQ: bigint;
    chemicalQ: bigint;
    totalQ: bigint;
};
export declare function cloneState(state: PhysicsState): PhysicsState;
