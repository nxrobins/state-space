import { type GpuVolume3D } from './3d-gpu-core.js';
import { type WorldOptions3D, type WorldSnapshot3D } from './world-core.js';
export type { LatencyRecord, LatencySnapshot, TerrainCamera, TerrainRenderer, TerrainAppearance, RegionRequest3D, Region3D, VolumeEdit3D, GpuStepOptions3D } from './3d-gpu-core.js';
export type { GameplayState3D, GameplayRules3D, GameplayCommand3D, GameplayPresentation3D, GameplayCommit3D, ResidentGameplay3D } from './gameplay-view.js';
export interface GpuWorld3D extends Omit<GpuVolume3D, 'snapshot' | 'restore' | 'inspectPass'> {
    readonly chunkSize: number;
    snapshot(): Promise<WorldSnapshot3D>;
    restore(snapshot: WorldSnapshot3D): Promise<void>;
    inspectPass(passIndex: number): Promise<WorldSnapshot3D>;
}
export declare function createGpuWorld3D(options?: WorldOptions3D & {
    profiling?: boolean;
    gpuTiming?: boolean;
}): Promise<GpuWorld3D>;
