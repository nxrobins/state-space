import type { LatencyProfiler, Trace } from './latency.js';
import type { GameplayCommand3D, GameplayCommit3D, GameplayRules3D, GameplayState3D } from './gameplay-view.js';
export declare function checkedGameplayState(state: GameplayState3D, shape: readonly number[]): {
    player: {
        x: number;
        y: number;
        z: number;
        vy: number;
        grounded: boolean;
        wet: boolean;
        jumpHeld: boolean;
        cooldown: number;
        blocked: boolean;
    };
    look: number[];
    status: "playing" | "won" | "lost";
    carved: boolean;
    iceWalk: boolean;
};
export declare function checkedGameplayRules(rules: GameplayRules3D, shape: readonly number[]): {
    goal: {
        minX: number;
        maxY: number;
        minZ: number;
        maxZ: number;
    };
    fallY: number;
    toolCeiling: number;
};
export declare function checkedGameplayCommand(c: GameplayCommand3D, tick: number): {
    look: number[];
    tick: number;
    moveX: number;
    moveZ: number;
    jump: boolean;
    tool: "none" | "carve" | "freeze";
};
export declare function makeGameplayResources(device: GPUDevice, shape: readonly number[], edge: number, cold: GPUBuffer, dirty: GPUBuffer, activity: GPUBuffer | undefined, rules: GameplayRules3D, profiler: LatencyProfiler): Promise<{
    result: GPUBuffer;
    read: GPUBuffer;
    writeState(s: GameplayState3D): void;
    prepare(c: GameplayCommand3D, view?: readonly number[]): void;
    initialize(e: GPUCommandEncoder, grid: GPUBuffer, energy: GPUBuffer): void;
    tools(e: GPUCommandEncoder, grid: GPUBuffer, energy: GPUBuffer, canEdit: boolean, trace?: Trace): void;
    controller(e: GPUCommandEncoder, grid: GPUBuffer, energy: GPUBuffer, trace?: Trace): void;
    present(e: GPUCommandEncoder, grid: GPUBuffer, energy: GPUBuffer, trace?: Trace): void;
    decode(words: Uint32Array, tick: number): GameplayCommit3D;
    close(): void;
}>;
