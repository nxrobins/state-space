import { type LatencyProfiler, type Trace } from './latency.js';
import type { TerrainCamera, TerrainRenderer } from './3d-view.js';
export interface ResidentChunkRenderer extends TerrainRenderer {
    validateCamera(camera: TerrainCamera): void;
    encode(encoder: GPUCommandEncoder, camera: TerrainCamera, grid: GPUBuffer, gpuCamera: GPUBuffer, trace?: Trace, presentationTick?: number): void;
}
export declare function makeChunkRenderer(device: GPUDevice, canvas: HTMLCanvasElement, state: () => {
    grid: GPUBuffer;
    shape: number[];
}, dirty: GPUBuffer, edge: number, profiler?: LatencyProfiler, tick?: () => number): Promise<ResidentChunkRenderer>;
