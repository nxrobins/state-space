import { energyLedger } from '../thermal.js';
export { MAT, PHASE } from '../generated/materials.js';
export { ENERGY_SCALE, MAX_ENERGY_Q } from '../thermal.js';
export declare const SCHEMA_VERSION_3D = 1;
export declare const RULES_VERSION_3D = "ca-3d-m1";
export declare const MAX_CELLS_3D = 32768;
export declare const MATERIAL_CATALOG_HASH_3D: string;
export declare const MATERIALS_3D: readonly (Readonly<Omit<import("../registry.js").MaterialDefinition, "properties">> & {
    readonly properties: Readonly<Record<string, number>>;
})[];
export interface VolumeState {
    grid: Uint32Array;
    energyQ: Uint32Array;
}
export interface VolumeSnapshot {
    schemaVersion: number;
    rulesVersion: string;
    materialCatalogHash: string;
    width: number;
    height: number;
    depth: number;
    tick: number;
    packedCells: number[];
    energyQ: number[];
}
export interface VolumeSample {
    material: number;
    materialName: string;
    phase: number;
    thermal: number;
    temperatureQ: number;
    energyQ: number;
}
export interface StateSpaceField3D {
    readonly width: number;
    readonly height: number;
    readonly depth: number;
    readonly tick: number;
    readonly grid: Uint32Array;
    readonly energyQ: Uint32Array;
    step(ticks?: number): void;
    sample(x: number, y: number, z: number): VolumeSample;
    setCell(x: number, y: number, z: number, material: number, thermal?: number): void;
    setEnergy(x: number, y: number, z: number, energyQ: number): void;
    copyStateInto(target: VolumeState): number;
    snapshot(): VolumeSnapshot;
    restore(snapshot: VolumeSnapshot): void;
    energyLedger(): ReturnType<typeof energyLedger>;
    energyBalance(): {
        initialQ: bigint;
        externalQ: bigint;
        currentQ: bigint;
        driftQ: bigint;
    };
}
export declare function validateVolumeSnapshot(value: VolumeSnapshot, maximum?: number): VolumeState;
export type VolumePass = {
    kind: 'gravity' | 'diagonal' | 'liquid' | 'buoyancy' | 'gas' | 'heat' | 'phase';
    axis: number;
    parity: number;
    direction: number;
};
/** All 27 passes, including their order, are part of ca-3d-m1. */
export declare function volumeSchedule(tick: number): readonly VolumePass[];
/** Single-pass verification hook; validates and copies caller state. */
export declare function runVolumePass(state: VolumeState, w: number, h: number, d: number, tick: number, passIndex: number): VolumeState;
export declare class CpuVolume implements StateSpaceField3D {
    #private;
    readonly width: number;
    readonly height: number;
    readonly depth: number;
    constructor(w: number, h: number, d: number, fill: number, maximum?: number);
    get tick(): number;
    get grid(): Uint32Array;
    get energyQ(): Uint32Array;
    step(ticks?: number): void;
    sample(x: number, y: number, z: number): VolumeSample;
    setCell(x: number, y: number, z: number, id: number, thermal?: number): void;
    setEnergy(x: number, y: number, z: number, q: number): void;
    copyStateInto(target: VolumeState): number;
    snapshot(): VolumeSnapshot;
    restore(snapshot: VolumeSnapshot): void;
    energyLedger(): ReturnType<typeof energyLedger>;
    energyBalance(): {
        initialQ: bigint;
        externalQ: bigint;
        currentQ: bigint;
        driftQ: bigint;
    };
}
export declare function createStateSpaceField3D(width: number, height: number, depth: number, fillMaterial?: number): StateSpaceField3D;
