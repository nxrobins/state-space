export declare function activeShaders(edge: number, chunks: number, activeEdge?: number): {
    physics: string;
    access: string;
};
