/** Validated, immutable catalogs. Custom registries use the same SHA-256 identity as Python. */
import { DEFAULT_CATALOG } from './generated/materials.js';
export interface MaterialDefinition {
    id: number;
    name: string;
    default_thermal: number;
    color: string;
    properties: Record<string, number>;
}
export type MaterialCatalog = Omit<typeof DEFAULT_CATALOG, 'materials'> & {
    materials: MaterialDefinition[];
};
export interface MaterialRegistry {
    readonly hash: string;
    readonly materialIds: readonly number[];
    has(material: number): boolean;
    material(material: number): Readonly<Omit<MaterialDefinition, 'properties'>> & {
        readonly properties: Readonly<Record<string, number>>;
    };
    toCatalog(): MaterialCatalog;
    coldTable(): Uint32Array;
    extend(materials: MaterialDefinition[]): Promise<MaterialRegistry>;
}
/** Stable JSON: object keys sorted, material records sorted by ID, all numbers exact integers. */
export declare function canonicalCatalog(catalog: MaterialCatalog): string;
export declare function validateCatalog(value: unknown): asserts value is MaterialCatalog;
export declare function requireRegistry(registry: MaterialRegistry): void;
export declare const DEFAULT_REGISTRY: MaterialRegistry;
export declare function createMaterialRegistry(value: unknown): Promise<MaterialRegistry>;
