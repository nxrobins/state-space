export declare const KERNEL_SPECS: ({
    id: string;
    name: string;
    source_file: string;
    constants: {
        GRAVITY_PHASE?: undefined;
        MOVE_AXIS?: undefined;
        MOVE_PHASE?: undefined;
        MOVE_SALT?: undefined;
        THERMAL_AXIS?: undefined;
        THERMAL_PARITY?: undefined;
    };
} | {
    id: string;
    name: string;
    source_file: string;
    constants: {
        GRAVITY_PHASE: number;
        MOVE_AXIS?: undefined;
        MOVE_PHASE?: undefined;
        MOVE_SALT?: undefined;
        THERMAL_AXIS?: undefined;
        THERMAL_PARITY?: undefined;
    };
} | {
    id: string;
    name: string;
    source_file: string;
    constants: {
        MOVE_AXIS: number;
        MOVE_PHASE: number;
        MOVE_SALT: number;
        GRAVITY_PHASE?: undefined;
        THERMAL_AXIS?: undefined;
        THERMAL_PARITY?: undefined;
    };
} | {
    id: string;
    name: string;
    source_file: string;
    constants: {
        MOVE_PHASE: number;
        MOVE_SALT: number;
        GRAVITY_PHASE?: undefined;
        MOVE_AXIS?: undefined;
        THERMAL_AXIS?: undefined;
        THERMAL_PARITY?: undefined;
    };
} | {
    id: string;
    name: string;
    source_file: string;
    constants: {
        MOVE_PHASE: number;
        GRAVITY_PHASE?: undefined;
        MOVE_AXIS?: undefined;
        MOVE_SALT?: undefined;
        THERMAL_AXIS?: undefined;
        THERMAL_PARITY?: undefined;
    };
} | {
    id: string;
    name: string;
    source_file: string;
    constants: {
        THERMAL_AXIS: number;
        THERMAL_PARITY: number;
        GRAVITY_PHASE?: undefined;
        MOVE_AXIS?: undefined;
        MOVE_PHASE?: undefined;
        MOVE_SALT?: undefined;
    };
})[];
export declare function movementScheduleForTick(tick: number): string[];
