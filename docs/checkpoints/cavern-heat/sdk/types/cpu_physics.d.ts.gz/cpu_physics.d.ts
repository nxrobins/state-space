import { type StructuralState, type StructuralPlan } from './structure.js';
import { type MaterialRegistry } from './registry.js';
export declare function hashPair(x: number, y: number, salt: number): number;
export type PassObserver = (passId: string, state: StructuralState, plan?: StructuralPlan) => void;
/** `committed` is only for a field's own committed state, which was validated at
 * commit. Every other input is validated by the first (structural) pass. */
export declare function runCpuTick(state: StructuralState, width: number, height: number, cold: Uint32Array, tick: number, observer?: PassObserver, registry?: MaterialRegistry, committed?: boolean): StructuralState;
export declare function runCpuPass(state: StructuralState, width: number, height: number, cold: Uint32Array, passId: string, registry?: MaterialRegistry): StructuralState;
