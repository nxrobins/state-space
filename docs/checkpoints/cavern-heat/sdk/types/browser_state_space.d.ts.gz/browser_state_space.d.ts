/** CPU backend for the versioned State Space field contract. */
export * from './generated/materials.js';
import { MAT } from './generated/materials.js';
import { energyLedger as inspectEnergy } from './thermal.js';
import { type StructuralState, type StructuralPlan } from './structure.js';
import { type MaterialRegistry } from './registry.js';
import { type PassReport, type StepOptions } from './inspection.js';
export type MaterialId = (typeof MAT)[keyof typeof MAT];
import { type PackedSnapshot } from './contracts.js';
export interface VoxelState {
    material: number;
    thermal: number;
    kineticX: number;
    kineticY: number;
    phase: number;
    flags: number;
}
export interface FieldSample {
    material: number;
    materialName: string;
    thermal: number;
    energyQ: number;
    temperatureQ: number;
    phase: number;
    flags: number;
    structure: number;
    integrity: number;
    anchored: boolean;
    bonds: number;
    pressureQ: number;
    velocityX: number;
    velocityY: number;
}
export interface StateSpaceFieldSnapshot {
    width: number;
    height: number;
    grid: Uint32Array;
    energyQ: Uint32Array;
    structure: Uint32Array;
    tick: number;
}
export interface StateSpaceField {
    readonly registry: MaterialRegistry;
    readonly width: number;
    readonly height: number;
    readonly tick: number;
    readonly grid: Uint32Array;
    readonly energyQ: Uint32Array;
    readonly structure: Uint32Array;
    copyStateInto(target: StructuralState): number;
    energyLedger(): ReturnType<typeof inspectEnergy>;
    energyBalance(): {
        initialQ: bigint;
        externalQ: bigint;
        currentQ: bigint;
        driftQ: bigint;
    };
    step(ticks?: number, options?: StepOptions): readonly PassReport[];
    close(): void;
    clear(material?: number): void;
    setCell(x: number, y: number, material: number, thermal?: number, flags?: number): void;
    setEnergy(x: number, y: number, energyQ: number): void;
    setAnchor(x: number, y: number, anchored?: boolean): void;
    setIntegrity(x: number, y: number, integrity: number, options?: {
        weld?: boolean;
    }): void;
    inspectStructure(): StructuralPlan;
    paintCircle(x: number, y: number, radius: number, material: number, thermal?: number, flags?: number): void;
    sample(x: number, y: number): FieldSample;
    materialAt(x: number, y: number): number;
    thermalAt(x: number, y: number): number;
    snapshot(): StateSpaceFieldSnapshot;
    packedSnapshot(): PackedSnapshot;
    restore(snapshot: PackedSnapshot): void;
}
export declare function packVoxel(material: number, thermal?: number, kineticX?: number, kineticY?: number, phase?: number, flags?: number): number;
export declare function unpackVoxel(packed: number): VoxelState;
export declare function defaultPhase(material: number): number;
export declare function defaultThermal(material: number): number;
export declare function materialName(material: number): string;
export declare function createStateSpaceField(width: number, height: number, fillMaterial?: number, registry?: MaterialRegistry): StateSpaceField;
/** Internal shared state/edit implementation for CPU and asynchronous GPU fields. */
export declare class FieldState {
    readonly width: number;
    readonly height: number;
    readonly registry: MaterialRegistry;
    protected cells: Uint32Array;
    protected energies: Uint32Array;
    protected bonds: Uint32Array;
    private initialEnergyQ;
    private editEnergyQ;
    protected coldTable: Uint32Array;
    protected tickCount: number;
    protected busy: boolean;
    protected closed: boolean;
    constructor(width: number, height: number, fillMaterial: number, registry: MaterialRegistry);
    protected ensureAvailable(mutation?: boolean): void;
    /** Invalidate backend copies before any committed coordinates are changed. */
    protected stateChanged(): void;
    close(): void;
    get grid(): Uint32Array;
    get energyQ(): Uint32Array;
    get structure(): Uint32Array;
    /** Copy the committed coordinates into independent caller-owned storage. */
    copyStateInto(target: StructuralState): number;
    energyLedger(): ReturnType<typeof inspectEnergy>;
    energyBalance(): {
        initialQ: bigint;
        externalQ: bigint;
        currentQ: bigint;
        driftQ: bigint;
    };
    get tick(): number;
    clear(material?: number): void;
    setCell(x: number, y: number, material: number, thermal?: number, flags?: number): void;
    setEnergy(x: number, y: number, energyQ: number): void;
    private normalizeStructure;
    setAnchor(x: number, y: number, anchored?: boolean): void;
    setIntegrity(x: number, y: number, integrity: number, options?: {
        weld?: boolean;
    }): void;
    inspectStructure(): StructuralPlan;
    paintCircle(x: number, y: number, radius: number, material: number, thermal?: number, flags?: number): void;
    sample(x: number, y: number): FieldSample;
    materialAt(x: number, y: number): number;
    thermalAt(x: number, y: number): number;
    snapshot(): StateSpaceFieldSnapshot;
    packedSnapshot(): PackedSnapshot;
    restore(snapshot: PackedSnapshot): void;
    protected commitState(state: StructuralState, tick: number): void;
    /** Private continuation: take ownership only after complete-state validation. */
    protected adoptState(state: StructuralState, tick: number): void;
    private index;
    private inside;
    private clampX;
    private clampY;
}
