/** Portable WebGPU field. Await step before accessing or editing its complete state. */
import { type StateSpaceField } from './browser_state_space.js';
import { type MaterialRegistry } from './registry.js';
import { type PassReport, type StepOptions } from './inspection.js';
export interface GpuStateSpaceField extends Omit<StateSpaceField, 'step'> {
    readonly backendInfo: Readonly<{
        vendor: string;
        architecture: string;
        device: string;
        description: string;
        isFallbackAdapter: boolean;
    }>;
    step(ticks?: number, options?: StepOptions): Promise<readonly PassReport[]>;
}
export interface GpuFieldOptions {
    fillMaterial?: number;
    registry?: MaterialRegistry;
}
export declare function createGpuField(width: number, height: number, options?: GpuFieldOptions): Promise<GpuStateSpaceField>;
