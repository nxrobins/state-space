var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var __privateWrapper = (obj, member, setter, getter) => ({
  set _(value) {
    __privateSet(obj, member, value, setter);
  },
  get _() {
    return __privateGet(obj, member, getter);
  }
});
var _catalog, _records, _cold, _state, _spare, _tick, _initial, _external, _maximum, _CpuVolume_instances, total_fn, index_fn, _state2, _tick2, _initial2, _external2, _slots, _records2, _pending, _next, _device, _pipelines, _banks, _owned, _current, _tick3, _cold2, _work, _dirty, _uniform, _commands, _receipts, _controlRead, _receiptRead, _fullRead, _indirect, _activityRead, _queryResult, _queryRead, _solveDispatch, _solveBatchLimit, _groups, _params, _computePass, _busy, _closed, _fault, _initial3, _external3, _planReusable, _renderers, _gameplay, _revision, _submissions, _submitTrace, _stats, _GpuStructuralWorld3D_instances, address_fn, pack_fn, unpack_fn, upload_fn, run_fn, group_fn, compute_fn, dispatch_fn, parameters_fn, writeParameters_fn, submit_fn, control_fn, converge_fn, edits_fn, batchedSolve_fn, tickOnce_fn, encodeMotionAndMaterial_fn, readState_fn;
const MATERIAL_CATALOG_HASH = "f5e8af40e58281e2e8b5d343fddbc849c1daecfa54d4a51ea10d4b3bf9ce5ce7";
const PHASE_SHIFT = 24;
const PHASE_SOLID = 0;
const PHASE_FROZEN = 6;
const COLD_TABLE_STRIDE = 24;
const COLD_TABLE_ENTRIES = 256;
const COLD_DENSITY = 0;
const COLD_CONDUCTIVITY = 1;
const COLD_MELT_POINT = 2;
const COLD_BOIL_POINT = 3;
const COLD_FREEZE_POINT = 8;
const COLD_CONDENSE_POINT = 9;
const COLD_MELTS_INTO = 12;
const COLD_BOILS_INTO = 13;
const COLD_FREEZES_INTO = 14;
const COLD_CONDENSES_INTO = 15;
const COLD_FUEL_ENERGY = 16;
const COLD_PHASE_ENERGY = 19;
const COLD_DEFAULT_PHASE = 20;
const COLD_COHESION = 22;
const COLD_SOFTENING = 23;
const COLD_STRIDE = COLD_TABLE_STRIDE;
function freezeDefinition(value) {
  if (value !== null && typeof value === "object") {
    for (const child of Object.values(value)) freezeDefinition(child);
    Object.freeze(value);
  }
  return value;
}
const MAT = freezeDefinition({
  "AIR": 0,
  "STONE": 1,
  "WATER": 2,
  "SAND": 3,
  "FIRE": 4,
  "METAL": 5,
  "OIL": 6,
  "WOOD": 7,
  "ICE": 8,
  "STEAM": 9,
  "LAVA": 10,
  "GLASS": 11,
  "PLAYER": 12,
  "ASH": 13,
  "SMOKE": 14,
  "OIL_VAPOR": 15,
  "MOLTEN_METAL": 16,
  "MOLTEN_GLASS": 17
});
const PHASE = freezeDefinition({
  "SOLID": 0,
  "POWDER": 1,
  "LIQUID": 2,
  "VISCOUS": 3,
  "GAS": 4,
  "PLASMA": 5,
  "FROZEN": 6,
  "MOLTEN": 7,
  "BURNING": 8,
  "CONDENSING": 9,
  "EVAPORATING": 10,
  "SUBLIMATING": 11
});
freezeDefinition({
  "BURNING": 1,
  "CONDUCTING": 2,
  "PRESSURIZED": 4,
  "PLAYER_OWNED": 8
});
freezeDefinition({
  "0": "air",
  "1": "stone",
  "2": "water",
  "3": "sand",
  "4": "fire",
  "5": "metal",
  "6": "oil",
  "7": "wood",
  "8": "ice",
  "9": "steam",
  "10": "lava",
  "11": "glass",
  "12": "player",
  "13": "ash",
  "14": "smoke",
  "15": "oil_vapor",
  "16": "molten_metal",
  "17": "molten_glass"
});
freezeDefinition({
  "0": "#0d0d14",
  "1": "#808080",
  "2": "#2659cc",
  "3": "#c2b280",
  "4": "#ff6610",
  "5": "#b3b8bf",
  "6": "#331f0d",
  "7": "#8c5926",
  "8": "#bfe6f2",
  "9": "#d9d9e6",
  "10": "#ff4d00",
  "11": "#b3d9e6",
  "12": "#33cc66",
  "13": "#4d4740",
  "14": "#66666b",
  "15": "#b4a178",
  "16": "#ffb665",
  "17": "#f6d5aa"
});
freezeDefinition({
  "0": 4,
  "1": 0,
  "2": 2,
  "3": 1,
  "4": 4,
  "5": 0,
  "6": 3,
  "7": 0,
  "8": 6,
  "9": 4,
  "10": 3,
  "11": 0,
  "12": 0,
  "13": 1,
  "14": 4,
  "15": 4,
  "16": 7,
  "17": 7
});
freezeDefinition({
  "0": 20,
  "1": 20,
  "2": 25,
  "3": 20,
  "4": 255,
  "5": 20,
  "6": 22,
  "7": 20,
  "8": 5,
  "9": 120,
  "10": 250,
  "11": 20,
  "12": 20,
  "13": 30,
  "14": 40,
  "15": 120,
  "16": 250,
  "17": 250
});
const COLD_ROWS = freezeDefinition([
  [
    0,
    1,
    5,
    0,
    0,
    0,
    0,
    255,
    3704094720,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    4,
    1,
    0,
    0
  ],
  [
    1,
    200,
    30,
    220,
    255,
    0,
    0,
    0,
    2155872456,
    210,
    0,
    30,
    0,
    10,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    200,
    180
  ],
  [
    2,
    100,
    60,
    0,
    100,
    0,
    0,
    0,
    2151677982,
    15,
    90,
    0,
    40,
    0,
    9,
    8,
    0,
    0,
    0,
    0,
    15,
    2,
    0,
    0,
    0
  ],
  [
    3,
    180,
    20,
    200,
    255,
    0,
    0,
    150,
    2999058612,
    0,
    0,
    25,
    0,
    11,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    0,
    0,
    0
  ],
  [
    4,
    0,
    255,
    0,
    0,
    0,
    255,
    255,
    1694497290,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    4,
    0,
    0,
    0
  ],
  [
    5,
    220,
    200,
    230,
    255,
    0,
    0,
    0,
    3031695580,
    220,
    0,
    35,
    0,
    16,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    255,
    185
  ],
  [
    6,
    90,
    10,
    0,
    80,
    120,
    200,
    0,
    505938070,
    0,
    70,
    0,
    30,
    0,
    15,
    0,
    0,
    150,
    14,
    4,
    0,
    3,
    0,
    0,
    0
  ],
  [
    7,
    120,
    15,
    0,
    0,
    180,
    150,
    30,
    1519059104,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    80,
    13,
    4,
    0,
    0,
    0,
    24,
    120
  ],
  [
    8,
    100,
    40,
    30,
    100,
    0,
    0,
    0,
    3871866900,
    0,
    0,
    15,
    0,
    2,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    6,
    0,
    12,
    12
  ],
  [
    9,
    5,
    50,
    0,
    0,
    0,
    0,
    255,
    3705410565,
    0,
    90,
    0,
    0,
    0,
    0,
    0,
    2,
    0,
    0,
    0,
    55,
    4,
    0,
    0,
    0
  ],
  [
    10,
    210,
    150,
    0,
    255,
    0,
    50,
    0,
    1358947940,
    210,
    0,
    0,
    0,
    0,
    0,
    1,
    0,
    0,
    0,
    0,
    30,
    3,
    0,
    0,
    0
  ],
  [
    11,
    170,
    25,
    240,
    255,
    0,
    0,
    0,
    3704094730,
    235,
    0,
    30,
    0,
    17,
    0,
    0,
    0,
    0,
    0,
    0,
    25,
    0,
    0,
    48,
    190
  ],
  [
    12,
    100,
    30,
    0,
    0,
    0,
    0,
    0,
    3362004530,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    32,
    0
  ],
  [
    13,
    150,
    10,
    0,
    0,
    0,
    0,
    100,
    1684275380,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    0,
    0,
    0
  ],
  [
    14,
    3,
    30,
    0,
    0,
    0,
    0,
    255,
    1684277840,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    4,
    0,
    0,
    0
  ],
  [
    15,
    2,
    30,
    0,
    0,
    120,
    200,
    0,
    505938070,
    0,
    70,
    0,
    0,
    0,
    0,
    0,
    6,
    150,
    14,
    4,
    30,
    4,
    0,
    0,
    0
  ],
  [
    16,
    220,
    200,
    0,
    0,
    0,
    0,
    0,
    3031695580,
    220,
    0,
    0,
    0,
    0,
    0,
    5,
    0,
    0,
    0,
    0,
    35,
    7,
    0,
    0,
    0
  ],
  [
    17,
    170,
    40,
    0,
    0,
    0,
    0,
    0,
    3704094730,
    235,
    0,
    0,
    0,
    0,
    0,
    11,
    0,
    0,
    0,
    0,
    55,
    7,
    0,
    0,
    0
  ]
]);
const DEFAULT_CATALOG = freezeDefinition({
  "schema_version": 4,
  "cold_stride": 24,
  "capacity": 256,
  "bit_fields": {
    "material": {
      "shift": 0,
      "bits": 8,
      "signed": false
    },
    "thermal": {
      "shift": 8,
      "bits": 8,
      "signed": false
    },
    "kinetic_x": {
      "shift": 16,
      "bits": 4,
      "signed": true
    },
    "kinetic_y": {
      "shift": 20,
      "bits": 4,
      "signed": true
    },
    "phase": {
      "shift": 24,
      "bits": 4,
      "signed": false
    },
    "flags": {
      "shift": 28,
      "bits": 4,
      "signed": false
    }
  },
  "phases": {
    "SOLID": 0,
    "POWDER": 1,
    "LIQUID": 2,
    "VISCOUS": 3,
    "GAS": 4,
    "PLASMA": 5,
    "FROZEN": 6,
    "MOLTEN": 7,
    "BURNING": 8,
    "CONDENSING": 9,
    "EVAPORATING": 10,
    "SUBLIMATING": 11
  },
  "flags": {
    "BURNING": 1,
    "CONDUCTING": 2,
    "PRESSURIZED": 4,
    "PLAYER_OWNED": 8
  },
  "cold_fields": [
    "density",
    "conductivity",
    "melt_point",
    "boil_point",
    "flash_point",
    "reactivity",
    "porosity",
    "optical",
    "freeze_point",
    "condense_point",
    "latent_heat_melt",
    "latent_heat_boil",
    "melts_into",
    "boils_into",
    "freezes_into",
    "condenses_into",
    "fuel_energy",
    "burns_into",
    "smoke_product",
    "phase_energy",
    "default_phase",
    "oxidizer",
    "cohesion",
    "softening"
  ],
  "materials": [
    {
      "id": 0,
      "name": "air",
      "default_thermal": 20,
      "color": "#0d0d14",
      "properties": {
        "density": 1,
        "conductivity": 5,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 255,
        "optical": 3704094720,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 4,
        "oxidizer": 1,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 1,
      "name": "stone",
      "default_thermal": 20,
      "color": "#808080",
      "properties": {
        "density": 200,
        "conductivity": 30,
        "melt_point": 220,
        "boil_point": 255,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 2155872456,
        "freeze_point": 210,
        "condense_point": 0,
        "latent_heat_melt": 30,
        "latent_heat_boil": 0,
        "melts_into": 10,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 0,
        "oxidizer": 0,
        "cohesion": 200,
        "softening": 180
      }
    },
    {
      "id": 2,
      "name": "water",
      "default_thermal": 25,
      "color": "#2659cc",
      "properties": {
        "density": 100,
        "conductivity": 60,
        "melt_point": 0,
        "boil_point": 100,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 2151677982,
        "freeze_point": 15,
        "condense_point": 90,
        "latent_heat_melt": 0,
        "latent_heat_boil": 40,
        "melts_into": 0,
        "boils_into": 9,
        "freezes_into": 8,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 15,
        "default_phase": 2,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 3,
      "name": "sand",
      "default_thermal": 20,
      "color": "#c2b280",
      "properties": {
        "density": 180,
        "conductivity": 20,
        "melt_point": 200,
        "boil_point": 255,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 150,
        "optical": 2999058612,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 25,
        "latent_heat_boil": 0,
        "melts_into": 11,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 1,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 4,
      "name": "fire",
      "default_thermal": 255,
      "color": "#ff6610",
      "properties": {
        "density": 0,
        "conductivity": 255,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 255,
        "porosity": 255,
        "optical": 1694497290,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 4,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 5,
      "name": "metal",
      "default_thermal": 20,
      "color": "#b3b8bf",
      "properties": {
        "density": 220,
        "conductivity": 200,
        "melt_point": 230,
        "boil_point": 255,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3031695580,
        "freeze_point": 220,
        "condense_point": 0,
        "latent_heat_melt": 35,
        "latent_heat_boil": 0,
        "melts_into": 16,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 0,
        "oxidizer": 0,
        "cohesion": 255,
        "softening": 185
      }
    },
    {
      "id": 6,
      "name": "oil",
      "default_thermal": 22,
      "color": "#331f0d",
      "properties": {
        "density": 90,
        "conductivity": 10,
        "melt_point": 0,
        "boil_point": 80,
        "flash_point": 120,
        "reactivity": 200,
        "porosity": 0,
        "optical": 505938070,
        "freeze_point": 0,
        "condense_point": 70,
        "latent_heat_melt": 0,
        "latent_heat_boil": 30,
        "melts_into": 0,
        "boils_into": 15,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 150,
        "burns_into": 14,
        "smoke_product": 4,
        "phase_energy": 0,
        "default_phase": 3,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 7,
      "name": "wood",
      "default_thermal": 20,
      "color": "#8c5926",
      "properties": {
        "density": 120,
        "conductivity": 15,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 180,
        "reactivity": 150,
        "porosity": 30,
        "optical": 1519059104,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 80,
        "burns_into": 13,
        "smoke_product": 4,
        "phase_energy": 0,
        "default_phase": 0,
        "oxidizer": 0,
        "cohesion": 24,
        "softening": 120
      }
    },
    {
      "id": 8,
      "name": "ice",
      "default_thermal": 5,
      "color": "#bfe6f2",
      "properties": {
        "density": 100,
        "conductivity": 40,
        "melt_point": 30,
        "boil_point": 100,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3871866900,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 15,
        "latent_heat_boil": 0,
        "melts_into": 2,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 6,
        "oxidizer": 0,
        "cohesion": 12,
        "softening": 12
      }
    },
    {
      "id": 9,
      "name": "steam",
      "default_thermal": 120,
      "color": "#d9d9e6",
      "properties": {
        "density": 5,
        "conductivity": 50,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 255,
        "optical": 3705410565,
        "freeze_point": 0,
        "condense_point": 90,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 2,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 55,
        "default_phase": 4,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 10,
      "name": "lava",
      "default_thermal": 250,
      "color": "#ff4d00",
      "properties": {
        "density": 210,
        "conductivity": 150,
        "melt_point": 0,
        "boil_point": 255,
        "flash_point": 0,
        "reactivity": 50,
        "porosity": 0,
        "optical": 1358947940,
        "freeze_point": 210,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 1,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 30,
        "default_phase": 3,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 11,
      "name": "glass",
      "default_thermal": 20,
      "color": "#b3d9e6",
      "properties": {
        "density": 170,
        "conductivity": 25,
        "melt_point": 240,
        "boil_point": 255,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3704094730,
        "freeze_point": 235,
        "condense_point": 0,
        "latent_heat_melt": 30,
        "latent_heat_boil": 0,
        "melts_into": 17,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 25,
        "default_phase": 0,
        "oxidizer": 0,
        "cohesion": 48,
        "softening": 190
      }
    },
    {
      "id": 12,
      "name": "player",
      "default_thermal": 20,
      "color": "#33cc66",
      "properties": {
        "density": 100,
        "conductivity": 30,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3362004530,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 0,
        "oxidizer": 0,
        "cohesion": 32,
        "softening": 0
      }
    },
    {
      "id": 13,
      "name": "ash",
      "default_thermal": 30,
      "color": "#4d4740",
      "properties": {
        "density": 150,
        "conductivity": 10,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 100,
        "optical": 1684275380,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 1,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 14,
      "name": "smoke",
      "default_thermal": 40,
      "color": "#66666b",
      "properties": {
        "density": 3,
        "conductivity": 30,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 255,
        "optical": 1684277840,
        "freeze_point": 0,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 0,
        "default_phase": 4,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 15,
      "name": "oil_vapor",
      "default_thermal": 120,
      "color": "#b4a178",
      "properties": {
        "density": 2,
        "conductivity": 30,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 120,
        "reactivity": 200,
        "porosity": 0,
        "optical": 505938070,
        "freeze_point": 0,
        "condense_point": 70,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 0,
        "condenses_into": 6,
        "fuel_energy": 150,
        "burns_into": 14,
        "smoke_product": 4,
        "phase_energy": 30,
        "default_phase": 4,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 16,
      "name": "molten_metal",
      "default_thermal": 250,
      "color": "#ffb665",
      "properties": {
        "density": 220,
        "conductivity": 200,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3031695580,
        "freeze_point": 220,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 5,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 35,
        "default_phase": 7,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    },
    {
      "id": 17,
      "name": "molten_glass",
      "default_thermal": 250,
      "color": "#f6d5aa",
      "properties": {
        "density": 170,
        "conductivity": 40,
        "melt_point": 0,
        "boil_point": 0,
        "flash_point": 0,
        "reactivity": 0,
        "porosity": 0,
        "optical": 3704094730,
        "freeze_point": 235,
        "condense_point": 0,
        "latent_heat_melt": 0,
        "latent_heat_boil": 0,
        "melts_into": 0,
        "boils_into": 0,
        "freezes_into": 11,
        "condenses_into": 0,
        "fuel_energy": 0,
        "burns_into": 0,
        "smoke_product": 0,
        "phase_energy": 55,
        "default_phase": 7,
        "oxidizer": 0,
        "cohesion": 0,
        "softening": 0
      }
    }
  ],
  "structure_fields": {
    "integrity": {
      "shift": 0,
      "bits": 8
    },
    "bond_left": {
      "shift": 8,
      "bits": 1
    },
    "bond_right": {
      "shift": 9,
      "bits": 1
    },
    "bond_up": {
      "shift": 10,
      "bits": 1
    },
    "bond_down": {
      "shift": 11,
      "bits": 1
    },
    "anchor": {
      "shift": 12,
      "bits": 1
    },
    "fresh": {
      "shift": 13,
      "bits": 1
    },
    "moved": {
      "shift": 14,
      "bits": 1
    },
    "pressure": {
      "shift": 16,
      "bits": 16
    }
  }
});
function buildColdTable() {
  const buffer = new Uint32Array(COLD_TABLE_ENTRIES * COLD_STRIDE);
  for (const [id, ...props] of COLD_ROWS) buffer.set(props, id * COLD_STRIDE);
  return buffer;
}
const typedArrayName = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(Uint32Array.prototype), Symbol.toStringTag).get;
const typedArrayPrototype = Object.getPrototypeOf(Uint32Array.prototype);
const arrayLength$1 = Object.getOwnPropertyDescriptor(typedArrayPrototype, "length").get;
const arrayBuffer$1 = Object.getOwnPropertyDescriptor(typedArrayPrototype, "buffer").get;
const arrayOffset$1 = Object.getOwnPropertyDescriptor(typedArrayPrototype, "byteOffset").get;
function stateCopyTargets(target, count) {
  if (!target || typeof target !== "object") throw new Error("State copy requires output storage.");
  const values = ["grid", "energyQ", "structure"].map((key) => {
    var _a;
    return (_a = Object.getOwnPropertyDescriptor(target, key)) == null ? void 0 : _a.value;
  });
  for (const value of values) {
    if (!(value instanceof Uint32Array) || typedArrayName.call(value) !== "Uint32Array" || arrayLength$1.call(value) !== count) {
      throw new Error("State copy requires three Uint32Arrays of the field cell count.");
    }
  }
  for (let i = 0; i < values.length; i++) for (let j = 0; j < i; j++) {
    if (arrayBuffer$1.call(values[i]) === arrayBuffer$1.call(values[j]) && Math.abs(arrayOffset$1.call(values[i]) - arrayOffset$1.call(values[j])) < count * 4) {
      throw new Error("State copy coordinates must not overlap.");
    }
  }
  return values;
}
function checkedInteger(value, minimum, maximum, name) {
  if (!Number.isSafeInteger(value) || value < minimum || value > maximum) {
    throw new Error(`${name} must be an integer in [${minimum}, ${maximum}].`);
  }
  return value;
}
function validatePackedCells(values, length) {
  if (!values || values.length !== length) {
    throw new Error(`Engine snapshot cell length mismatch: expected ${length}, received ${values == null ? void 0 : values.length}.`);
  }
  if (values instanceof Uint32Array && typedArrayName.call(values) === "Uint32Array") {
    const copy = new Uint32Array(values);
    if (copy.length !== length) throw new Error("Engine snapshot cell length mismatch.");
    return copy;
  }
  for (let index = 0; index < length; index += 1) {
    const value = values[index];
    if (!Number.isSafeInteger(value) || value < 0 || value > 4294967295) {
      checkedInteger(value, 0, 4294967295, `packedCells[${index}]`);
    }
  }
  return Uint32Array.from(values);
}
const sameKeys = (value, keys, label) => {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).length !== keys.length || keys.some((key) => !Object.hasOwn(value, key))) {
    throw new Error(`${label} has missing or unexpected fields.`);
  }
};
const integer = (value, min, max, label) => {
  if (typeof value !== "number") throw new Error(`${label} must be a number.`);
  checkedInteger(value, min, max, label);
};
function canonicalCatalog(catalog) {
  const stable = (value) => {
    if (Array.isArray(value)) return `[${value.map(stable).join(",")}]`;
    if (value && typeof value === "object") {
      return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stable(value[key])}`).join(",")}}`;
    }
    return JSON.stringify(value);
  };
  return stable({ ...catalog, materials: [...catalog.materials].sort((a, b) => a.id - b.id) });
}
function validateCatalog(value) {
  var _a;
  sameKeys(value, Object.keys(DEFAULT_CATALOG), "Catalog");
  const catalog = value;
  integer(catalog.schema_version, 4, 4, "schema_version");
  integer(catalog.capacity, 256, 256, "capacity");
  integer(catalog.cold_stride, 24, 24, "cold_stride");
  sameKeys(catalog.structure_fields, Object.keys(DEFAULT_CATALOG.structure_fields), "structure_fields");
  for (const [name, expected] of Object.entries(DEFAULT_CATALOG.structure_fields)) {
    const field = catalog.structure_fields[name];
    sameKeys(field, ["shift", "bits"], `structure_fields.${name}`);
    integer(field.shift, expected.shift, expected.shift, `${name}.shift`);
    integer(field.bits, expected.bits, expected.bits, `${name}.bits`);
  }
  sameKeys(catalog.bit_fields, Object.keys(DEFAULT_CATALOG.bit_fields), "bit_fields");
  for (const [name, expected] of Object.entries(DEFAULT_CATALOG.bit_fields)) {
    const field = catalog.bit_fields[name];
    sameKeys(field, ["shift", "bits", "signed"], `bit_fields.${name}`);
    if (field.shift !== expected.shift || field.bits !== expected.bits || field.signed !== expected.signed) throw new Error("Packed layout requires a new schema version.");
  }
  for (const [label, table] of [["phases", catalog.phases], ["flags", catalog.flags]]) {
    if (!table || typeof table !== "object" || Array.isArray(table)) throw new Error(`Invalid ${label}.`);
    const values = /* @__PURE__ */ new Set();
    for (const [name, id] of Object.entries(table)) {
      if (!/^[A-Z][A-Z_0-9]*$/.test(name)) throw new Error(`Invalid ${label} symbol.`);
      integer(id, label === "phases" ? 0 : 1, 15, name);
      if (values.has(id) || label === "flags" && (id & id - 1) !== 0) throw new Error(`Invalid ${label} value.`);
      values.add(id);
    }
    for (const [name, id] of Object.entries(DEFAULT_CATALOG[label])) {
      if (table[name] !== id) throw new Error(`Changing existing ${label} requires a new schema version.`);
    }
    if (label === "flags" && Object.keys(table).length !== Object.keys(DEFAULT_CATALOG.flags).length) throw new Error("Invalid flags.");
  }
  if (!Array.isArray(catalog.cold_fields) || catalog.cold_fields.length !== DEFAULT_CATALOG.cold_fields.length || Array.from(catalog.cold_fields).some((name, i) => name !== DEFAULT_CATALOG.cold_fields[i])) throw new Error("Cold table offsets require a new schema version.");
  if (!Array.isArray(catalog.materials) || !catalog.materials.length) throw new Error("materials must be a nonempty array.");
  const records = /* @__PURE__ */ new Map(), names = /* @__PURE__ */ new Set();
  for (const record of catalog.materials) {
    sameKeys(record, ["id", "name", "default_thermal", "color", "properties"], "Material");
    integer(record.id, 0, 255, "material.id");
    if (typeof record.name !== "string" || !/^[a-z][a-z_0-9]*$/.test(record.name)) throw new Error("Invalid material name.");
    if (records.has(record.id) || names.has(record.name)) throw new Error("Duplicate material ID or name.");
    if (typeof record.color !== "string" || !/^#[0-9a-fA-F]{6}$/.test(record.color)) throw new Error("Invalid material color.");
    integer(record.default_thermal, 0, 255, "default_thermal");
    sameKeys(record.properties, catalog.cold_fields, "Material properties");
    for (const [name, property] of Object.entries(record.properties)) integer(property, 0, name === "optical" ? 4294967295 : 255, name);
    if (!Object.values(catalog.phases).includes(record.properties.default_phase)) throw new Error("Undefined default phase.");
    if (![0, 1].includes(record.properties.oxidizer)) throw new Error("oxidizer must be 0 or 1.");
    if (record.properties.softening && !record.properties.cohesion) throw new Error("Softening requires nonzero cohesion.");
    records.set(record.id, record);
    names.add(record.name);
  }
  for (const builtin2 of DEFAULT_CATALOG.materials) {
    if (((_a = records.get(builtin2.id)) == null ? void 0 : _a.name) !== builtin2.name) throw new Error("Changing existing material IDs requires a new schema version.");
  }
  const up = (p) => [p.boils_into || p.melts_into, p.boils_into ? p.boil_point : p.melt_point];
  const down = (p) => [p.freezes_into || p.condenses_into, p.freezes_into ? p.freeze_point : p.condense_point];
  for (const record of records.values()) {
    const p = record.properties;
    for (const name of ["melts_into", "boils_into", "freezes_into", "condenses_into", "burns_into", "smoke_product"]) {
      if (!records.has(p[name])) throw new Error(`Undefined target ${record.name}.${name}.`);
    }
    for (const [threshold, target] of [["melt_point", "melts_into"], ["boil_point", "boils_into"], ["freeze_point", "freezes_into"], ["condense_point", "condenses_into"]]) {
      if (p[target] && !p[threshold]) throw new Error("Transition target requires a threshold.");
    }
    if (p.melts_into && p.boils_into || p.freezes_into && p.condenses_into) throw new Error("Only one upward and downward phase interval is supported.");
    if (p.fuel_energy && (!p.flash_point || !p.burns_into || !p.smoke_product)) throw new Error("Incomplete combustion definition.");
    if (p.oxidizer && (p.fuel_energy || p.phase_energy)) throw new Error("Oxidizer must have zero chemical and phase offsets.");
    const upward = up(p), downward = down(p);
    if (upward[0] && downward[0] && downward[1] >= upward[1]) throw new Error("Material phase intervals overlap.");
    for (const [transition, direction] of [[upward, 1], [downward, -1]]) {
      const [id, threshold] = transition;
      if (!id) continue;
      const target = records.get(id).properties;
      const difference = target.phase_energy - p.phase_energy;
      if (difference * direction <= 0) throw new Error("Phase energy must change monotonically.");
      if (direction > 0 && difference !== p[p.boils_into ? "latent_heat_boil" : "latent_heat_melt"]) throw new Error("Declared latent heat must equal the phase energy difference.");
      if (target.fuel_energy !== p.fuel_energy || target.oxidizer !== p.oxidizer) throw new Error("Phase changes must preserve chemical and oxidizer identity.");
      const reverse = direction > 0 ? down(target) : up(target);
      if (reverse[0] && (reverse[0] !== record.id || (direction > 0 ? reverse[1] >= threshold : threshold >= reverse[1]))) {
        throw new Error("Reverse phase edges require original identity and positive hysteresis.");
      }
    }
    if (p.fuel_energy) {
      for (const id of [p.burns_into, p.smoke_product]) {
        const product = records.get(id).properties;
        if (product.fuel_energy || product.oxidizer || product.phase_energy) throw new Error("Combustion products must be inert with zero phase offset.");
      }
    }
  }
}
const registries = /* @__PURE__ */ new WeakSet();
class ValidatedRegistry {
  constructor(catalog, hash) {
    __publicField(this, "hash");
    __publicField(this, "materialIds");
    __privateAdd(this, _catalog);
    __privateAdd(this, _records);
    __privateAdd(this, _cold);
    this.hash = hash;
    __privateSet(this, _catalog, catalog);
    __privateSet(this, _records, new Map(catalog.materials.map((record) => [record.id, record])));
    this.materialIds = Object.freeze([...__privateGet(this, _records).keys()].sort((a, b) => a - b));
    __privateSet(this, _cold, new Uint32Array(catalog.capacity * catalog.cold_stride));
    for (const record of catalog.materials) {
      __privateGet(this, _cold).set(catalog.cold_fields.map((name) => record.properties[name]), record.id * catalog.cold_stride);
      Object.freeze(record.properties);
      Object.freeze(record);
    }
    registries.add(this);
    Object.freeze(this);
  }
  has(material2) {
    return __privateGet(this, _records).has(material2);
  }
  material(material2) {
    integer(material2, 0, 255, "material");
    const record = __privateGet(this, _records).get(material2);
    if (!record) throw new Error(`Undefined material: ${material2}`);
    return record;
  }
  toCatalog() {
    return structuredClone(__privateGet(this, _catalog));
  }
  coldTable() {
    return __privateGet(this, _cold).slice();
  }
  extend(materials) {
    return createMaterialRegistry({ ...this.toCatalog(), materials: [...this.toCatalog().materials, ...materials] });
  }
}
_catalog = new WeakMap();
_records = new WeakMap();
_cold = new WeakMap();
const builtin = structuredClone(DEFAULT_CATALOG);
validateCatalog(builtin);
const DEFAULT_REGISTRY = new ValidatedRegistry(builtin, MATERIAL_CATALOG_HASH);
async function createMaterialRegistry(value) {
  const catalog = structuredClone(value);
  validateCatalog(catalog);
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(canonicalCatalog(catalog)));
  const hash = Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
  return new ValidatedRegistry(catalog, hash);
}
const ENERGY_SCALE = 256;
const MAX_ENERGY_Q = 1073741823;
const prop = (v, cold2, field) => cold2[(v & 255) * COLD_STRIDE + field];
function temperatureQ(voxel, energy, cold2) {
  const heat = energy - prop(voxel, cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE;
  const phase2 = prop(voxel, cold2, COLD_PHASE_ENERGY) * ENERGY_SCALE;
  let temperature = Math.max(0, heat - phase2);
  const boil = prop(voxel, cold2, COLD_BOILS_INTO);
  const up = boil || prop(voxel, cold2, COLD_MELTS_INTO);
  const upTemperature = prop(voxel, cold2, boil ? COLD_BOIL_POINT : COLD_MELT_POINT) * ENERGY_SCALE;
  const freeze = prop(voxel, cold2, COLD_FREEZES_INTO);
  const down = freeze || prop(voxel, cold2, COLD_CONDENSES_INTO);
  const downTemperature = prop(voxel, cold2, freeze ? COLD_FREEZE_POINT : COLD_CONDENSE_POINT) * ENERGY_SCALE;
  if (up && heat >= phase2 + upTemperature) {
    temperature = Math.max(upTemperature, heat - prop(up, cold2, COLD_PHASE_ENERGY) * ENERGY_SCALE);
  } else if (down && heat <= phase2 + downTemperature) {
    temperature = Math.min(downTemperature, Math.max(0, heat - prop(down, cold2, COLD_PHASE_ENERGY) * ENERGY_SCALE));
  }
  return temperature;
}
function thermalView(voxel, energy, cold2) {
  return (voxel & 4294902015 | Math.min(255, Math.floor(temperatureQ(voxel, energy, cold2) / ENERGY_SCALE)) << 8) >>> 0;
}
function seedState(values, cold2 = buildColdTable(), registry = DEFAULT_REGISTRY) {
  const grid = validatePackedCells(values, values.length);
  const energyQ = new Uint32Array(grid.length);
  for (let i = 0; i < grid.length; i += 1) {
    const v = grid[i];
    if (!registry.has(v & 255)) throw new Error("Undefined material in initial state.");
    energyQ[i] = ((v >>> 8 & 255) + prop(v, cold2, COLD_PHASE_ENERGY) + prop(v, cold2, COLD_FUEL_ENERGY)) * ENERGY_SCALE;
    grid[i] = thermalView(v, energyQ[i], cold2);
  }
  return { grid, energyQ };
}
function validateEnergyState(cells, energies, length, cold2 = buildColdTable(), registry = DEFAULT_REGISTRY) {
  const grid = validatePackedCells(cells, length);
  const energyQ = validatePackedCells(energies, length);
  for (let i = 0; i < length; i += 1) {
    const v = grid[i];
    if (!registry.has(v & 255)) throw new Error("Undefined material in simulation state.");
    const minimum = prop(v, cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE;
    if (energyQ[i] < minimum || energyQ[i] > MAX_ENERGY_Q) checkedInteger(energyQ[i], minimum, MAX_ENERGY_Q, `energyQ[${i}]`);
    if (thermalView(v, energyQ[i], cold2) !== v) throw new Error("Packed thermal view disagrees with conserved energy.");
  }
  return { grid, energyQ };
}
function exchangeEnergy(a, b, ea, eb, cold2) {
  const ta = temperatureQ(a, ea, cold2), tb = temperatureQ(b, eb, cold2);
  const ca = prop(a, cold2, COLD_CONDUCTIVITY), cb = prop(b, cold2, COLD_CONDUCTIVITY);
  const k = ca + cb ? Math.floor(2 * ca * cb / (ca + cb)) : 0;
  const difference = Math.abs(ta - tb);
  let flux = Math.floor(difference / 512) * k + Math.floor((difference % 512 * k + 511) / 512);
  flux = Math.min(flux, Math.floor(difference / 2));
  if (ta > tb) {
    flux = Math.min(flux, ea - prop(a, cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE, MAX_ENERGY_Q - eb);
    return [ea - flux, eb + flux];
  }
  flux = Math.min(flux, eb - prop(b, cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE, MAX_ENERGY_Q - ea);
  return [ea + flux, eb - flux];
}
function phaseMaterial(v, energy, cold2) {
  const chemical = prop(v, cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE;
  const boil = prop(v, cold2, COLD_BOILS_INTO);
  const up = boil || prop(v, cold2, COLD_MELTS_INTO);
  if (up) {
    const boundary = chemical + (prop(up, cold2, COLD_PHASE_ENERGY) + prop(v, cold2, boil ? COLD_BOIL_POINT : COLD_MELT_POINT)) * ENERGY_SCALE;
    if (energy >= boundary) return up;
  }
  const freeze = prop(v, cold2, COLD_FREEZES_INTO);
  const down = freeze || prop(v, cold2, COLD_CONDENSES_INTO);
  if (down) {
    const boundary = chemical + (prop(down, cold2, COLD_PHASE_ENERGY) + prop(v, cold2, freeze ? COLD_FREEZE_POINT : COLD_CONDENSE_POINT)) * ENERGY_SCALE;
    if (energy <= boundary) return down;
  }
  return v & 255;
}
function rewriteMaterial(voxel, material2, energy, cold2) {
  const packed = (voxel & 4043243520 | material2 | prop(material2, cold2, COLD_DEFAULT_PHASE) << PHASE_SHIFT) >>> 0;
  return thermalView(packed, energy, cold2);
}
function energyLedger(state, cold2 = buildColdTable()) {
  let sensibleQ = 0n, latentQ = 0n, chemicalQ = 0n;
  for (let i = 0; i < state.grid.length; i += 1) {
    const chemical = prop(state.grid[i], cold2, COLD_FUEL_ENERGY) * ENERGY_SCALE;
    const sensible = temperatureQ(state.grid[i], state.energyQ[i], cold2);
    sensibleQ += BigInt(sensible);
    chemicalQ += BigInt(chemical);
    latentQ += BigInt(state.energyQ[i] - chemical - sensible);
  }
  return { sensibleQ, latentQ, chemicalQ, totalQ: sensibleQ + latentQ + chemicalQ };
}
const SCHEMA_VERSION_3D = 1;
const RULES_VERSION_3D = "ca-3d-m1";
const MAX_CELLS_3D = 32768;
const MATERIAL_CATALOG_HASH_3D = DEFAULT_REGISTRY.hash;
const cold$4 = buildColdTable();
const arrayPrototype = Object.getPrototypeOf(Uint32Array.prototype);
const arrayLength = Object.getOwnPropertyDescriptor(arrayPrototype, "length").get;
const arrayBuffer = Object.getOwnPropertyDescriptor(arrayPrototype, "buffer").get;
const arrayOffset = Object.getOwnPropertyDescriptor(arrayPrototype, "byteOffset").get;
const arrayName = Object.getOwnPropertyDescriptor(arrayPrototype, Symbol.toStringTag).get;
const MATERIALS_3D = Object.freeze([
  MAT.AIR,
  MAT.STONE,
  MAT.SAND,
  MAT.WATER,
  MAT.ICE,
  MAT.STEAM,
  MAT.LAVA,
  MAT.GLASS,
  MAT.MOLTEN_GLASS
].map((id) => DEFAULT_REGISTRY.material(id)));
const supported$1 = new Set(MATERIALS_3D.map((m) => m.id));
const material$1 = (v) => v & 255;
const phase$1 = (v) => v >>> PHASE_SHIFT & 15;
const fixed = (v) => phase$1(v) === PHASE.SOLID || phase$1(v) === PHASE.FROZEN;
const liquid$1 = (v) => phase$1(v) === PHASE.LIQUID || phase$1(v) === PHASE.VISCOUS || phase$1(v) === PHASE.MOLTEN;
const falling$1 = (v) => phase$1(v) === PHASE.POWDER || liquid$1(v);
const gas$1 = (v) => phase$1(v) === PHASE.GAS;
const density$1 = (v) => cold$4[material$1(v) * COLD_STRIDE + COLD_DENSITY];
function dimensions(w, h, d, maximum = MAX_CELLS_3D) {
  for (const [key, value] of [["width", w], ["height", h], ["depth", d]]) checkedInteger(value, 1, maximum, key);
  return checkedInteger(w * h * d, 1, maximum, "volume cell count");
}
function requireMaterial(id) {
  checkedInteger(id, 0, 255, "material");
  if (!supported$1.has(id)) throw new Error("Material is not supported by ca-3d-m1.");
}
function placement$1(id, thermal) {
  requireMaterial(id);
  const record = DEFAULT_REGISTRY.material(id);
  checkedInteger(thermal ?? record.default_thermal, 0, 255, "thermal");
  return seedState([id | (thermal ?? record.default_thermal) << 8 | record.properties.default_phase << PHASE_SHIFT]);
}
function validateState(cells, energies, count) {
  const state = validateEnergyState(cells, energies, count);
  for (const v of state.grid) {
    requireMaterial(material$1(v));
    if ((v & 4043243520) !== 0 || phase$1(v) !== DEFAULT_REGISTRY.material(material$1(v)).properties.default_phase) {
      throw new Error("3D M1 requires the material default phase and zero velocity/flags.");
    }
  }
  return state;
}
function validateVolumeSnapshot(value, maximum = MAX_CELLS_3D) {
  const keys = ["schemaVersion", "rulesVersion", "materialCatalogHash", "width", "height", "depth", "tick", "packedCells", "energyQ"];
  if (!value || typeof value !== "object" || Object.keys(value).length !== keys.length || keys.some((k) => !Object.hasOwn(value, k))) {
    throw new Error("3D snapshot contains missing or unexpected fields.");
  }
  if (value.schemaVersion !== SCHEMA_VERSION_3D || value.rulesVersion !== RULES_VERSION_3D || value.materialCatalogHash !== MATERIAL_CATALOG_HASH_3D) {
    throw new Error("Incompatible 3D snapshot version or catalog.");
  }
  checkedInteger(value.tick, 0, Number.MAX_SAFE_INTEGER, "tick");
  return validateState(value.packedCells, value.energyQ, dimensions(value.width, value.height, value.depth, maximum));
}
function choice$1(index, axis, tick) {
  let h = Math.imul(index, 374761393) + Math.imul(axis, 668265263) + Math.imul(tick >>> 0, 1442695041) >>> 0;
  h = Math.imul(h ^ h >>> 13, 1274126177) >>> 0;
  return ((h ^ h >>> 16) & 1) === 0;
}
function volumeSchedule(tick) {
  checkedInteger(tick, 0, Number.MAX_SAFE_INTEGER, "tick");
  const passes = [];
  const pairs = (kind, axis, direction = 1) => {
    for (const parity of [0, 1]) passes.push({ kind, axis, parity, direction });
  };
  pairs("gravity", 1);
  const directions = [[0, 1], [0, -1], [2, 1], [2, -1]];
  for (let k = 0; k < 4; k++) {
    const [axis, direction] = directions[(k + tick % 4) % 4];
    pairs("diagonal", axis, direction);
  }
  const axes = tick % 2 ? [2, 0] : [0, 2];
  for (const axis of axes) pairs("liquid", axis);
  pairs("buoyancy", 1);
  for (const axis of axes) pairs("gas", axis);
  for (const axis of [0, 1, 2]) pairs("heat", axis);
  passes.push({ kind: "phase", axis: 0, parity: 0, direction: 1 });
  return passes;
}
function executePass(input, output, w, h, d, tick, pass) {
  const aGrid = input.grid, aEnergy = input.energyQ, bGrid = output.grid, bEnergy = output.energyQ;
  bGrid.set(aGrid);
  bEnergy.set(aEnergy);
  const layer = w * h;
  const bound = (index) => fixed(aGrid[index]);
  const canFall = (source, target) => falling$1(aGrid[source]) && !bound(source) && !bound(target) && density$1(aGrid[source]) > density$1(aGrid[target]);
  const gasRank = (i) => Math.floor(temperatureQ(aGrid[i], aEnergy[i], cold$4) / 256) * 2 - density$1(aGrid[i]);
  const canRise = (s, t) => material$1(aGrid[s]) !== MAT.AIR && gas$1(aGrid[s]) && gas$1(aGrid[t]) && gasRank(s) > gasRank(t) + 16;
  const swap = (s, t) => {
    bGrid[s] = aGrid[t];
    bGrid[t] = aGrid[s];
    bEnergy[s] = aEnergy[t];
    bEnergy[t] = aEnergy[s];
  };
  const hasFall = (i, x, y, z) => y + 1 < h && (canFall(i, i + w) || x > 0 && canFall(i, i + w - 1) || x + 1 < w && canFall(i, i + w + 1) || z > 0 && canFall(i, i + w - layer) || z + 1 < d && canFall(i, i + w + layer));
  if (pass.kind === "phase") {
    for (let i = 0; i < aGrid.length; i++) {
      const next = phaseMaterial(aGrid[i], aEnergy[i], cold$4);
      if (next !== material$1(aGrid[i])) bGrid[i] = rewriteMaterial(aGrid[i], next, aEnergy[i], cold$4);
    }
    return;
  }
  const vertical = ["gravity", "diagonal", "buoyancy"].includes(pass.kind);
  const pairAxis = vertical ? 1 : pass.axis;
  for (let z = pairAxis === 2 ? pass.parity : 0; z < d; z += pairAxis === 2 ? 2 : 1) {
    for (let y = pairAxis === 1 ? pass.parity : 0; y < h; y += pairAxis === 1 ? 2 : 1) {
      for (let x = pairAxis === 0 ? pass.parity : 0; x < w; x += pairAxis === 0 ? 2 : 1) {
        let tx = x + (pairAxis === 0 ? 1 : 0), ty = y + (pairAxis === 1 ? 1 : 0), tz = z + (pairAxis === 2 ? 1 : 0);
        if (pass.kind === "diagonal") {
          tx += pass.axis === 0 ? pass.direction : 0;
          tz += pass.axis === 2 ? pass.direction : 0;
        }
        if (tx < 0 || tx >= w || ty >= h || tz < 0 || tz >= d) continue;
        const a = x + w * (y + h * z), b = tx + w * (ty + h * tz);
        if (pass.kind === "gravity") {
          if (canFall(a, b)) swap(a, b);
        } else if (pass.kind === "diagonal") {
          if (!canFall(a, a + w) && canFall(a, b)) swap(a, b);
        } else if (pass.kind === "buoyancy") {
          if (canRise(b, a)) swap(a, b);
        } else if (pass.kind === "liquid") {
          const spread = (s, t) => liquid$1(aGrid[s]) && gas$1(aGrid[t]) && density$1(aGrid[s]) > density$1(aGrid[t]);
          if (spread(a, b) && !hasFall(a, x, y, z) || spread(b, a) && !hasFall(b, tx, ty, tz)) swap(a, b);
        } else if (pass.kind === "gas") {
          const [s, t, sy] = choice$1(a, pass.axis, tick) ? [a, b, y] : [b, a, ty];
          if (material$1(aGrid[s]) !== MAT.AIR && gas$1(aGrid[s]) && gas$1(aGrid[t]) && (sy === 0 || !canRise(s, s - w)) && (material$1(aGrid[t]) === MAT.AIR || gasRank(s) > gasRank(t) + 16)) swap(s, t);
        } else if (pass.kind === "heat") {
          if (material$1(aGrid[a]) === material$1(aGrid[b]) && aEnergy[a] === aEnergy[b]) continue;
          [bEnergy[a], bEnergy[b]] = exchangeEnergy(aGrid[a], aGrid[b], aEnergy[a], aEnergy[b], cold$4);
          bGrid[a] = thermalView(aGrid[a], bEnergy[a], cold$4);
          bGrid[b] = thermalView(aGrid[b], bEnergy[b], cold$4);
        }
      }
    }
  }
}
class CpuVolume {
  constructor(w, h, d, fill, maximum = MAX_CELLS_3D) {
    __privateAdd(this, _CpuVolume_instances);
    __publicField(this, "width");
    __publicField(this, "height");
    __publicField(this, "depth");
    __privateAdd(this, _state);
    __privateAdd(this, _spare);
    __privateAdd(this, _tick, 0);
    __privateAdd(this, _initial, 0n);
    __privateAdd(this, _external, 0n);
    __privateAdd(this, _maximum);
    const count = dimensions(w, h, d, maximum), seed = placement$1(fill);
    __privateSet(this, _maximum, maximum);
    this.width = w;
    this.height = h;
    this.depth = d;
    for (const key of ["width", "height", "depth"]) Object.defineProperty(this, key, { writable: false, configurable: false });
    __privateSet(this, _state, { grid: new Uint32Array(count).fill(seed.grid[0]), energyQ: new Uint32Array(count).fill(seed.energyQ[0]) });
    __privateSet(this, _spare, { grid: new Uint32Array(count), energyQ: new Uint32Array(count) });
    __privateSet(this, _initial, __privateMethod(this, _CpuVolume_instances, total_fn).call(this));
  }
  get tick() {
    return __privateGet(this, _tick);
  }
  get grid() {
    return __privateGet(this, _state).grid.slice();
  }
  get energyQ() {
    return __privateGet(this, _state).energyQ.slice();
  }
  step(ticks = 1) {
    checkedInteger(ticks, 0, 1024, "ticks per request");
    checkedInteger(__privateGet(this, _tick) + ticks, 0, Number.MAX_SAFE_INTEGER, "end tick");
    for (let n = 0; n < ticks; n++) {
      for (const pass of volumeSchedule(__privateGet(this, _tick))) {
        executePass(__privateGet(this, _state), __privateGet(this, _spare), this.width, this.height, this.depth, __privateGet(this, _tick), pass);
        [__privateWrapper(this, _state)._, __privateWrapper(this, _spare)._] = [__privateGet(this, _spare), __privateGet(this, _state)];
      }
      __privateWrapper(this, _tick)._++;
    }
  }
  sample(x, y, z) {
    const i = __privateMethod(this, _CpuVolume_instances, index_fn).call(this, x, y, z), v = __privateGet(this, _state).grid[i], energyQ = __privateGet(this, _state).energyQ[i];
    return {
      material: material$1(v),
      materialName: DEFAULT_REGISTRY.material(material$1(v)).name,
      phase: phase$1(v),
      thermal: v >>> 8 & 255,
      temperatureQ: temperatureQ(v, energyQ, cold$4),
      energyQ
    };
  }
  setCell(x, y, z, id, thermal) {
    const i = __privateMethod(this, _CpuVolume_instances, index_fn).call(this, x, y, z), seed = placement$1(id, thermal);
    __privateSet(this, _external, __privateGet(this, _external) + (BigInt(seed.energyQ[0]) - BigInt(__privateGet(this, _state).energyQ[i])));
    __privateGet(this, _state).grid[i] = seed.grid[0];
    __privateGet(this, _state).energyQ[i] = seed.energyQ[0];
  }
  setEnergy(x, y, z, q) {
    const i = __privateMethod(this, _CpuVolume_instances, index_fn).call(this, x, y, z);
    checkedInteger(q, 0, MAX_ENERGY_Q, "energyQ");
    __privateSet(this, _external, __privateGet(this, _external) + (BigInt(q) - BigInt(__privateGet(this, _state).energyQ[i])));
    __privateGet(this, _state).energyQ[i] = q;
    __privateGet(this, _state).grid[i] = thermalView(__privateGet(this, _state).grid[i], q, cold$4);
  }
  copyStateInto(target) {
    const count = __privateGet(this, _state).grid.length;
    const values = ["grid", "energyQ"].map((k) => {
      var _a;
      return target && ((_a = Object.getOwnPropertyDescriptor(target, k)) == null ? void 0 : _a.value);
    });
    if (values.some((v) => !(v instanceof Uint32Array) || arrayName.call(v) !== "Uint32Array" || arrayLength.call(v) !== count || !(arrayBuffer.call(v) instanceof ArrayBuffer))) throw new Error("State copy needs two owned Uint32Arrays of the volume cell count.");
    const [grid, energies] = values;
    if (arrayBuffer.call(grid) === arrayBuffer.call(energies) && Math.abs(arrayOffset.call(grid) - arrayOffset.call(energies)) < count * 4) throw new Error("State copy coordinates overlap.");
    Uint32Array.prototype.set.call(grid, __privateGet(this, _state).grid);
    Uint32Array.prototype.set.call(energies, __privateGet(this, _state).energyQ);
    return __privateGet(this, _tick);
  }
  snapshot() {
    return {
      schemaVersion: SCHEMA_VERSION_3D,
      rulesVersion: RULES_VERSION_3D,
      materialCatalogHash: MATERIAL_CATALOG_HASH_3D,
      width: this.width,
      height: this.height,
      depth: this.depth,
      tick: __privateGet(this, _tick),
      packedCells: Array.from(__privateGet(this, _state).grid),
      energyQ: Array.from(__privateGet(this, _state).energyQ)
    };
  }
  restore(snapshot) {
    const next = validateVolumeSnapshot(snapshot, __privateGet(this, _maximum));
    if (snapshot.width !== this.width || snapshot.height !== this.height || snapshot.depth !== this.depth) throw new Error("3D snapshot geometry differs from the field.");
    __privateSet(this, _state, next);
    __privateSet(this, _tick, snapshot.tick);
    __privateSet(this, _initial, __privateMethod(this, _CpuVolume_instances, total_fn).call(this));
    __privateSet(this, _external, 0n);
  }
  energyLedger() {
    return energyLedger(__privateGet(this, _state), cold$4);
  }
  energyBalance() {
    const currentQ = __privateMethod(this, _CpuVolume_instances, total_fn).call(this);
    return { initialQ: __privateGet(this, _initial), externalQ: __privateGet(this, _external), currentQ, driftQ: currentQ - __privateGet(this, _initial) - __privateGet(this, _external) };
  }
}
_state = new WeakMap();
_spare = new WeakMap();
_tick = new WeakMap();
_initial = new WeakMap();
_external = new WeakMap();
_maximum = new WeakMap();
_CpuVolume_instances = new WeakSet();
total_fn = function() {
  let sum = 0;
  for (const q of __privateGet(this, _state).energyQ) sum += q;
  return BigInt(sum);
};
index_fn = function(x, y, z) {
  checkedInteger(x, 0, this.width - 1, "x");
  checkedInteger(y, 0, this.height - 1, "y");
  checkedInteger(z, 0, this.depth - 1, "z");
  return x + this.width * (y + this.height * z);
};
function createStateSpaceField3D(width, height, depth, fillMaterial = MAT.AIR) {
  return new CpuVolume(width, height, depth, fillMaterial);
}
function activeWorldGeometry(options = {}) {
  if (!options || typeof options !== "object" || Array.isArray(options) || Object.keys(options).some((k) => !["width", "height", "depth", "chunkSize", "fillMaterial"].includes(k))) throw new Error("Invalid world options.");
  const { width = 128, height = 128, depth = 128, chunkSize = 32 } = options;
  for (const n of [width, height, depth]) checkedInteger(n, 1, 128, "world dimension");
  checkedInteger(chunkSize, 4, 32, "chunk size");
  if (chunkSize & chunkSize - 1 || [width, height, depth].some((n) => n % chunkSize) || width * height * depth / chunkSize ** 3 > 512) throw new Error("World requires power-of-two chunks, complete chunks and at most 512 chunks.");
  return { width, height, depth, chunkSize };
}
function checkedActiveWorldRegion(request, geometry) {
  if (!request || !Array.isArray(request.origin) || !Array.isArray(request.size) || request.origin.length !== 3 || request.size.length !== 3) throw new Error("Region needs three origin and size coordinates.");
  const shape = [geometry.width, geometry.height, geometry.depth], origin = [], size = [];
  for (let i = 0; i < 3; i++) {
    size.push(checkedInteger(request.size[i], 1, shape[i], "region size"));
    origin.push(checkedInteger(request.origin[i], 0, shape[i] - size[i], "region origin"));
  }
  checkedInteger(size[0] * size[1] * size[2], 1, 4096, "region cell count");
  return { origin, size };
}
const VOLUME_SHADER = `
struct Params { shape: vec4u, rule: vec4u, tick: vec4u }
@group(0) @binding(0) var<storage, read> cells: array<u32>;
@group(0) @binding(1) var<storage, read> energies: array<u32>;
@group(0) @binding(2) var<storage, read_write> nextCells: array<u32>;
@group(0) @binding(3) var<storage, read_write> nextEnergies: array<u32>;
@group(0) @binding(4) var<storage, read> cold: array<u32>;
@group(0) @binding(5) var<uniform> p: Params;
const MAX_Q = 0x3fffffffu;
fn prop(v: u32, f: u32) -> u32 { return cold[(v & 255u) * 24u + f]; }
fn temperature(v: u32, q: u32) -> u32 {
  let heat = q - prop(v,16u)*256u; let latent = prop(v,19u)*256u;
  var t = max(0, i32(heat)-i32(latent));
  let boil = prop(v,13u); let up = select(prop(v,12u),boil,boil!=0u);
  let ut = prop(v,select(2u,3u,boil!=0u))*256u;
  let freeze = prop(v,14u); let down = select(prop(v,15u),freeze,freeze!=0u);
  let dt = prop(v,select(9u,8u,freeze!=0u))*256u;
  if (up!=0u && heat>=latent+ut) { t=max(i32(ut),i32(heat)-i32(prop(up,19u)*256u)); }
  else if (down!=0u && heat<=latent+dt) { t=min(i32(dt),max(0,i32(heat)-i32(prop(down,19u)*256u))); }
  return u32(t);
}
fn thermal(v:u32,q:u32)->u32 { return (v&0xffff00ffu)|(min(255u,temperature(v,q)/256u)<<8u); }
fn transition(v:u32,q:u32)->u32 {
  let chemical=prop(v,16u)*256u;
  let boil=prop(v,13u); let up=select(prop(v,12u),boil,boil!=0u);
  if(up!=0u && q>=chemical+(prop(up,19u)+prop(v,select(2u,3u,boil!=0u)))*256u) {return up;}
  let freeze=prop(v,14u); let down=select(prop(v,15u),freeze,freeze!=0u);
  if(down!=0u && q<=chemical+(prop(down,19u)+prop(v,select(9u,8u,freeze!=0u)))*256u) {return down;}
  return v&255u;
}
fn pairEnergy(a:u32,b:u32,ea:u32,eb:u32)->u32 {
  let ta=temperature(a,ea); let tb=temperature(b,eb);
  let ca=prop(a,1u); let cb=prop(b,1u); var k=0u;
  if(ca+cb>0u){k=2u*ca*cb/(ca+cb);}
  let diff=u32(abs(i32(ta)-i32(tb)));
  var flux=min(diff/512u*k+(diff%512u*k+511u)/512u,diff/2u);
  if(ta>tb){flux=min(flux,min(ea-prop(a,16u)*256u,MAX_Q-eb)); return ea-flux;}
  flux=min(flux,min(eb-prop(b,16u)*256u,MAX_Q-ea)); return ea+flux;
}
fn phase(v:u32)->u32{return (v>>24u)&15u;}
fn fixed(v:u32)->bool{return phase(v)==0u||phase(v)==6u;}
fn liquid(v:u32)->bool{let s=phase(v);return s==2u||s==3u||s==7u;}
fn falling(v:u32)->bool{return phase(v)==1u||liquid(v);}
fn gas(v:u32)->bool{return phase(v)==4u;}
fn fall(s:u32,t:u32)->bool{return falling(cells[s])&&!fixed(cells[s])&&!fixed(cells[t])&&prop(cells[s],0u)>prop(cells[t],0u);}
fn rank(i:u32)->i32{return i32(temperature(cells[i],energies[i])/256u)*2-i32(prop(cells[i],0u));}
fn rise(s:u32,t:u32)->bool{return (cells[s]&255u)!=0u&&gas(cells[s])&&gas(cells[t])&&rank(s)>rank(t)+16;}
fn index(c:vec3i)->u32{return u32(c.x)+p.shape.x*(u32(c.y)+p.shape.y*u32(c.z));}
fn inside(c:vec3i)->bool{return all(c>=vec3i(0))&&all(c<vec3i(p.shape.xyz));}
fn hasFall(i:u32,c:vec3i)->bool{
  if(c.y+1>=i32(p.shape.y)){return false;}
  let b=c+vec3i(0,1,0); if(fall(i,index(b))){return true;}
  let offsets=array<vec3i,4>(vec3i(1,0,0),vec3i(-1,0,0),vec3i(0,0,1),vec3i(0,0,-1));
  for(var k=0u;k<4u;k++){let t=b+offsets[k];if(inside(t)&&fall(i,index(t))){return true;}}
  return false;
}
fn spread(s:u32,t:u32)->bool{return liquid(cells[s])&&gas(cells[t])&&prop(cells[s],0u)>prop(cells[t],0u);}
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) id:vec3u){
  let i=id.x; if(i>=p.shape.w){return;}
  let v=cells[i]; let q=energies[i]; var outV=v;var outQ=q;
  let kind=p.rule.x;
  if(kind==6u){let m=transition(v,q);if(m!=(v&255u)){outV=thermal((v&0xf0ff0000u)|m|(prop(m,20u)<<24u),q);}}
  else {
    let c=vec3i(vec3u(i%p.shape.x,(i/p.shape.x)%p.shape.y,i/(p.shape.x*p.shape.y)));
    let vertical=kind==0u||kind==1u||kind==3u;
    let axis=select(p.rule.y,1u,vertical); let lower=(u32(c[axis])&1u)!=p.rule.z;
    var delta=vec3i(0);delta[axis]=1;
    if(kind==1u){delta[p.rule.y]=i32(p.rule.w);}
    let a=c-select(vec3i(0),delta,lower); let b=a+delta;
    if(inside(a)&&inside(b)){
      let ai=index(a);let bi=index(b);var swap=false;
      if(kind==0u){swap=fall(ai,bi);}
      else if(kind==1u){swap=!fall(ai,index(a+vec3i(0,1,0)))&&fall(ai,bi);}
      else if(kind==2u){swap=(spread(ai,bi)&&!hasFall(ai,a))||(spread(bi,ai)&&!hasFall(bi,b));}
      else if(kind==3u){swap=rise(bi,ai);}
      else if(kind==4u){
        var hash=ai*374761393u+p.rule.y*668265263u+p.tick.x*1442695041u;
        hash=(hash^(hash>>13u))*1274126177u;
        let choose=((hash^(hash>>16u))&1u)==0u;
        let s=select(bi,ai,choose);let t=select(ai,bi,choose);let sy=select(b.y,a.y,choose);
        swap=(cells[s]&255u)!=0u&&gas(cells[s])&&gas(cells[t])&&(sy==0||!rise(s,s-p.shape.x))&&((cells[t]&255u)==0u||rank(s)>rank(t)+16);
      } else if(kind==5u){
        // Valid states already have normalized thermal bits. This is the same
        // exact no-op used by the CPU reference for equal material/energy pairs.
        if((cells[ai]&255u)!=(cells[bi]&255u)||energies[ai]!=energies[bi]){
          let eq=pairEnergy(cells[ai],cells[bi],energies[ai],energies[bi]);
          outQ=select(eq,energies[ai]+energies[bi]-eq,lower);outV=thermal(v,outQ);
        }
      }
      if(swap){let other=select(bi,ai,lower);outV=cells[other];outQ=energies[other];}
    }
  }
  nextCells[i]=outV;nextEnergies[i]=outQ;
}
`;
const ACCESS_SHADER = VOLUME_SHADER.slice(0, VOLUME_SHADER.indexOf("@compute")) + `
@group(0) @binding(6) var<storage, read> edits:array<vec4u>;
@group(0) @binding(7) var<storage, read_write> results:array<u32>;
@compute @workgroup_size(64) fn edit(@builtin(global_invocation_id) id:vec3u){
  if(id.x>=p.tick.y){return;}let e=edits[id.x];let old=nextEnergies[e.x];
  if(e.y==0u){nextCells[e.x]=e.z;nextEnergies[e.x]=e.w;}
  else{nextCells[e.x]=thermal(nextCells[e.x],e.w);nextEnergies[e.x]=e.w;}
  results[id.x*2u]=old;results[id.x*2u+1u]=e.w;
}
@compute @workgroup_size(64) fn query(@builtin(global_invocation_id) id:vec3u){
  let i=id.x;let size=p.rule.xyz; if(i>=size.x*size.y*size.z){return;}
  let c=p.tick.xyz+vec3u(i%size.x,(i/size.x)%size.y,i/(size.x*size.y));
  results[i]=cells[index(vec3i(c))];
}
`;
function chunkShaders(edge) {
  if (!edge) return { physics: VOLUME_SHADER, access: ACCESS_SHADER };
  const mapping = `
const EDGE=${edge}u;
fn linear(c:vec3i)->u32{return u32(c.x)+p.shape.x*(u32(c.y)+p.shape.y*u32(c.z));}
fn index(c:vec3i)->u32{
 let u=vec3u(c);let n=p.shape.xyz/EDGE;let k=u/EDGE;let local=u%EDGE;
 return (k.x+n.x*(k.y+n.y*k.z))*EDGE*EDGE*EDGE+local.x+EDGE*(local.y+EDGE*local.z);
}
fn coordinate(i:u32)->vec3i{
 let n=p.shape.xyz/EDGE;let k=i/(EDGE*EDGE*EDGE);let local=i%(EDGE*EDGE*EDGE);
 return vec3i(vec3u(k%n.x,(k/n.x)%n.y,k/(n.x*n.y))*EDGE+vec3u(local%EDGE,(local/EDGE)%EDGE,local/(EDGE*EDGE)));
}
`;
  const translate = (code) => code.replace("fn index(c:vec3i)->u32{return u32(c.x)+p.shape.x*(u32(c.y)+p.shape.y*u32(c.z));}", mapping).replace("let c=vec3i(vec3u(i%p.shape.x,(i/p.shape.x)%p.shape.y,i/(p.shape.x*p.shape.y)));", "let c=coordinate(i);").replace("var hash=ai*374761393u", "var hash=linear(a)*374761393u").replace("!rise(s,s-p.shape.x)", "!rise(s,index(select(b,a,choose)+vec3i(0,-1,0)))");
  const dirty = `
@group(0) @binding(6) var<storage,read_write> dirty:array<atomic<u32>>;
fn mark(c:vec3i){
 let n=p.shape.xyz/EDGE;let k=vec3u(c)/EDGE;
 atomicStore(&dirty[k.x+n.x*(k.y+n.y*k.z)],1u);
}
fn changed(c:vec3i){
 mark(c);
 for(var axis=0u;axis<3u;axis++){
  var t=c;t[axis]-=1;
  if(inside(t)&&u32(c[axis])%EDGE==0u){mark(t);}
  t=c;t[axis]+=1;
  if(inside(t)&&u32(t[axis])%EDGE==0u){mark(t);}
 }
}
`;
  const physics = translate(VOLUME_SHADER).replace("@compute @workgroup_size(64) fn main", dirty + "\n@compute @workgroup_size(64) fn main").replace("nextCells[i]=outV;nextEnergies[i]=outQ;", "if((v&255u)!=(outV&255u)){changed(coordinate(i));}\n  nextCells[i]=outV;nextEnergies[i]=outQ;");
  return { physics, access: translate(ACCESS_SHADER) };
}
function structuralShaders(edge, shape) {
  const base = chunkShaders(edge).physics;
  const replace = (source, from, to) => {
    if (source.split(from).length !== 2) throw Error("M5 material template differs from the frozen M1 law.");
    return source.replace(from, to);
  };
  const mechanical = `
@group(0) @binding(7) var<storage,read> structures:array<u32>;
@group(0) @binding(8) var<storage,read_write> nextStructures:array<u32>;
const INTEGRITY=255u;const ANCHOR=16384u;const FRESH=32768u;const INF=0xffffffffu;
const NORMALS=array<vec3i,6>(vec3i(-1,0,0),vec3i(1,0,0),vec3i(0,-1,0),vec3i(0,1,0),vec3i(0,0,-1),vec3i(0,0,1));
fn eligible(v:u32)->bool{return fixed(v)&&prop(v,22u)>0u;}
fn bound(i:u32)->bool{return (structures[i]&(INTEGRITY|ANCHOR))!=0u;}
fn intact(i:u32)->bool{return (structures[i]&INTEGRITY)!=0u;}
fn bit(dir:u32)->u32{return 1u<<(8u+dir);}
fn neighbor(i:u32,dir:u32)->u32{let c=coordinate(i)+NORMALS[dir];if(!inside(c)){return INF;}return index(c);}
fn storageOf(canonical:u32)->u32{return index(vec3i(vec3u(canonical%p.shape.x,(canonical/p.shape.x)%p.shape.y,canonical/(p.shape.x*p.shape.y))));}
`;
  let physics = replace(base, "@compute @workgroup_size(64) fn main", mechanical + "\n@compute @workgroup_size(64) fn main");
  physics = replace(physics, "fn falling(v:u32)->bool{return phase(v)==1u||liquid(v);}", "fn falling(v:u32)->bool{return phase(v)==1u||liquid(v)||eligible(v);}");
  physics = replace(physics, "!fixed(cells[s])&&!fixed(cells[t])", "!bound(s)&&!bound(t)");
  physics = replace(physics, "var outV=v;var outQ=q;", "var outV=v;var outQ=q;var outS=structures[i];");
  physics = replace(physics, "outV=thermal((v&0xf0ff0000u)|m|(prop(m,20u)<<24u),q);", "outV=thermal((v&0xf0ff0000u)|m|(prop(m,20u)<<24u),q);outS=select(0u,INTEGRITY|FRESH,eligible(outV));");
  physics = replace(physics, "outV=cells[other];outQ=energies[other];", "outV=cells[other];outQ=energies[other];outS=structures[other];");
  physics = replace(physics, "nextCells[i]=outV;nextEnergies[i]=outQ;", "nextCells[i]=outV;nextEnergies[i]=outQ;nextStructures[i]=outS;");
  const prefix = base.slice(0, base.indexOf("@compute")) + mechanical;
  const mechanics = prefix + `
// Header: changed, maxDistance, error, reserved, supportedWeight, reactionTotal.
// Planes: support distance, load, component root (canonical), blocked root.
@group(0) @binding(9) var<storage,read_write> work:array<atomic<u32>>;
@group(0) @binding(10) var<storage,read> commands:array<vec4u>;
@group(0) @binding(11) var<storage,read_write> receipts:array<vec2u>;
@group(0) @binding(13) var<storage,read_write> queryWords:array<vec4u>;
@group(0) @binding(14) var<storage,read_write> solveDispatch:array<u32>;
@compute @workgroup_size(1) fn relaxStart(){
 atomicStore(&work[0],0u);solveDispatch[0]=(p.shape.w+63u)/64u;solveDispatch[1]=1u;solveDispatch[2]=1u;solveDispatch[3]=0u;
}
@compute @workgroup_size(1) fn relaxAdvance(){
 if(solveDispatch[0]!=0u){solveDispatch[3]++;}if(atomicExchange(&work[0],0u)==0u){solveDispatch[0]=0u;}
}
@compute @workgroup_size(1) fn relaxEnd(){
 // A nonzero budget flag rejects the attempt. The host resumes with the
 // general convergent solver; no fixed-iteration approximation is committed.
 if(solveDispatch[0]!=0u){atomicOr(&work[8],p.rule.x);}
 atomicStore(&work[8u+p.rule.y],solveDispatch[3]);
}
@compute @workgroup_size(64) fn queryCells(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;let size=p.rule.xyz;if(i>=size.x*size.y*size.z){return;}
 let c=p.tick.xyz+vec3u(i%size.x,(i/size.x)%size.y,i/(size.x*size.y));let j=index(vec3i(c));
 queryWords[i]=vec4u(cells[j],energies[j],structures[j],0u);
}
fn clearEditedBonds(i:u32){
 for(var dir=0u;dir<6u;dir++){let j=neighbor(i,dir);if(j!=INF){nextStructures[j]&=~bit(dir^1u);}}
 nextStructures[i]&=INTEGRITY|ANCHOR;
}
// One invocation applies an ordered bounded batch to a scratch bank. Host-side
// validation rejects malformed commands; state-dependent errors discard the bank.
@compute @workgroup_size(1) fn editBatch(){
 if(atomicLoad(&work[2])!=0u){return;}
 for(var k=p.tick.y;k<p.tick.z;k++){
  let e=commands[k];let i=storageOf(e.x);let old=nextEnergies[i];
  if(e.y==0u){
   clearEditedBonds(i);nextCells[i]=e.z;nextEnergies[i]=e.w;
   nextStructures[i]=select(0u,INTEGRITY,eligible(e.z));
   if(nextStructures[i]!=0u){for(var dir=0u;dir<6u;dir++){
    let j=neighbor(i,dir);if(j!=INF&&(nextStructures[j]&INTEGRITY)!=0u){nextStructures[i]|=bit(dir);nextStructures[j]|=bit(dir^1u);}
   }}
   changed(coordinate(i));
  }else if(e.y==1u){nextCells[i]=thermal(nextCells[i],e.z);nextEnergies[i]=e.z;}
  else{
   if(!eligible(nextCells[i])){atomicStore(&work[2],3u);return;}
   if(e.y==2u){if(e.z==0u){clearEditedBonds(i);}nextStructures[i]=(nextStructures[i]&~INTEGRITY)|e.z;}
   else if(e.y==3u){nextStructures[i]=select(nextStructures[i]&~ANCHOR,nextStructures[i]|ANCHOR,e.z!=0u);}
   else{
    let j=neighbor(i,e.z);if(j==INF){atomicStore(&work[2],4u);return;}
    if(e.w!=0u){
     if((nextStructures[i]&INTEGRITY)==0u||(nextStructures[j]&INTEGRITY)==0u){atomicStore(&work[2],5u);return;}
     nextStructures[i]|=bit(e.z);nextStructures[j]|=bit(e.z^1u);
    }else{nextStructures[i]&=~bit(e.z);nextStructures[j]&=~bit(e.z^1u);}
   }
  }
  receipts[k]=vec2u(old,nextEnergies[i]);
 }
}
fn address(plane:u32,i:u32)->u32{return 16u+plane*p.shape.w+i;}
fn planRead(plane:u32,i:u32)->u32{return atomicLoad(&work[address(plane,i)]);}
fn planWrite(plane:u32,i:u32,value:u32){atomicStore(&work[address(plane,i)],value);}
fn weight(i:u32)->u32{return max(1u,(prop(cells[i],0u)+63u)/64u);}
fn strength(v:u32,q:u32,s:u32)->u32{
 let nominal=prop(v,22u)*16u;let soft=prop(v,23u);var remaining=16384u;
 if(soft!=0u){remaining=u32(clamp(i32((soft+64u)*256u)-i32(temperature(v,q)),0,16384));}
 return(nominal*(s&INTEGRITY)/255u)*remaining/16384u;
}
// An exact whole-world certificate, not a hash or spatial wake radius. Retain
// the global plan only if its graph/weights are unchanged and next tick's
// thermal damage is provably zero. Any changed dependency invalidates it all.
@compute @workgroup_size(64) fn certifyPlan(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=p.shape.w){return;}let s=nextStructures[i];
 if(structures[i]!=s){atomicStore(&work[6],1u);return;}
 if((s&INTEGRITY)!=0u){
  // Only intact cells contribute weight. Moving fluid elsewhere cannot change
  // the support graph. At contacts, compare the actual root predicate exactly.
  if(prop(cells[i],0u)!=prop(nextCells[i],0u)){atomicStore(&work[6],1u);return;}
  let below=neighbor(i,3u);
  if(below!=INF&&!intact(below)&&(structures[below]&ANCHOR)==0u){
   let before=prop(cells[i],0u)<=prop(cells[below],0u);
   let after=prop(nextCells[i],0u)<=prop(nextCells[below],0u);
   if(before!=after){atomicStore(&work[6],1u);return;}
  }
  let capacity=strength(nextCells[i],nextEnergies[i],s);if(capacity==0u||planRead(1u,i)>capacity){atomicStore(&work[6],1u);}
 }
}
fn obstacle(i:u32,j:u32)->bool{return (structures[j]&ANCHOR)!=0u||prop(cells[i],0u)<=prop(cells[j],0u);}
fn rootSupport(i:u32)->bool{
 let below=neighbor(i,3u);if((structures[i]&ANCHOR)!=0u||below==INF){return true;}
 return !intact(below)&&obstacle(i,below);
}
@compute @workgroup_size(64) fn supportInit(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=p.shape.w){return;}
 var d=INF;if(intact(i)&&rootSupport(i)){d=0u;}planWrite(0u,i,d);planWrite(1u,i,0u);
}
@compute @workgroup_size(64) fn supportRelax(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=p.shape.w||!intact(i)){return;}var best=planRead(0u,i);
 for(var dir=0u;dir<6u;dir++){
  let j=neighbor(i,dir);if(j==INF||!intact(j)){continue;}
  if((structures[i]&bit(dir))!=0u||dir==3u){let d=planRead(0u,j);if(d!=INF){best=min(best,d+1u);}}
 }
 if(atomicMin(&work[address(0u,i)],best)>best){atomicStore(&work[0],1u);}
}
@compute @workgroup_size(64) fn supportSummary(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=p.shape.w){return;}let d=planRead(0u,i);
 if(d!=INF){atomicMax(&work[1],d);atomicAdd(&work[4],weight(i));}
}
// Each dispatch owns one support-distance level. Gather immutable child loads;
// canonical coordinate rank decides integer remainders independently of layout.
@compute @workgroup_size(64) fn loadLevel(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=p.shape.w||planRead(0u,i)!=p.tick.y){return;}var load=weight(i);let canonical=linear(coordinate(i));
 for(var dir=0u;dir<6u;dir++){
  let child=neighbor(i,dir);if(child==INF||!intact(child)||planRead(0u,child)!=p.tick.y+1u){continue;}
  if((structures[i]&bit(dir))==0u&&dir!=2u){continue;}
  var count=0u;var rank=0u;
  for(var side=0u;side<6u;side++){
   let parent=neighbor(child,side);if(parent==INF||!intact(parent)||planRead(0u,parent)!=p.tick.y){continue;}
   if((structures[child]&bit(side))!=0u||side==3u){count++;if(linear(coordinate(parent))<canonical){rank++;}}
  }
  if(count==0u){atomicStore(&work[2],1u);return;}
  let childLoad=planRead(1u,child);load+=childLoad/count+select(0u,1u,rank<childLoad%count);
 }
 planWrite(1u,i,load);if(p.tick.y==0u){atomicAdd(&work[5],load);}
}
@compute @workgroup_size(64) fn loadInit(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=p.shape.w){return;}planWrite(1u,i,select(weight(i),0u,planRead(0u,i)==INF));
}
// On the fixed support-distance DAG, each predecessor's integer share is
// monotone in the child's load. Atomic maxima converge to the same exact load
// as the independent CPU reverse-BFS reduction, regardless of invocation order.
@compute @workgroup_size(64) fn loadRelax(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=p.shape.w){return;}let level=planRead(0u,i);if(level==INF){return;}
 var load=weight(i);let canonical=linear(coordinate(i));
 for(var dir=0u;dir<6u;dir++){
  let child=neighbor(i,dir);if(child==INF||!intact(child)||planRead(0u,child)!=level+1u){continue;}
  if((structures[i]&bit(dir))==0u&&dir!=2u){continue;}
  var count=0u;var rank=0u;
  for(var side=0u;side<6u;side++){
   let parent=neighbor(child,side);if(parent==INF||!intact(parent)||planRead(0u,parent)!=level){continue;}
   if((structures[child]&bit(side))!=0u||side==3u){count++;if(linear(coordinate(parent))<canonical){rank++;}}
  }
  if(count==0u){atomicStore(&work[2],1u);return;}
  let childLoad=planRead(1u,child);load+=childLoad/count+select(0u,1u,rank<childLoad%count);
 }
 if(atomicMax(&work[address(1u,i)],load)<load){atomicStore(&work[0],1u);}
}
@compute @workgroup_size(64) fn loadSummary(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i<p.shape.w&&planRead(0u,i)==0u){atomicAdd(&work[5],planRead(1u,i));}
}
@compute @workgroup_size(64) fn damage(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=p.shape.w){return;}let s=structures[i];let integrity=s&INTEGRITY;var result=s;
 if(integrity!=0u){
  let v=cells[i];let nominal=prop(v,22u)*16u;
  let capacity=strength(v,energies[i],s);let load=planRead(1u,i);var loss=0u;
  if(capacity==0u){loss=integrity;}else if(load>capacity){loss=min(integrity,max(1u,(load-capacity)*255u/nominal));}
  result=(s&~INTEGRITY)|(integrity-loss);
 }
 nextStructures[i]=result;
}
@compute @workgroup_size(64) fn normalize(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=p.shape.w){return;}var s=0u;
 if(eligible(cells[i])){
  s=structures[i]&(INTEGRITY|ANCHOR);
  if((s&INTEGRITY)!=0u){for(var dir=0u;dir<6u;dir++){
   let j=neighbor(i,dir);if(j==INF||!eligible(cells[j])||!intact(j)){continue;}
   if(((structures[i]&bit(dir))!=0u&&(structures[j]&bit(dir^1u))!=0u)||((structures[i]|structures[j])&FRESH)!=0u){s|=bit(dir);}
  }}
 }
 nextStructures[i]=s;
}
@compute @workgroup_size(64) fn componentInit(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=p.shape.w){return;}planWrite(2u,i,select(INF,linear(coordinate(i)),intact(i)));planWrite(3u,i,0u);
}
@compute @workgroup_size(64) fn componentRelax(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=p.shape.w||!intact(i)){return;}var root=planRead(2u,i);
 let previousRoot=root;
 for(var dir=0u;dir<6u;dir++){if((structures[i]&bit(dir))!=0u){root=min(root,planRead(2u,neighbor(i,dir)));}}
 // Pointer compression accelerates long components without changing the fixed point.
 root=min(root,planRead(2u,storageOf(root)));
 // Hook the previous representative too. Both labels belong to this bonded
 // component, and every write strictly decreases a canonical index. This
 // accelerates propagation through large anchored floors without merging
 // unbonded contacts or changing the unique minimum-index fixed point.
 if(atomicMin(&work[address(2u,storageOf(previousRoot))],root)>root){atomicStore(&work[0],1u);}
 if(atomicMin(&work[address(2u,i)],root)>root){atomicStore(&work[0],1u);}
}
@compute @workgroup_size(64) fn blockInit(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=p.shape.w||!intact(i)){return;}
 if(rootSupport(i)){atomicStore(&work[address(3u,storageOf(planRead(2u,i)))],1u);}
}
@compute @workgroup_size(64) fn blockRelax(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=p.shape.w||!intact(i)){return;}let below=neighbor(i,3u);
 if(below==INF||!intact(below)){return;}let root=storageOf(planRead(2u,i));let lower=storageOf(planRead(2u,below));
 if(root!=lower&&planRead(3u,lower)!=0u&&atomicOr(&work[address(3u,root)],1u)==0u){atomicStore(&work[0],1u);}
}
fn moving(i:u32)->bool{return intact(i)&&planRead(3u,storageOf(planRead(2u,i)))==0u;}
@compute @workgroup_size(64) fn applyMotion(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=p.shape.w){return;}let above=neighbor(i,2u);var source=i;
 if(above!=INF&&moving(above)){source=above;}
 else if(moving(i)){
  // Only a run's vacated top receives its displaced bottom cell.
  var found=false;
  for(var y=1u;y<p.shape.y;y++){
   let c=coordinate(i)+vec3i(0,i32(y),0);if(!inside(c)){break;}
   let j=index(c);if(!moving(j)){source=j;found=true;break;}
  }
  if(!found){atomicStore(&work[2],2u);return;}
 }
 nextCells[i]=cells[source];nextEnergies[i]=energies[source];nextStructures[i]=structures[source];
 if((cells[i]&255u)!=(cells[source]&255u)){changed(coordinate(i));}
}
`;
  const specialize = (source) => `const SHAPE=vec4u(${shape.join("u,")}u,${shape.reduce((a, b) => a * b, 1)}u);
` + source.replaceAll("p.shape", "SHAPE");
  return { physics: specialize(physics), mechanics: specialize(mechanics) };
}
function structuralActivityShaders(physics, edge, chunks) {
  const declarations = `
const M5_CHUNKS=${chunks}u;
const M5_AWAKE=M5_CHUNKS;
const M5_LIST=M5_AWAKE+M5_CHUNKS;
const M5_COUNT=M5_LIST+M5_CHUNKS;
fn wakeLocal(c:vec3i){
 let n=vec3i(SHAPE.xyz/EDGE);let k=c/i32(EDGE);let local=vec3u(c)%EDGE;
 let lo=-vec3i(select(vec3u(0),vec3u(1),local<vec3u(2)));
 let hi=vec3i(select(vec3u(0),vec3u(1),local+vec3u(2)>=vec3u(EDGE)));
 for(var z=lo.z;z<=hi.z;z++){for(var y=lo.y;y<=hi.y;y++){for(var x=lo.x;x<=hi.x;x++){
  let t=k+vec3i(x,y,z);if(all(t>=vec3i(0))&&all(t<n)){atomicStore(&dirty[M5_AWAKE+u32(t.x+n.x*(t.y+n.y*t.z))],1u);}
 }}}
}
// Every parity/direction is considered. Tick order alone cannot awaken a tile.
fn locallyQuiet(i:u32)->bool{
 let v=cells[i];let q=energies[i];let c=coordinate(i);let immovable=bound(i);
 if(thermal(v,q)!=v||transition(v,q)!=(v&255u)){return false;}
 for(var f=0u;f<6u;f++){
  let t=c+NORMALS[f];if(!inside(t)){continue;}let j=index(t);let other=cells[j];
  if(((v&255u)!=(other&255u)||q!=energies[j])&&pairEnergy(v,other,q,energies[j])!=q){return false;}
  if(immovable){continue;}
  if(f==2u){if(rise(i,j)||fall(j,i)){return false;}}
  else if(f==3u){if(fall(i,j)||rise(j,i)){return false;}}
  else{
   if(spread(i,j)||spread(j,i)){return false;}
   if(gas(v)&&gas(other)&&(((v&255u)!=0u&&((other&255u)==0u||rank(i)>rank(j)+16))||((other&255u)!=0u&&((v&255u)==0u||rank(j)>rank(i)+16)))){return false;}
  }
 }
 if(immovable){return true;}
 for(var f=0u;f<6u;f++){
  if(f==2u||f==3u){continue;}
  let down=c+NORMALS[f]+vec3i(0,1,0);if(inside(down)&&fall(i,index(down))){return false;}
  let up=c+NORMALS[f]-vec3i(0,1,0);if(inside(up)&&fall(index(up),i)){return false;}
 }
 return true;
}
@compute @workgroup_size(64) fn certifyLocal(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=SHAPE.w){return;}if(!locallyQuiet(i)){wakeLocal(coordinate(i));}
}
@group(0) @binding(12) var<storage,read_write> localDispatch:array<u32>;
@compute @workgroup_size(1) fn collectLocal(){
 var count=0u;
 for(var k=0u;k<M5_CHUNKS;k++){if(atomicLoad(&dirty[M5_AWAKE+k])!=0u){atomicStore(&dirty[M5_LIST+count],k);count++;}}
 atomicStore(&dirty[M5_COUNT],count);atomicAdd(&dirty[M5_COUNT+1u],count);atomicMax(&dirty[M5_COUNT+2u],count);
 localDispatch[0]=count*EDGE*EDGE*EDGE/64u;localDispatch[1]=1u;localDispatch[2]=1u;
}
`;
  const marker = "@compute @workgroup_size(64) fn main";
  const prefix = physics.slice(0, physics.indexOf(marker)), planning = prefix + declarations;
  const body = physics.slice(physics.indexOf(marker)).replace("let i=id.x; if(i>=SHAPE.w){return;}", "let i=atomicLoad(&dirty[M5_LIST+id.x/(EDGE*EDGE*EDGE)])*EDGE*EDGE*EDGE+id.x%(EDGE*EDGE*EDGE);").replace(
    "nextCells[i]=outV;nextEnergies[i]=outQ;nextStructures[i]=outS;",
    "if(v!=outV||q!=outQ||structures[i]!=outS){wakeLocal(coordinate(i));}\n  nextCells[i]=outV;nextEnergies[i]=outQ;nextStructures[i]=outS;"
  );
  if (!body.includes("let i=atomicLoad")) throw Error("M5 active template differs.");
  return { physics: planning + body, planning, edge };
}
const INTEGRITY_3D = 255;
const BONDS_3D = Object.freeze([1 << 8, 1 << 9, 1 << 10, 1 << 11, 1 << 12, 1 << 13]);
const ANCHOR_3D = 1 << 14;
const FRESH_3D = 1 << 15;
const cold$3 = buildColdTable();
const structuralDensity = (v) => cold$3[(v & 255) * COLD_STRIDE + COLD_DENSITY];
function structuralEligible(v) {
  const phase2 = v >>> PHASE_SHIFT & 15;
  return (phase2 === PHASE_SOLID || phase2 === PHASE_FROZEN) && cold$3[(v & 255) * COLD_STRIDE + COLD_COHESION] > 0;
}
function structuralNeighbor(i, direction, g) {
  const { width: w, height: h, depth: d } = g, layer = w * h;
  const x = i % w, y = Math.floor(i / w) % h, z = Math.floor(i / layer);
  switch (direction) {
    case 0:
      return x ? i - 1 : -1;
    case 1:
      return x + 1 < w ? i + 1 : -1;
    case 2:
      return y ? i - w : -1;
    case 3:
      return y + 1 < h ? i + w : -1;
    case 4:
      return z ? i - layer : -1;
    case 5:
      return z + 1 < d ? i + layer : -1;
    default:
      throw Error("Invalid structural direction.");
  }
}
function normalizeStructure3D(grid, words, g) {
  const out = new Uint32Array(grid.length);
  for (let i = 0; i < out.length; i++) if (structuralEligible(grid[i])) out[i] = words[i] & (INTEGRITY_3D | ANCHOR_3D);
  for (let i = 0; i < out.length; i++) {
    if (!(out[i] & INTEGRITY_3D)) continue;
    for (const dir of [1, 3, 5]) {
      const j = structuralNeighbor(i, dir, g);
      if (j < 0 || !(out[j] & INTEGRITY_3D)) continue;
      if (words[i] & BONDS_3D[dir] && words[j] & BONDS_3D[dir ^ 1] || (words[i] | words[j]) & FRESH_3D) {
        out[i] |= BONDS_3D[dir];
        out[j] |= BONDS_3D[dir ^ 1];
      }
    }
  }
  return out;
}
function structuralCapacity(v, q, integrity) {
  const at = (v & 255) * COLD_STRIDE, nominal = cold$3[at + COLD_COHESION] * 16, softening = cold$3[at + COLD_SOFTENING];
  const remaining = softening ? Math.max(0, Math.min(64 * ENERGY_SCALE, (softening + 64) * ENERGY_SCALE - temperatureQ(v, q, cold$3))) : 64 * ENERGY_SCALE;
  return Math.floor(Math.floor(nominal * integrity / 255) * remaining / (64 * ENERGY_SCALE));
}
function solveStructure3D(input, g) {
  const { grid, energyQ, structure } = input, n = grid.length;
  const active = (i, words = structure) => i >= 0 && (words[i] & INTEGRITY_3D) !== 0;
  const obstructed = (i, j) => (structure[j] & ANCHOR_3D) !== 0 || structuralDensity(grid[i]) <= structuralDensity(grid[j]);
  const distances = new Int32Array(n).fill(-1), loads = new Uint32Array(n), reactions = new Uint32Array(n), queue = new Uint32Array(n);
  let length = 0;
  for (let i = 0; i < n; i++) if (active(i)) {
    const below = structuralNeighbor(i, 3, g);
    if (structure[i] & ANCHOR_3D || below < 0 || !active(below) && obstructed(i, below)) {
      distances[i] = 0;
      queue[length++] = i;
    }
  }
  for (let head = 0; head < length; head++) {
    const i = queue[head];
    for (let dir = 0; dir < 6; dir++) {
      const j = structuralNeighbor(i, dir, g);
      if (active(j) && distances[j] < 0 && (structure[i] & BONDS_3D[dir] || dir === 2)) {
        distances[j] = distances[i] + 1;
        queue[length++] = j;
      }
    }
  }
  let supportedWeight = 0;
  for (let k = 0; k < length; k++) {
    const i = queue[k];
    loads[i] = Math.max(1, Math.ceil(structuralDensity(grid[i]) / 64));
    supportedWeight += loads[i];
  }
  const supports = [];
  for (let k = length - 1; k >= 0; k--) {
    const i = queue[k];
    if (distances[i] === 0) {
      reactions[i] = loads[i];
      continue;
    }
    supports.length = 0;
    for (let dir = 0; dir < 6; dir++) {
      const j = structuralNeighbor(i, dir, g);
      if (active(j) && distances[j] === distances[i] - 1 && (structure[i] & BONDS_3D[dir] || dir === 3)) supports.push(j);
    }
    supports.sort((a, b) => a - b);
    if (!supports.length) throw Error("Incomplete structural support solve.");
    const share = Math.floor(loads[i] / supports.length), remainder = loads[i] % supports.length;
    for (let r = 0; r < supports.length; r++) loads[supports[r]] += share + (r < remainder ? 1 : 0);
  }
  let reactionTotal = 0;
  for (const r of reactions) reactionTotal += r;
  if (reactionTotal !== supportedWeight) throw Error("Structural reactions do not balance supported weight.");
  const capacities = new Uint32Array(n), damaged = structure.slice();
  let brokenCells = 0;
  for (let i = 0; i < n; i++) if (active(i)) {
    const integrity = structure[i] & INTEGRITY_3D, nominal = cold$3[(grid[i] & 255) * COLD_STRIDE + COLD_COHESION] * 16;
    const capacity = structuralCapacity(grid[i], energyQ[i], integrity);
    capacities[i] = capacity;
    const loss = capacity === 0 ? integrity : loads[i] > capacity ? Math.min(integrity, Math.max(1, Math.floor((loads[i] - capacity) * 255 / nominal))) : 0;
    damaged[i] = damaged[i] & ~INTEGRITY_3D | integrity - loss;
    if (loss === integrity) brokenCells++;
  }
  const edges = normalizeStructure3D(grid, damaged, g), ids = new Int32Array(n).fill(-1);
  const members = [], roots = [];
  for (let root = 0; root < n; root++) if (active(root, edges) && ids[root] < 0) {
    const cells = [root];
    ids[root] = root;
    for (let head = 0; head < cells.length; head++) {
      const i = cells[head];
      for (let dir = 0; dir < 6; dir++) if (edges[i] & BONDS_3D[dir]) {
        const j = structuralNeighbor(i, dir, g);
        if (j < 0 || !active(j, edges)) throw Error("Broken structural adjacency.");
        if (ids[j] < 0) {
          ids[j] = root;
          cells.push(j);
        }
      }
    }
    roots.push(root);
    members.push(cells);
  }
  const blocked = new Uint8Array(n), dependents = /* @__PURE__ */ new Map();
  length = 0;
  for (let k = 0; k < roots.length; k++) {
    const root = roots[k];
    for (const i of members[k]) {
      const below = structuralNeighbor(i, 3, g);
      if (edges[i] & ANCHOR_3D || below < 0 || !active(below, edges) && obstructed(i, below)) blocked[root] = 1;
      else if (ids[below] >= 0 && ids[below] !== root) {
        let above = dependents.get(ids[below]);
        if (!above) {
          above = /* @__PURE__ */ new Set();
          dependents.set(ids[below], above);
        }
        above.add(root);
      }
    }
    if (blocked[root]) queue[length++] = root;
  }
  for (let head = 0; head < length; head++) for (const above of dependents.get(queue[head]) ?? []) {
    if (!blocked[above]) {
      blocked[above] = 1;
      queue[length++] = above;
    }
  }
  const moving = new Uint8Array(n);
  let movedCells = 0;
  for (let i = 0; i < n; i++) if (ids[i] >= 0 && !blocked[ids[i]]) {
    moving[i] = 1;
    movedCells++;
  }
  const sources = Uint32Array.from({ length: n }, (_, i) => i);
  for (let z = 0; z < g.depth; z++) for (let x = 0; x < g.width; x++) {
    let top = -1;
    for (let y = 0; y < g.height; y++) {
      const i = x + g.width * (y + g.height * z);
      if (moving[i]) {
        if (y + 1 === g.height) throw Error("Structural motion crossed the closed floor.");
        if (top < 0) top = i;
        sources[i + g.width] = i;
      } else if (top >= 0) {
        sources[top] = i;
        top = -1;
      }
    }
  }
  const state = { grid: new Uint32Array(n), energyQ: new Uint32Array(n), structure: new Uint32Array(n) }, visited = new Uint8Array(n);
  for (let i = 0; i < n; i++) {
    const source = sources[i];
    if (visited[source]) throw Error("Structural motion is not a permutation.");
    visited[source] = 1;
    state.grid[i] = grid[source];
    state.energyQ[i] = energyQ[source];
    state.structure[i] = edges[source];
  }
  return { state, sources, distances, loads, capacities, reactions, componentIds: ids, moving, supportedWeight, brokenCells, movedCells };
}
const cold$2 = buildColdTable();
const material = (v) => v & 255;
const phase = (v) => v >>> PHASE_SHIFT & 15;
const liquid = (v) => phase(v) === PHASE.LIQUID || phase(v) === PHASE.VISCOUS || phase(v) === PHASE.MOLTEN;
const falling = (v) => phase(v) === PHASE.POWDER || liquid(v) || structuralEligible(v);
const gas = (v) => phase(v) === PHASE.GAS;
const density = (v) => cold$2[material(v) * COLD_STRIDE + COLD_DENSITY];
function choice(index, axis, tick) {
  let h = Math.imul(index, 374761393) + Math.imul(axis, 668265263) + Math.imul(tick >>> 0, 1442695041) >>> 0;
  h = Math.imul(h ^ h >>> 13, 1274126177) >>> 0;
  return ((h ^ h >>> 16) & 1) === 0;
}
function executeStructuralMaterialPass(input, output, w, h, d, tick, pass) {
  const aGrid = input.grid, aEnergy = input.energyQ, bGrid = output.grid, bEnergy = output.energyQ;
  bGrid.set(aGrid);
  bEnergy.set(aEnergy);
  output.structure.set(input.structure);
  const layer = w * h;
  const bound = (index) => (input.structure[index] & (INTEGRITY_3D | ANCHOR_3D)) !== 0;
  const canFall = (source, target) => falling(aGrid[source]) && !bound(source) && !bound(target) && density(aGrid[source]) > density(aGrid[target]);
  const gasRank = (i) => Math.floor(temperatureQ(aGrid[i], aEnergy[i], cold$2) / 256) * 2 - density(aGrid[i]);
  const canRise = (s, t) => material(aGrid[s]) !== MAT.AIR && gas(aGrid[s]) && gas(aGrid[t]) && gasRank(s) > gasRank(t) + 16;
  const swap = (s, t) => {
    bGrid[s] = aGrid[t];
    bGrid[t] = aGrid[s];
    bEnergy[s] = aEnergy[t];
    bEnergy[t] = aEnergy[s];
    output.structure[s] = input.structure[t];
    output.structure[t] = input.structure[s];
  };
  const hasFall = (i, x, y, z) => y + 1 < h && (canFall(i, i + w) || x > 0 && canFall(i, i + w - 1) || x + 1 < w && canFall(i, i + w + 1) || z > 0 && canFall(i, i + w - layer) || z + 1 < d && canFall(i, i + w + layer));
  if (pass.kind === "phase") {
    for (let i = 0; i < aGrid.length; i++) {
      const next = phaseMaterial(aGrid[i], aEnergy[i], cold$2);
      if (next !== material(aGrid[i])) {
        bGrid[i] = rewriteMaterial(aGrid[i], next, aEnergy[i], cold$2);
        output.structure[i] = structuralEligible(bGrid[i]) ? INTEGRITY_3D | FRESH_3D : 0;
      }
    }
    return;
  }
  const vertical = ["gravity", "diagonal", "buoyancy"].includes(pass.kind);
  const pairAxis = vertical ? 1 : pass.axis;
  for (let z = pairAxis === 2 ? pass.parity : 0; z < d; z += pairAxis === 2 ? 2 : 1) {
    for (let y = pairAxis === 1 ? pass.parity : 0; y < h; y += pairAxis === 1 ? 2 : 1) {
      for (let x = pairAxis === 0 ? pass.parity : 0; x < w; x += pairAxis === 0 ? 2 : 1) {
        let tx = x + (pairAxis === 0 ? 1 : 0), ty = y + (pairAxis === 1 ? 1 : 0), tz = z + (pairAxis === 2 ? 1 : 0);
        if (pass.kind === "diagonal") {
          tx += pass.axis === 0 ? pass.direction : 0;
          tz += pass.axis === 2 ? pass.direction : 0;
        }
        if (tx < 0 || tx >= w || ty >= h || tz < 0 || tz >= d) continue;
        const a = x + w * (y + h * z), b = tx + w * (ty + h * tz);
        if (pass.kind === "gravity") {
          if (canFall(a, b)) swap(a, b);
        } else if (pass.kind === "diagonal") {
          if (!canFall(a, a + w) && canFall(a, b)) swap(a, b);
        } else if (pass.kind === "buoyancy") {
          if (canRise(b, a)) swap(a, b);
        } else if (pass.kind === "liquid") {
          const spread = (s, t) => liquid(aGrid[s]) && gas(aGrid[t]) && density(aGrid[s]) > density(aGrid[t]);
          if (spread(a, b) && !hasFall(a, x, y, z) || spread(b, a) && !hasFall(b, tx, ty, tz)) swap(a, b);
        } else if (pass.kind === "gas") {
          const [s, t, sy] = choice(a, pass.axis, tick) ? [a, b, y] : [b, a, ty];
          if (material(aGrid[s]) !== MAT.AIR && gas(aGrid[s]) && gas(aGrid[t]) && (sy === 0 || !canRise(s, s - w)) && (material(aGrid[t]) === MAT.AIR || gasRank(s) > gasRank(t) + 16)) swap(s, t);
        } else if (pass.kind === "heat") {
          if (material(aGrid[a]) === material(aGrid[b]) && aEnergy[a] === aEnergy[b]) continue;
          [bEnergy[a], bEnergy[b]] = exchangeEnergy(aGrid[a], aGrid[b], aEnergy[a], aEnergy[b], cold$2);
          bGrid[a] = thermalView(aGrid[a], bEnergy[a], cold$2);
          bGrid[b] = thermalView(aGrid[b], bEnergy[b], cold$2);
        }
      }
    }
  }
}
const STRUCTURAL_SCHEMA_VERSION_3D = 2;
const STRUCTURAL_RULES_VERSION_3D = "ca-3d-m5";
const STRUCTURAL_WORLD_VERSION_3D = "finite-structural-1";
const cold$1 = buildColdTable(), supported = new Set(MATERIALS_3D.map((m) => m.id));
const clone = (s) => ({ grid: s.grid.slice(), energyQ: s.energyQ.slice(), structure: s.structure.slice() });
const total$1 = (s) => {
  let q = 0;
  for (const value of s.energyQ) q += value;
  return BigInt(q);
};
function position(p, g) {
  checkedInteger(p.x, 0, g.width - 1, "x");
  checkedInteger(p.y, 0, g.height - 1, "y");
  checkedInteger(p.z, 0, g.depth - 1, "z");
  return p.x + g.width * (p.y + g.height * p.z);
}
function placement(id, thermal) {
  if (!Number.isInteger(id) || !supported.has(id)) throw Error("Material is not supported by ca-3d-m5.");
  const record = DEFAULT_REGISTRY.material(id), t = thermal ?? record.default_thermal;
  checkedInteger(t, 0, 255, "thermal");
  return seedState([id | t << 8 | record.properties.default_phase << PHASE_SHIFT]);
}
function prepareStructuralEdits3D(edits, g) {
  if (!Array.isArray(edits) || edits.length > 65536) throw Error("Structural edits must be an array of at most 65536 entries.");
  const commands = new Uint32Array(edits.length * 4);
  const expected = { material: ["kind,material,x,y,z", "kind,material,thermal,x,y,z"], energy: ["energyQ,kind,x,y,z"], integrity: ["integrity,kind,x,y,z"], anchor: ["anchored,kind,x,y,z"], bond: ["bonded,direction,kind,x,y,z"] };
  for (let k = 0; k < edits.length; k++) {
    const edit = edits[k];
    if (!edit || typeof edit !== "object" || Array.isArray(edit) || !Object.hasOwn(expected, edit.kind) || !expected[edit.kind].includes(Object.keys(edit).sort().join(","))) throw Error("Invalid structural edit fields.");
    const i = position(edit, g);
    let kind = 0, a = 0, b = 0;
    if (edit.kind === "material") {
      const seed = placement(edit.material, edit.thermal);
      a = seed.grid[0];
      b = seed.energyQ[0];
    } else if (edit.kind === "energy") {
      kind = 1;
      a = checkedInteger(edit.energyQ, 0, MAX_ENERGY_Q, "energyQ");
    } else if (edit.kind === "integrity") {
      kind = 2;
      a = checkedInteger(edit.integrity, 0, 255, "integrity");
    } else if (edit.kind === "anchor") {
      kind = 3;
      if (typeof edit.anchored !== "boolean") throw Error("Anchor state must be boolean.");
      a = Number(edit.anchored);
    } else {
      kind = 4;
      a = checkedInteger(edit.direction, 0, 5, "bond direction");
      if (typeof edit.bonded !== "boolean") throw Error("Bond state must be boolean.");
      b = Number(edit.bonded);
      if (structuralNeighbor(i, a, g) < 0) throw Error("Bond crosses the closed boundary.");
    }
    commands.set([i, kind, a, b], k * 4);
  }
  return commands;
}
function validateStructuralState3D(grid, energyQ, structure, g) {
  const state = validateVolumeSnapshot({
    schemaVersion: SCHEMA_VERSION_3D,
    rulesVersion: RULES_VERSION_3D,
    materialCatalogHash: MATERIAL_CATALOG_HASH_3D,
    width: g.width,
    height: g.height,
    depth: g.depth,
    tick: 0,
    packedCells: grid,
    energyQ
  }, 128 ** 3);
  const words = validatePackedCells(structure, state.grid.length);
  if (words.some((v) => (v & -32768) !== 0)) throw Error("Reserved or pending structural bits in completed state.");
  const normalized = normalizeStructure3D(state.grid, words, g);
  if (words.some((v, i) => v !== normalized[i])) throw Error("Invalid structural phase, boundary or reciprocal bond.");
  return { ...state, structure: words };
}
function validateStructuralSnapshot3D(s) {
  const keys = "chunkSize,depth,energyQ,height,materialCatalogHash,packedCells,rulesVersion,schemaVersion,structure,tick,width,worldVersion";
  if (!s || typeof s !== "object" || Object.keys(s).sort().join(",") !== keys) throw Error("Invalid structural snapshot fields.");
  if (s.schemaVersion !== STRUCTURAL_SCHEMA_VERSION_3D || s.rulesVersion !== STRUCTURAL_RULES_VERSION_3D || s.worldVersion !== STRUCTURAL_WORLD_VERSION_3D || s.materialCatalogHash !== MATERIAL_CATALOG_HASH_3D) throw Error("Incompatible structural snapshot version or catalog.");
  const g = activeWorldGeometry({ width: s.width, height: s.height, depth: s.depth, chunkSize: s.chunkSize });
  checkedInteger(s.tick, 0, Number.MAX_SAFE_INTEGER, "tick");
  return validateStructuralState3D(s.packedCells, s.energyQ, s.structure, g);
}
function applyStructuralEdits3D(input, edits, g) {
  prepareStructuralEdits3D(edits, g);
  if (!edits.length) return { state: input, externalQ: 0n };
  const state = clone(input);
  let externalQ = 0n;
  const clearBonds = (i) => {
    for (let dir = 0; dir < 6; dir++) {
      const j = structuralNeighbor(i, dir, g);
      if (j >= 0) state.structure[j] &= ~BONDS_3D[dir ^ 1];
    }
    state.structure[i] &= INTEGRITY_3D | ANCHOR_3D;
  };
  for (let k = 0; k < edits.length; k++) {
    const edit = edits[k];
    if (!edit || typeof edit !== "object" || Array.isArray(edit)) throw Error("Invalid structural edit.");
    const keys = Object.keys(edit).sort().join(",");
    const expected = { material: ["kind,material,x,y,z", "kind,material,thermal,x,y,z"], energy: ["energyQ,kind,x,y,z"], integrity: ["integrity,kind,x,y,z"], anchor: ["anchored,kind,x,y,z"], bond: ["bonded,direction,kind,x,y,z"] };
    if (!Object.hasOwn(expected, edit.kind) || !expected[edit.kind].includes(keys)) throw Error("Invalid structural edit fields.");
    const i = position(edit, g);
    if (edit.kind === "material") {
      const seed = placement(edit.material, edit.thermal);
      clearBonds(i);
      externalQ += BigInt(seed.energyQ[0]) - BigInt(state.energyQ[i]);
      state.grid[i] = seed.grid[0];
      state.energyQ[i] = seed.energyQ[0];
      state.structure[i] = structuralEligible(state.grid[i]) ? INTEGRITY_3D : 0;
      if (state.structure[i]) for (let dir = 0; dir < 6; dir++) {
        const j = structuralNeighbor(i, dir, g);
        if (j >= 0 && state.structure[j] & INTEGRITY_3D) {
          state.structure[i] |= BONDS_3D[dir];
          state.structure[j] |= BONDS_3D[dir ^ 1];
        }
      }
    } else if (edit.kind === "energy") {
      checkedInteger(edit.energyQ, 0, MAX_ENERGY_Q, "energyQ");
      externalQ += BigInt(edit.energyQ) - BigInt(state.energyQ[i]);
      state.energyQ[i] = edit.energyQ;
      state.grid[i] = thermalView(state.grid[i], edit.energyQ, cold$1);
    } else {
      if (!structuralEligible(state.grid[i])) throw Error("Mechanical edits require a cohesive solid/frozen cell.");
      if (edit.kind === "integrity") {
        checkedInteger(edit.integrity, 0, 255, "integrity");
        if (!edit.integrity) clearBonds(i);
        state.structure[i] = state.structure[i] & ~INTEGRITY_3D | edit.integrity;
      } else if (edit.kind === "anchor") {
        if (typeof edit.anchored !== "boolean") throw Error("Anchor state must be boolean.");
        state.structure[i] = edit.anchored ? state.structure[i] | ANCHOR_3D : state.structure[i] & ~ANCHOR_3D;
      } else {
        checkedInteger(edit.direction, 0, 5, "bond direction");
        if (typeof edit.bonded !== "boolean") throw Error("Bond state must be boolean.");
        const j = structuralNeighbor(i, edit.direction, g);
        if (j < 0) throw Error("Bond crosses the closed boundary.");
        if (edit.bonded) {
          if (!(state.structure[i] & INTEGRITY_3D) || !(state.structure[j] & INTEGRITY_3D)) throw Error("Bond endpoints must both be intact.");
          state.structure[i] |= BONDS_3D[edit.direction];
          state.structure[j] |= BONDS_3D[edit.direction ^ 1];
        } else {
          state.structure[i] &= ~BONDS_3D[edit.direction];
          state.structure[j] &= ~BONDS_3D[edit.direction ^ 1];
        }
      }
    }
  }
  return { state, externalQ };
}
class CpuStructuralWorld3D {
  constructor(options = {}) {
    __publicField(this, "width");
    __publicField(this, "height");
    __publicField(this, "depth");
    __publicField(this, "chunkSize");
    __privateAdd(this, _state2);
    __privateAdd(this, _tick2, 0);
    __privateAdd(this, _initial2, 0n);
    __privateAdd(this, _external2, 0n);
    const g = activeWorldGeometry(options);
    this.width = g.width;
    this.height = g.height;
    this.depth = g.depth;
    this.chunkSize = g.chunkSize;
    const seed = placement(options.fillMaterial ?? MAT.AIR), n = g.width * g.height * g.depth;
    const grid = new Uint32Array(n).fill(seed.grid[0]), words = new Uint32Array(n).fill(structuralEligible(seed.grid[0]) ? INTEGRITY_3D | FRESH_3D : 0);
    __privateSet(this, _state2, { grid, energyQ: new Uint32Array(n).fill(seed.energyQ[0]), structure: normalizeStructure3D(grid, words, g) });
    __privateSet(this, _initial2, total$1(__privateGet(this, _state2)));
    for (const key of ["width", "height", "depth", "chunkSize"]) Object.defineProperty(this, key, { writable: false, configurable: false });
  }
  get tick() {
    return __privateGet(this, _tick2);
  }
  get grid() {
    return __privateGet(this, _state2).grid.slice();
  }
  get energyQ() {
    return __privateGet(this, _state2).energyQ.slice();
  }
  get structure() {
    return __privateGet(this, _state2).structure.slice();
  }
  edit(edits) {
    const next = applyStructuralEdits3D(__privateGet(this, _state2), edits, this);
    __privateSet(this, _state2, next.state);
    __privateSet(this, _external2, __privateGet(this, _external2) + next.externalQ);
  }
  setCell(x, y, z, material2, thermal) {
    this.edit([{ kind: "material", x, y, z, material: material2, ...thermal === void 0 ? {} : { thermal } }]);
  }
  setEnergy(x, y, z, energyQ) {
    this.edit([{ kind: "energy", x, y, z, energyQ }]);
  }
  setAnchor(x, y, z, anchored) {
    this.edit([{ kind: "anchor", x, y, z, anchored }]);
  }
  setIntegrity(x, y, z, integrity) {
    this.edit([{ kind: "integrity", x, y, z, integrity }]);
  }
  setBond(x, y, z, direction, bonded) {
    this.edit([{ kind: "bond", x, y, z, direction, bonded }]);
  }
  step(ticks = 1, options = {}) {
    checkedInteger(ticks, 0, 32, "ticks per request");
    checkedInteger(__privateGet(this, _tick2) + ticks, 0, Number.MAX_SAFE_INTEGER, "end tick");
    if (!options || typeof options !== "object" || Array.isArray(options) || Object.keys(options).some((k) => k !== "edits")) throw Error("Invalid structural step options.");
    const edited = applyStructuralEdits3D(__privateGet(this, _state2), options.edits === void 0 ? [] : options.edits, this);
    if (!ticks) {
      __privateSet(this, _state2, edited.state);
      __privateSet(this, _external2, __privateGet(this, _external2) + edited.externalQ);
      return;
    }
    let input = edited.state;
    for (let t = 0; t < ticks; t++) {
      let state = solveStructure3D(input, this).state, spare = clone(state);
      for (const pass of volumeSchedule(__privateGet(this, _tick2))) {
        executeStructuralMaterialPass(state, spare, this.width, this.height, this.depth, __privateGet(this, _tick2), pass);
        [state, spare] = [spare, state];
      }
      state.structure = normalizeStructure3D(state.grid, state.structure, this);
      __privateSet(this, _state2, state);
      __privateWrapper(this, _tick2)._++;
      if (t === 0) __privateSet(this, _external2, __privateGet(this, _external2) + edited.externalQ);
      input = state;
    }
  }
  sample(x, y, z) {
    const i = position({ x, y, z }, this), v = __privateGet(this, _state2).grid[i], q = __privateGet(this, _state2).energyQ[i], s = __privateGet(this, _state2).structure[i];
    return {
      material: v & 255,
      materialName: DEFAULT_REGISTRY.material(v & 255).name,
      phase: v >>> PHASE_SHIFT & 15,
      thermal: v >>> 8 & 255,
      energyQ: q,
      temperatureQ: temperatureQ(v, q, cold$1),
      structure: s,
      integrity: s & INTEGRITY_3D,
      anchored: Boolean(s & ANCHOR_3D),
      bonds: BONDS_3D.map((b) => Boolean(s & b))
    };
  }
  copyStateInto(target) {
    const arrays = stateCopyTargets(target, __privateGet(this, _state2).grid.length);
    if (arrays.some((a) => !(a.buffer instanceof ArrayBuffer))) throw Error("State copy requires owned ArrayBuffers.");
    for (const [i, key] of ["grid", "energyQ", "structure"].entries()) Uint32Array.prototype.set.call(arrays[i], __privateGet(this, _state2)[key]);
    return __privateGet(this, _tick2);
  }
  snapshot() {
    return {
      schemaVersion: STRUCTURAL_SCHEMA_VERSION_3D,
      rulesVersion: STRUCTURAL_RULES_VERSION_3D,
      worldVersion: STRUCTURAL_WORLD_VERSION_3D,
      materialCatalogHash: MATERIAL_CATALOG_HASH_3D,
      width: this.width,
      height: this.height,
      depth: this.depth,
      chunkSize: this.chunkSize,
      tick: __privateGet(this, _tick2),
      packedCells: Array.from(__privateGet(this, _state2).grid),
      energyQ: Array.from(__privateGet(this, _state2).energyQ),
      structure: Array.from(__privateGet(this, _state2).structure)
    };
  }
  restore(snapshot) {
    const next = validateStructuralSnapshot3D(snapshot);
    if (snapshot.width !== this.width || snapshot.height !== this.height || snapshot.depth !== this.depth) throw Error("Structural snapshot geometry differs.");
    __privateSet(this, _state2, next);
    __privateSet(this, _tick2, snapshot.tick);
    __privateSet(this, _initial2, total$1(next));
    __privateSet(this, _external2, 0n);
  }
  energyLedger() {
    return energyLedger(__privateGet(this, _state2), cold$1);
  }
  energyBalance() {
    const currentQ = total$1(__privateGet(this, _state2));
    return { initialQ: __privateGet(this, _initial2), externalQ: __privateGet(this, _external2), currentQ, driftQ: currentQ - __privateGet(this, _initial2) - __privateGet(this, _external2) };
  }
  inspectStructure() {
    return solveStructure3D(__privateGet(this, _state2), this);
  }
}
_state2 = new WeakMap();
_tick2 = new WeakMap();
_initial2 = new WeakMap();
_external2 = new WeakMap();
const palette = Array.from({ length: 18 }, (_, i) => {
  const m = MATERIALS_3D.find((m2) => m2.id === i);
  return `vec3f(${[1, 3, 5].map((k) => m ? parseInt(m.color.slice(k, k + 2), 16) / 255 : 0).join(",")})`;
}).join(",");
const COMMON = `
struct Camera { eye:vec4f, right:vec4f, up:vec4f, forward:vec4f, projection:vec4f, shape:vec4u }
const normals=array<vec3i,6>(vec3i(-1,0,0),vec3i(1,0,0),vec3i(0,-1,0),vec3i(0,1,0),vec3i(0,0,-1),vec3i(0,0,1));
`;
const DRAW = COMMON + `
@group(0) @binding(0) var<storage,read> grid:array<u32>;
@group(0) @binding(1) var<storage,read> faces:array<u32>;
@group(0) @binding(2) var<uniform> camera:Camera;
const colors=array<vec3f,18>(${palette});
struct Out{@builtin(position) position:vec4f,@location(0) color:vec3f,@location(1) fog:f32,@location(2) uv:vec2f}
@vertex fn vertex(@builtin(vertex_index) vertex:u32,@builtin(instance_index) instance:u32)->Out{
 let face=faces[instance];let i=face/6u;let f=face%6u;let shape=camera.shape.xyz;
 let c=vec3f(f32(i%shape.x),f32((i/shape.x)%shape.y),f32(i/(shape.x*shape.y)));
 let uvs=array<vec2f,6>(vec2f(0,0),vec2f(1,0),vec2f(1,1),vec2f(0,0),vec2f(1,1),vec2f(0,1));let uv=uvs[vertex];
 var local=vec3f(0);switch f{
 case 0u:{local=vec3f(0,uv.y,uv.x);}case 1u:{local=vec3f(1,uv.y,1-uv.x);}
 case 2u:{local=vec3f(uv.x,0,1-uv.y);}case 3u:{local=vec3f(uv.x,1,uv.y);}
 case 4u:{local=vec3f(1-uv.x,uv.y,0);}default:{local=vec3f(uv.x,uv.y,1);}}
 let v=grid[i];let m=v&255u;if(m==9u){local=vec3f(.39)+local*.22;}
 let p=c+local-camera.eye.xyz;let z=dot(p,camera.forward.xyz);
 var out:Out;out.position=vec4f(dot(p,camera.right.xyz)/camera.projection.x,dot(p,camera.up.xyz)/camera.projection.y,camera.projection.z*z+camera.projection.w,z);
 let light=.30+.70*max(0.,dot(vec3f(normals[f]),normalize(vec3f(.4,-.85,.3))));
 let heat=clamp((f32((v>>8u)&255u)-170.)/85.,0.,1.);
 var color=colors[m]*light+heat*vec3f(.3,.05,0);
 if(i==camera.shape.w){color=mix(color,vec3f(1,.7,.22),.38);}
 out.color=color;out.fog=clamp(z/90.,0.,.7);out.uv=uv;return out;
}
@fragment fn fragment(v:Out)->@location(0) vec4f{let edge=select(1.,.78,any(v.uv<vec2f(.02))||any(v.uv>vec2f(.98)));return vec4f(mix(v.color*edge,vec3f(.065,.10,.15),v.fog),1);}
`;
async function makeChunkRenderer(device, canvas, state, dirty, edge, profiler, tick = () => 0) {
  const context = canvas.getContext("webgpu");
  if (!context) throw new Error("Cannot create WebGPU canvas.");
  const shape = state().shape, count = shape.reduce((a, b) => a * b, 1), capacity = edge ** 3 * 6, chunks = count / edge ** 3;
  const format = navigator.gpu.getPreferredCanvasFormat();
  context.configure({ device, format, alphaMode: "opaque" });
  const mapping = `
const EDGE=${edge}u;
fn coordinate(i:u32)->vec3u{let n=camera.shape.xyz/EDGE;let k=i/(EDGE*EDGE*EDGE);let l=i%(EDGE*EDGE*EDGE);return vec3u(k%n.x,(k/n.x)%n.y,k/(n.x*n.y))*EDGE+vec3u(l%EDGE,(l/EDGE)%EDGE,l/(EDGE*EDGE));}
fn index(c:vec3u)->u32{let n=camera.shape.xyz/EDGE;let k=c/EDGE;let l=c%EDGE;return (k.x+n.x*(k.y+n.y*k.z))*EDGE*EDGE*EDGE+l.x+EDGE*(l.y+EDGE*l.z);}
fn linear(c:vec3u)->u32{return c.x+camera.shape.x*(c.y+camera.shape.y*c.z);}
`;
  const common = `struct Camera {eye:vec4f,right:vec4f,up:vec4f,forward:vec4f,projection:vec4f,shape:vec4u}
@group(0) @binding(0) var<storage,read> grid:array<u32>;
@group(0) @binding(1) var<storage,read_write> faces:array<u32>;
@group(0) @binding(2) var<storage,read_write> args:array<atomic<u32>>;
@group(0) @binding(3) var<uniform> camera:Camera;
@group(0) @binding(4) var<storage,read_write> dirty:array<atomic<u32>>;
@group(0) @binding(5) var<storage,read_write> rebuild:array<u32>;
@group(0) @binding(6) var<storage,read_write> work:array<u32>;
@group(0) @binding(7) var<storage,read_write> dispatch:array<u32>;
${mapping}
@compute @workgroup_size(1) fn reset(){
 var length=0u;
 for(var k=0u;k<${chunks}u;k++){
  let changed=atomicExchange(&dirty[k],0u);rebuild[k]=changed;
  if(changed!=0u){
   work[length]=k;length++;
   atomicStore(&args[k*4u],6u);atomicStore(&args[k*4u+1u],0u);atomicStore(&args[k*4u+2u],k*6u);atomicStore(&args[k*4u+3u],0u);
  }
 }
 dispatch[0]=${Math.ceil(edge ** 3 / 64)}u;dispatch[1]=length;dispatch[2]=1u;
}
@compute @workgroup_size(64) fn mesh(@builtin(global_invocation_id) id:vec3u){
 if(id.x>=EDGE*EDGE*EDGE){return;}let k=work[id.y];let i=k*EDGE*EDGE*EDGE+id.x;
 let m=grid[i]&255u;if(m==0u){return;}let c=vec3i(coordinate(i));
 let normals=array<vec3i,6>(vec3i(-1,0,0),vec3i(1,0,0),vec3i(0,-1,0),vec3i(0,1,0),vec3i(0,0,-1),vec3i(0,0,1));
 for(var f=0u;f<6u;f++){let t=c+normals[f];var exposed=true;
  if(m!=9u&&all(t>=vec3i(0))&&all(t<vec3i(camera.shape.xyz))){let n=grid[index(vec3u(t))]&255u;exposed=n==0u||n==9u;}
  if(exposed){let slot=atomicAdd(&args[k*4u+1u],1u);faces[k*${capacity}u+slot]=i*6u+f;}
 }
}`;
  const drawCode = DRAW.replace("const colors=", mapping + "\nconst colors=").replace("let face=faces[instance];", "let face=faces[(vertex/6u)*" + capacity + "u+instance];").replace("let c=vec3f(f32(i%shape.x),f32((i/shape.x)%shape.y),f32(i/(shape.x*shape.y)));", "let c=vec3f(coordinate(i));").replace("let uv=uvs[vertex];", "let uv=uvs[vertex%6u];").replace("if(i==camera.shape.w)", "if(linear(coordinate(i))==camera.shape.w)");
  async function module(code) {
    const m = device.createShaderModule({ code });
    const info = await m.getCompilationInfo();
    const errors = info.messages.filter((m2) => m2.type === "error");
    if (errors.length) throw new Error(errors.map((m2) => `${m2.lineNum}: ${m2.message}`).join("\n"));
    return m;
  }
  const meshModule = await module(common), drawModule = await module(drawCode);
  const reset = await device.createComputePipelineAsync({ layout: "auto", compute: { module: meshModule, entryPoint: "reset" } });
  const mesh = await device.createComputePipelineAsync({ layout: "auto", compute: { module: meshModule, entryPoint: "mesh" } });
  const draw = await device.createRenderPipelineAsync({ layout: "auto", vertex: { module: drawModule, entryPoint: "vertex" }, fragment: { module: drawModule, entryPoint: "fragment", targets: [{ format }] }, primitive: { topology: "triangle-list" }, depthStencil: { format: "depth24plus", depthWriteEnabled: true, depthCompare: "less" } });
  const buffer = (size, usage) => device.createBuffer({ size, usage });
  const faces = buffer(count * 24, GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC), args = buffer(chunks * 16, GPUBufferUsage.STORAGE | GPUBufferUsage.INDIRECT | GPUBufferUsage.COPY_SRC), rebuild = buffer(chunks * 4, GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC), uniform = buffer(96, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST);
  const work = buffer(chunks * 4, GPUBufferUsage.STORAGE), dispatch = buffer(12, GPUBufferUsage.STORAGE | GPUBufferUsage.INDIRECT | GPUBufferUsage.COPY_SRC);
  device.queue.writeBuffer(dirty, 0, new Uint32Array(chunks).fill(1));
  const resetGroup = device.createBindGroup({ layout: reset.getBindGroupLayout(0), entries: [{ binding: 2, resource: { buffer: args } }, { binding: 4, resource: { buffer: dirty } }, { binding: 5, resource: { buffer: rebuild } }, { binding: 6, resource: { buffer: work } }, { binding: 7, resource: { buffer: dispatch } }] });
  const bindings = /* @__PURE__ */ new Map();
  const data = new ArrayBuffer(96), f = new Float32Array(data), u = new Uint32Array(data), near = 0.06, far = 160, tan = Math.tan(Math.PI / 6);
  const n = shape.map((v) => v / edge), radius = Math.sqrt(3) * edge / 2, centers = new Float64Array(chunks * 3);
  for (let k = 0; k < chunks; k++) {
    centers[k * 3] = (k % n[0] + 0.5) * edge;
    centers[k * 3 + 1] = (Math.floor(k / n[0]) % n[1] + 0.5) * edge;
    centers[k * 3 + 2] = (Math.floor(k / (n[0] * n[1])) + 0.5) * edge;
  }
  let depth, width = 0, height = 0, closed = false;
  let heatDistortion = true;
  let appearance = "diagnostic", natural;
  function encode(encoder, camera, grid, trace, gpuCamera, presentationTick = tick()) {
    if (closed) throw new Error("Terrain renderer is closed.");
    const vectors = [camera.eye, camera.right, camera.up, camera.forward].map((a) => {
      if (!a || a.length !== 3) throw new Error("Invalid terrain camera.");
      const v = [a[0], a[1], a[2]];
      if (!v.every(Number.isFinite)) throw new Error("Invalid terrain camera.");
      return v;
    });
    if (camera.target !== void 0 && (!Number.isSafeInteger(camera.target) || camera.target < 0 || camera.target >= count)) throw new Error("Invalid target.");
    if (canvas.width < 1 || canvas.height < 1) throw new Error("Canvas must have positive dimensions.");
    if (!depth || width !== canvas.width || height !== canvas.height) {
      depth == null ? void 0 : depth.destroy();
      width = canvas.width;
      height = canvas.height;
      depth = device.createTexture({ size: [width, height], format: "depth24plus", usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING });
    }
    let groups = bindings.get(grid);
    if (!groups) {
      groups = { mesh: device.createBindGroup({ layout: mesh.getBindGroupLayout(0), entries: [{ binding: 0, resource: { buffer: grid } }, { binding: 1, resource: { buffer: faces } }, { binding: 2, resource: { buffer: args } }, { binding: 3, resource: { buffer: uniform } }, { binding: 6, resource: { buffer: work } }] }), draw: device.createBindGroup({ layout: draw.getBindGroupLayout(0), entries: [grid, faces, uniform].map((buffer2, binding) => ({ binding, resource: { buffer: buffer2 } })) }) };
      bindings.set(grid, groups);
    }
    for (let i = 0; i < 4; i++) f.set(vectors[i], i * 4);
    f.set([tan * width / height, tan, far / (far - near), -near * far / (far - near)], 16);
    u.set([...shape, camera.target ?? 4294967295], 20);
    device.queue.writeBuffer(uniform, 0, data);
    if (gpuCamera) {
      encoder.copyBufferToBuffer(gpuCamera, 64, uniform, 0, 16);
      encoder.copyBufferToBuffer(gpuCamera, 80, uniform, 92, 4);
    }
    const compute = encoder.beginComputePass(profiler == null ? void 0 : profiler.pass(trace, "mesh"));
    compute.setPipeline(reset);
    compute.setBindGroup(0, resetGroup);
    compute.dispatchWorkgroups(1);
    compute.setPipeline(mesh);
    compute.setBindGroup(0, groups.mesh);
    compute.dispatchWorkgroupsIndirect(dispatch, 0);
    compute.end();
    const output = context.getCurrentTexture().createView(), beauty = appearance === "naturalistic" ? natural : void 0;
    const prepared = beauty == null ? void 0 : beauty.prepare(encoder, grid, depth, width, height, presentationTick, heatDistortion, profiler, trace);
    const pass = encoder.beginRenderPass({ ...profiler == null ? void 0 : profiler.pass(trace, "draw"), colorAttachments: [{ view: (prepared == null ? void 0 : prepared.view) ?? output, clearValue: beauty ? [0.028, 0.045, 0.06, 1] : [0.065, 0.1, 0.15, 1], loadOp: "clear", storeOp: "store" }], depthStencilAttachment: { view: depth.createView(), depthClearValue: 1, depthLoadOp: "clear", depthStoreOp: "store" } });
    pass.setPipeline((beauty == null ? void 0 : beauty.draw) ?? draw);
    pass.setBindGroup(0, (prepared == null ? void 0 : prepared.group) ?? groups.draw);
    const bound = radius + (gpuCamera ? 4 : 0), horizontal = tan * width / height, horizontalRadius = bound * Math.hypot(1, horizontal), verticalRadius = bound * Math.hypot(1, tan);
    for (let k = 0; k < chunks; k++) {
      const cx = centers[k * 3] - vectors[0][0], cy = centers[k * 3 + 1] - vectors[0][1], cz = centers[k * 3 + 2] - vectors[0][2];
      const z = cx * vectors[3][0] + cy * vectors[3][1] + cz * vectors[3][2];
      const x = cx * vectors[1][0] + cy * vectors[1][1] + cz * vectors[1][2], y = cx * vectors[2][0] + cy * vectors[2][1] + cz * vectors[2][2];
      if (z + bound < near || z - bound > far || Math.abs(x) > z * horizontal + horizontalRadius || Math.abs(y) > z * tan + verticalRadius) continue;
      pass.drawIndirect(args, k * 16);
    }
    pass.end();
    beauty == null ? void 0 : beauty.finish(encoder, output, profiler, trace);
  }
  const renderer = {
    async setHeatDistortion(value) {
      if (closed) throw new Error("Terrain renderer is closed.");
      if (typeof value !== "boolean") throw new Error("Heat distortion must be boolean.");
      heatDistortion = value;
    },
    async setAppearance(value) {
      if (closed) throw new Error("Terrain renderer is closed.");
      if (value !== "diagnostic" && value !== "naturalistic") throw new Error("Invalid terrain appearance.");
      if (value === "naturalistic" && !natural) {
        const { makeCavernAppearance } = await import("./cavern-appearance-B1KAbJm-.js");
        natural = await makeCavernAppearance(device, format, shape, edge, capacity, faces, uniform);
      }
      appearance = value;
    },
    validateCamera(camera) {
      if (closed) throw new Error("Terrain renderer is closed.");
      for (const a of [camera.eye, camera.right, camera.up, camera.forward]) if (!a || a.length !== 3 || ![a[0], a[1], a[2]].every(Number.isFinite)) throw new Error("Invalid terrain camera.");
      if (camera.target !== void 0 && (!Number.isSafeInteger(camera.target) || camera.target < 0 || camera.target >= count)) throw new Error("Invalid target.");
      if (canvas.width < 1 || canvas.height < 1) throw new Error("Canvas must have positive dimensions.");
    },
    encode(encoder, camera, grid, gpuCamera, trace, presentationTick) {
      encode(encoder, camera, grid, trace, gpuCamera, presentationTick);
    },
    async render(camera) {
      renderer.validateCamera(camera);
      const trace = profiler == null ? void 0 : profiler.begin("render", tick());
      device.pushErrorScope("validation");
      const encoder = device.createCommandEncoder();
      encode(encoder, camera, state().grid, trace);
      device.queue.submit([encoder.finish()]);
      const results = await Promise.allSettled([device.popErrorScope(), device.queue.onSubmittedWorkDone().then(() => profiler == null ? void 0 : profiler.mark(trace, "queueCompletedAt"))]);
      for (const r of results) {
        if (r.status === "rejected") throw r.reason;
        if (r.value) throw new Error(r.value.message);
      }
    },
    async inspectMesh() {
      if (closed) throw new Error("Terrain renderer is closed.");
      const meshBytes = chunks * 20 + count * 24, bytes = meshBytes + 12, read = buffer(bytes, GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ), e = device.createCommandEncoder();
      e.copyBufferToBuffer(args, 0, read, 0, chunks * 16);
      e.copyBufferToBuffer(rebuild, 0, read, chunks * 16, chunks * 4);
      e.copyBufferToBuffer(faces, 0, read, chunks * 20, count * 24);
      e.copyBufferToBuffer(dispatch, 0, read, meshBytes, 12);
      device.queue.submit([e.finish()]);
      try {
        await read.mapAsync(GPUMapMode.READ);
        const words = new Uint32Array(read.getMappedRange()), result = [];
        for (let k = 0; k < chunks; k++) result.push(Array.from(words.subarray(chunks * 5 + k * capacity, chunks * 5 + k * capacity + words[k * 4 + 1])).sort((a, b) => a - b));
        return { faces: result, rebuilt: Array.from(words.subarray(chunks * 4, chunks * 5)), meshDispatch: Array.from(words.subarray(meshBytes / 4, meshBytes / 4 + 3)) };
      } finally {
        if (read.mapState === "mapped") read.unmap();
        read.destroy();
      }
    },
    close() {
      if (closed) return;
      closed = true;
      natural == null ? void 0 : natural.close();
      depth == null ? void 0 : depth.destroy();
      faces.destroy();
      args.destroy();
      rebuild.destroy();
      uniform.destroy();
      work.destroy();
      dispatch.destroy();
      context.unconfigure();
      bindings.clear();
    }
  };
  return renderer;
}
function gameplayShader(shape, edge, sparse, rules, air) {
  const [w, h, d] = shape, active = Math.min(edge, 8), tiles = w * h * d / active ** 3;
  const thermal = VOLUME_SHADER.slice(VOLUME_SHADER.indexOf("fn prop("), VOLUME_SHADER.indexOf("fn phase("));
  return `
const SHAPE=vec3i(${w},${h},${d});const EDGE=${edge}u;const ACTIVE=${active}u;
const MAX_Q=0x3fffffffu;
@group(0) @binding(0) var<storage,read_write> cells:array<u32>;
@group(0) @binding(1) var<storage,read_write> energies:array<u32>;
@group(0) @binding(2) var<storage,read> cold:array<u32>;
// player[0..8], status[9], event flags[10], look[11..13], cache origin[14..16].
@group(0) @binding(3) var<storage,read_write> actor:array<i32>;
@group(0) @binding(4) var<storage,read_write> cache:array<u32>;
@group(0) @binding(5) var<storage,read_write> result:array<u32>;
struct Command {controls:vec4i,lookTick:vec4i,view:vec4i}
@group(0) @binding(6) var<uniform> command:Command;
@group(0) @binding(7) var<storage,read_write> dirty:array<atomic<u32>>;
${sparse ? "@group(0) @binding(8) var<storage,read_write> activity:array<atomic<u32>>;" : ""}
${thermal}
fn index(c:vec3i)->u32{let u=vec3u(c);let n=vec3u(SHAPE)/EDGE;let k=u/EDGE;let l=u%EDGE;return (k.x+n.x*(k.y+n.y*k.z))*EDGE*EDGE*EDGE+l.x+EDGE*(l.y+EDGE*l.z);}
// WGSL signed division truncates; voxel coordinates require mathematical floor.
fn floorQ(v:i32)->i32{return select((v-255)/256,v/256,v>=0);}
fn floorVector(v:vec3i)->vec3i{return vec3i(floorQ(v.x),floorQ(v.y),floorQ(v.z));}
fn origin()->vec3i{return vec3i(actor[14],actor[15],actor[16]);}
fn eye()->vec3i{return vec3i(actor[0],actor[1]-400,actor[2]);}
fn cachedCell(c:vec3i)->u32{
 if(any(c<vec3i(0))||any(c>=SHAPE)){return 1u;}
 let l=c-origin();if(any(l<vec3i(0))||any(l>=vec3i(16))){result[25]=1u;return 1u;}
 return cache[u32(l.x+16*(l.y+16*l.z))];
}
fn ray(look:vec3i)->vec4i{
 var previous=vec3i(-1000000);
 for(var n=0;n<=160;n++){
  let c=floorVector(eye()+look*n/32);if(all(c==previous)){continue;}previous=c;
  if(any(c<vec3i(0))||any(c>=SHAPE)||any(c<origin())||any(c>=origin()+vec3i(16))){return vec4i(0,0,0,-1);}
  let m=i32(cachedCell(c)&255u);if(m!=0&&m!=9){return vec4i(c,m);}
 }
 return vec4i(0,0,0,-1);
}
fn solid(v:u32)->bool{let p=(v>>24u)&15u;return p==0u||p==1u||p==6u;}
fn overlaps(p:vec3i)->bool{
 let lo=floorVector(p-vec3i(77,448,77));let hi=floorVector(p+vec3i(76,-1,76));
 for(var z=lo.z;z<=hi.z;z++){for(var y=lo.y;y<=hi.y;y++){for(var x=lo.x;x<=hi.x;x++){if(solid(cachedCell(vec3i(x,y,z)))){return true;}}}}
 return false;
}
fn position()->vec3i{return vec3i(actor[0],actor[1],actor[2]);}
fn sweep(axis:u32,velocity:i32)->bool{
 let direction=sign(velocity);var remaining=abs(velocity);
 // Speeds are bounded by 150 Q; retain the CPU's segmented sweep semantics.
 while(remaining>0){
  let distance=min(remaining,256);let start=actor[axis];actor[axis]=start+distance*direction;
  if(overlaps(position())){
   var low=0;var high=distance;
   while(low+1<high){let mid=(low+high)/2;actor[axis]=start+mid*direction;if(overlaps(position())){high=mid;}else{low=mid;}}
   actor[axis]=start+low*direction;return true;
  }
  remaining-=distance;
 }
 return false;
}
fn emit(kind:u32,count:u32,location:vec3i){
 let slot=result[14];if(slot>=4u){result[25]=2u;return;}let base=32u+slot*8u;
 result[base]=kind;result[base+1u]=u32(command.lookTick.w);result[base+2u]=count;
 result[base+3u]=u32(location.x);result[base+4u]=u32(location.y);result[base+5u]=u32(location.z);result[14]=slot+1u;
}
fn mark(c:vec3i){let n=vec3u(SHAPE)/EDGE;let k=vec3u(c)/EDGE;atomicStore(&dirty[k.x+n.x*(k.y+n.y*k.z)],1u);}
fn changed(c:vec3i){
 mark(c);for(var a=0u;a<3u;a++){for(var sign=-1;sign<=1;sign+=2){var t=c;t[a]+=sign;
  if(all(t>=vec3i(0))&&all(t<SHAPE)&&(u32(c[a])/EDGE!=u32(t[a])/EDGE)){mark(t);}
 }}
}
fn wakeEdit(c:vec3i){${sparse ? `
 let n=SHAPE/i32(ACTIVE);let k=c/i32(ACTIVE);let l=vec3u(c)%ACTIVE;
 let lo=-vec3i(select(vec3u(0),vec3u(1),l<vec3u(2)));let hi=vec3i(select(vec3u(0),vec3u(1),l+vec3u(2)>=vec3u(ACTIVE)));
 atomicStore(&activity[10],1u);
 for(var z=lo.z;z<=hi.z;z++){for(var y=lo.y;y<=hi.y;y++){for(var x=lo.x;x<=hi.x;x++){
  let t=k+vec3i(x,y,z);if(all(t>=vec3i(0))&&all(t<n)){let j=u32(t.x+n.x*(t.y+n.y*t.z));atomicStore(&activity[16u+j],1u);atomicOr(&activity[${16 + 3 * tiles}u+j],16u);}
 }}}
 ` : ""}}
fn beginFrame(){for(var k=0u;k<128u;k++){result[k]=0u;}if(actor[7]>0){actor[7]--;}}
// A known no-tool command must not acquire write access to the terrain or activity buffers.
@compute @workgroup_size(1) fn noTools(){beginFrame();}
@compute @workgroup_size(1) fn tools(){
 beginFrame();
 if(command.controls.w==0||actor[7]!=0||actor[9]==2){return;}
 let hit=ray(command.lookTick.xyz);if(hit.w<0){return;}
 var count=0u;
 for(var z=hit.z-1;z<=hit.z+1;z++){for(var y=hit.y-1;y<=hit.y+1;y++){for(var x=hit.x-1;x<=hit.x+1;x++){
  let c=vec3i(x,y,z);if(any(c<vec3i(1))||x>=SHAPE.x-1||z>=SHAPE.z-1||y>=${rules.toolCeiling}){continue;}
  let m=cachedCell(c)&255u;let carve=command.controls.w==1&&(m==${MAT.STONE}u||m==${MAT.GLASS}u||m==${MAT.SAND}u||m==${MAT.ICE}u);
  let freeze=command.controls.w==2&&(m==${MAT.WATER}u||m==${MAT.ICE}u);if(!carve&&!freeze){continue;}
  let i=index(c);let old=energies[i];var q=0u;
  if(carve){cells[i]=${air[0]}u;q=${air[1]}u;changed(c);}else{cells[i]=thermal(cells[i],0u);}
  energies[i]=q;result[64u+count*2u]=old;result[65u+count*2u]=q;count++;wakeEdit(c);
 }}}
 result[15]=count;
 if(count>0u){actor[7]=6;if(command.controls.w==1){actor[10]|=1;}emit(u32(command.controls.w),count,hit.xyz);}
}
@compute @workgroup_size(64) fn cacheRegion(@builtin(global_invocation_id) id:vec3u){
 if(id.x>=4096u){return;}
 // Every lane derives the same origin from immutable position coordinates.
 // Only lane zero stores metadata; no lane reads it during this dispatch.
 let o=clamp(floorVector(position()-vec3i(0,224,0))-vec3i(8),vec3i(0),SHAPE-vec3i(16));
 if(id.x==0u){actor[14]=o.x;actor[15]=o.y;actor[16]=o.z;}
 let c=o+vec3i(i32(id.x%16u),i32((id.x/16u)%16u),i32(id.x/256u));cache[id.x]=cells[index(c)];
}
fn output(){
 for(var k=0u;k<14u;k++){result[k]=bitcast<u32>(actor[k]);}
 let e=vec3f(eye())/256.0;result[16]=bitcast<u32>(e.x);result[17]=bitcast<u32>(e.y);result[18]=bitcast<u32>(e.z);result[19]=0u;
 let hit=ray(command.view.xyz);result[20]=0xffffffffu;
 if(hit.w>=0){result[20]=u32(hit.x+SHAPE.x*(hit.y+SHAPE.y*hit.z));result[21]=u32(hit.w);result[22]=u32(hit.x);result[23]=u32(hit.y);result[24]=u32(hit.z);}
}
@compute @workgroup_size(1) fn locomotion(){
 actor[11]=command.lookTick.x;actor[12]=command.lookTick.y;actor[13]=command.lookTick.z;
 if(actor[9]!=2){
  if(overlaps(position())){
   var freed=false;for(var d=1;d<=3;d++){if(!overlaps(position()-vec3i(0,d*256,0))){actor[1]-=d*256;actor[3]=0;freed=true;break;}}
   if(!freed){actor[9]=2;emit(3u,0u,vec3i(0));}
  }
  if(actor[9]!=2){
   let wet=(cachedCell(floorVector(position()-vec3i(0,128,0)))&255u)==2u;actor[5]=i32(wet);
   if(command.controls.z!=0&&((actor[4]!=0&&actor[6]==0)||wet)){actor[3]=select(-115,-65,wet);}
   actor[3]=min(select(150,45,wet),actor[3]+select(8,4,wet));let speed=select(48,28,wet);
   let blockedX=sweep(0u,command.controls.x*speed/256);let blockedZ=sweep(2u,command.controls.y*speed/256);actor[8]=i32(blockedX||blockedZ);
   let hit=sweep(1u,actor[3]);let falling=actor[3]>0;if(hit){actor[3]=0;}
   actor[4]=i32((hit&&falling)||overlaps(position()+vec3i(0,1,0)));
   let under=cachedCell(floorVector(position()))&255u;
   if(actor[4]!=0&&under==${MAT.ICE}u&&(actor[10]&2)==0){actor[10]|=2;emit(4u,0u,vec3i(0));}
   if(actor[9]==0&&actor[0]>=${rules.goal.minX}&&actor[1]<=${rules.goal.maxY}&&actor[2]>=${rules.goal.minZ}&&actor[2]<=${rules.goal.maxZ}&&(actor[10]&3)==3){actor[9]=1;emit(5u,0u,vec3i(0));}
   if(actor[1]>${rules.fallY}){actor[9]=2;emit(6u,0u,vec3i(0));}
  }
 }
 actor[6]=command.controls.z;output();
}
@compute @workgroup_size(1) fn present(){for(var k=0u;k<128u;k++){result[k]=0u;}output();}
`;
}
const statuses = ["playing", "won", "lost"];
const tools = ["none", "carve", "freeze"];
function look(v) {
  if (!Array.isArray(v) || v.length !== 3) throw new Error("Invalid gameplay look.");
  const owned = [v[0], v[1], v[2]];
  for (const n of owned) checkedInteger(n, -256, 256, "look");
  const length = owned.reduce((s, n) => s + n * n, 0);
  if (length < 250 ** 2 || length > 262 ** 2) throw new Error("Invalid gameplay look length.");
  return owned;
}
function checkedGameplayState(state, shape) {
  if (!state || Object.keys(state).sort().join(",") !== "carved,iceWalk,look,player,status") throw new Error("Invalid gameplay state.");
  const p = state.player;
  if (!p || Object.keys(p).sort().join(",") !== "blocked,cooldown,grounded,jumpHeld,vy,wet,x,y,z") throw new Error("Invalid gameplay player.");
  checkedInteger(p.x, 77, shape[0] * 256 - 77, "player x");
  checkedInteger(p.y, 448, shape[1] * 256, "player y");
  checkedInteger(p.z, 77, shape[2] * 256 - 77, "player z");
  checkedInteger(p.vy, -150, 150, "player velocity");
  checkedInteger(p.cooldown, 0, 6, "cooldown");
  for (const v of [p.grounded, p.wet, p.jumpHeld, p.blocked, state.carved, state.iceWalk]) if (typeof v !== "boolean") throw new Error("Invalid gameplay flag.");
  if (!statuses.includes(state.status)) throw new Error("Invalid gameplay status.");
  return { player: { ...p }, look: look(state.look), status: state.status, carved: state.carved, iceWalk: state.iceWalk };
}
function checkedGameplayRules(rules, shape) {
  if (!rules || Object.keys(rules).sort().join(",") !== "fallY,goal,toolCeiling" || !rules.goal || Object.keys(rules.goal).sort().join(",") !== "maxY,maxZ,minX,minZ") throw new Error("Invalid gameplay rules.");
  const g = rules.goal;
  checkedInteger(g.minX, 0, shape[0] * 256, "goal x");
  checkedInteger(g.maxY, 0, shape[1] * 256, "goal y");
  checkedInteger(g.minZ, 0, shape[2] * 256, "goal z");
  checkedInteger(g.maxZ, g.minZ, shape[2] * 256, "goal max z");
  checkedInteger(rules.fallY, 448, shape[1] * 256, "fall threshold");
  checkedInteger(rules.toolCeiling, 1, shape[1] - 1, "tool ceiling");
  return { ...rules, goal: { ...g } };
}
function checkedGameplayCommand(c, tick) {
  if (!c || Object.keys(c).sort().join(",") !== "jump,look,moveX,moveZ,tick,tool") throw new Error("Invalid gameplay command.");
  checkedInteger(c.tick, tick, tick, "command tick");
  checkedInteger(c.tick, 1, 7200, "gameplay tick");
  checkedInteger(c.moveX, -256, 256, "moveX");
  checkedInteger(c.moveZ, -256, 256, "moveZ");
  if (c.moveX ** 2 + c.moveZ ** 2 > 257 ** 2 || typeof c.jump !== "boolean" || !tools.includes(c.tool)) throw new Error("Invalid gameplay input.");
  return { ...c, look: look(c.look) };
}
async function makeGameplayResources(device, shape, edge, cold2, dirty, activity, rules, profiler) {
  const seed = createStateSpaceField3D(1, 1, 1).snapshot();
  const module = device.createShaderModule({ code: gameplayShader(shape, edge, Boolean(activity), rules, [seed.packedCells[0], seed.energyQ[0]]) });
  const errors = (await module.getCompilationInfo()).messages.filter((m) => m.type === "error");
  if (errors.length) throw new Error(errors.map((m) => `${m.lineNum}: ${m.message}`).join("\n"));
  const pipelines = {};
  for (const entryPoint of ["tools", "noTools", "cacheRegion", "locomotion", "present"]) pipelines[entryPoint] = await device.createComputePipelineAsync({ layout: "auto", compute: { module, entryPoint } });
  const buffers = [];
  const buffer = (size, usage) => {
    const b = device.createBuffer({ size, usage });
    buffers.push(b);
    return b;
  };
  const storage2 = GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC;
  const actor = buffer(128, storage2), cache = buffer(4096 * 4, storage2), result = buffer(512, storage2), read = buffer(512, GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ), uniform = buffer(48, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST);
  const params = new Int32Array(12), groups = /* @__PURE__ */ new Map();
  function bindings(grid, energy) {
    let g = groups.get(grid);
    if (g) return g;
    g = {};
    const resources = [grid, energy, cold2, actor, cache, result, uniform, dirty, activity];
    const entries = { tools: [0, 1, 2, 3, 4, 5, 6, 7, ...[]], noTools: [3, 5], cacheRegion: [0, 3, 4], locomotion: [3, 4, 5, 6], present: [3, 4, 5, 6] };
    for (const name of Object.keys(pipelines)) g[name] = device.createBindGroup({ layout: pipelines[name].getBindGroupLayout(0), entries: entries[name].map((binding) => ({ binding, resource: { buffer: resources[binding] } })) });
    groups.set(grid, g);
    return g;
  }
  function dispatch(encoder, name, grid, energy, count = 1, trace, label = name) {
    const pass = encoder.beginComputePass(profiler.pass(trace, label));
    pass.setPipeline(pipelines[name]);
    pass.setBindGroup(0, bindings(grid, energy)[name]);
    pass.dispatchWorkgroups(count);
    pass.end();
  }
  return {
    result,
    read,
    writeState(s) {
      const p = s.player, a = new Int32Array(32);
      a.set([p.x, p.y, p.z, p.vy, +p.grounded, +p.wet, +p.jumpHeld, p.cooldown, +p.blocked, statuses.indexOf(s.status), +s.carved | +s.iceWalk << 1, ...s.look]);
      device.queue.writeBuffer(actor, 0, a);
    },
    prepare(c, view = c.look) {
      const v = look(view);
      params.set([c.moveX, c.moveZ, +c.jump, tools.indexOf(c.tool), ...c.look, c.tick, ...v, 0]);
      device.queue.writeBuffer(uniform, 0, params);
    },
    initialize(e, grid, energy) {
      dispatch(e, "cacheRegion", grid, energy, 64);
    },
    tools(e, grid, energy, canEdit, trace) {
      dispatch(e, canEdit ? "tools" : "noTools", grid, energy, 1, trace, "tools");
    },
    controller(e, grid, energy, trace) {
      dispatch(e, "cacheRegion", grid, energy, 64, trace, "collisionCache");
      dispatch(e, "locomotion", grid, energy, 1, trace, "controller");
    },
    present(e, grid, energy, trace) {
      dispatch(e, "present", grid, energy, 1, trace, "controller");
    },
    decode(words, tick) {
      if (words[25] || words[14] > 4 || words[15] > 27) throw new Error(`GPU gameplay rejected its bounded neighborhood (${words[25]}).`);
      const signed = new Int32Array(words.buffer, words.byteOffset, words.length), types = ["carved", "cooled", "trapped", "ice-walk", "crossed", "fell"];
      const state = checkedGameplayState({ player: { x: signed[0], y: signed[1], z: signed[2], vy: signed[3], grounded: Boolean(words[4]), wet: Boolean(words[5]), jumpHeld: Boolean(words[6]), cooldown: words[7], blocked: Boolean(words[8]) }, status: statuses[words[9]], carved: Boolean(words[10] & 1), iceWalk: Boolean(words[10] & 2), look: [signed[11], signed[12], signed[13]] }, shape);
      const events = [];
      for (let i = 0; i < words[14]; i++) {
        const b = 32 + i * 8, type = types[words[b] - 1];
        if (!type || words[b + 1] !== tick) throw new Error("Invalid GPU gameplay event.");
        events.push({ tick, type, ...words[b] <= 2 ? { cells: words[b + 2], target: [words[b + 3], words[b + 4], words[b + 5]] } : {} });
      }
      return { ...state, tick, events, target: words[20] === 4294967295 ? null : { cell: [words[22], words[23], words[24]], material: words[21] }, submissions: 1, completionBoundaries: 1, actorReadbackBytes: 512 };
    },
    close() {
      for (const b of buffers) b.destroy();
      groups.clear();
    }
  };
}
class LatencyProfiler {
  constructor(device, enabled = false, gpuTiming = false) {
    __publicField(this, "enabled");
    __publicField(this, "gpuTimestamps");
    __publicField(this, "gpuTimingRequested");
    __privateAdd(this, _slots, []);
    __privateAdd(this, _records2, []);
    __privateAdd(this, _pending, /* @__PURE__ */ new Set());
    __privateAdd(this, _next, 0);
    this.enabled = enabled;
    this.gpuTimingRequested = enabled && gpuTiming;
    this.gpuTimestamps = this.gpuTimingRequested && device.features.has("timestamp-query");
    if (this.gpuTimestamps) for (let i = 0; i < 3; i++) __privateGet(this, _slots).push({
      query: device.createQuerySet({ type: "timestamp", count: 20 }),
      resolve: device.createBuffer({ size: 256, usage: GPUBufferUsage.QUERY_RESOLVE | GPUBufferUsage.COPY_SRC }),
      read: device.createBuffer({ size: 256, usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ }),
      busy: false
    });
  }
  begin(kind, tick) {
    if (!this.enabled) return;
    const slot = __privateGet(this, _slots).find((s) => !s.busy);
    if (slot) slot.busy = true;
    const record = {
      id: ++__privateWrapper(this, _next)._,
      kind,
      tick,
      cpu: { startedAt: performance.now() },
      gpu: { status: slot ? "pending" : this.gpuTimestamps ? "busy" : this.gpuTimingRequested ? "unsupported" : "disabled", ms: {} }
    };
    __privateGet(this, _records2).push(record);
    if (__privateGet(this, _records2).length > 32) __privateGet(this, _records2).shift();
    return { record, slot, labels: [] };
  }
  mark(trace, name) {
    if (trace) trace.record.cpu[name] = performance.now();
  }
  pass(trace, label) {
    if (!(trace == null ? void 0 : trace.slot)) return {};
    if (trace.labels.length >= 10) throw new Error("Latency query capacity exceeded.");
    const index = trace.labels.length * 2;
    trace.labels.push(label);
    return { timestampWrites: { querySet: trace.slot.query, beginningOfPassWriteIndex: index, endOfPassWriteIndex: index + 1 } };
  }
  resolve(encoder, trace) {
    if (!(trace == null ? void 0 : trace.slot) || !trace.labels.length) return;
    encoder.resolveQuerySet(trace.slot.query, 0, trace.labels.length * 2, trace.slot.resolve, 0);
    encoder.copyBufferToBuffer(trace.slot.resolve, 0, trace.slot.read, 0, trace.labels.length * 16);
  }
  submitted(trace) {
    this.mark(trace, "submittedAt");
    if (!(trace == null ? void 0 : trace.slot)) return;
    const slot = trace.slot;
    if (!trace.labels.length) {
      slot.busy = false;
      trace.record.gpu.status = "complete";
      return;
    }
    const pending = slot.read.mapAsync(GPUMapMode.READ, 0, trace.labels.length * 16).then(() => {
      const times = new BigUint64Array(slot.read.getMappedRange(0, trace.labels.length * 16));
      for (let i = 0; i < trace.labels.length; i++) {
        if (times[i * 2 + 1] < times[i * 2]) throw new Error("Non-monotonic GPU timestamps.");
        trace.record.gpu.ms[trace.labels[i]] = Number(times[i * 2 + 1] - times[i * 2]) / 1e6;
      }
      trace.record.gpu.status = "complete";
    }).catch((error) => {
      trace.record.gpu.status = "error";
      trace.record.gpu.error = String(error);
    }).finally(() => {
      if (slot.read.mapState === "mapped") slot.read.unmap();
      slot.busy = false;
      __privateGet(this, _pending).delete(pending);
    });
    __privateGet(this, _pending).add(pending);
  }
  snapshot(afterId = 0) {
    if (!Number.isSafeInteger(afterId) || afterId < 0) throw new Error("Invalid latency cursor.");
    return {
      enabled: this.enabled,
      gpuTimingRequested: this.gpuTimingRequested,
      gpuTimestamps: this.gpuTimestamps,
      capacity: 32,
      records: __privateGet(this, _records2).filter((r) => r.id > afterId).map((r) => ({ ...r, cpu: { ...r.cpu }, gpu: { ...r.gpu, ms: { ...r.gpu.ms } } }))
    };
  }
  /** For receipt finalization only, after the measured loop has stopped. */
  async settle() {
    await Promise.all(__privateGet(this, _pending));
  }
  close() {
    for (const s of __privateGet(this, _slots)) {
      s.query.destroy();
      s.resolve.destroy();
      s.read.destroy();
    }
  }
}
_slots = new WeakMap();
_records2 = new WeakMap();
_pending = new WeakMap();
_next = new WeakMap();
const KINDS = ["gravity", "diagonal", "liquid", "buoyancy", "gas", "heat", "phase"];
const BINDINGS = {
  main: [0, 1, 2, 3, 4, 5, 6, 7, 8],
  supportInit: [0, 4, 7, 9],
  supportRelax: [7, 9],
  supportSummary: [0, 4, 9],
  loadLevel: [0, 4, 5, 7, 9],
  damage: [0, 1, 4, 7, 8, 9],
  normalize: [0, 4, 7, 8],
  componentInit: [7, 9],
  componentRelax: [7, 9],
  blockInit: [0, 4, 7, 9],
  blockRelax: [7, 9],
  applyMotion: [0, 1, 2, 3, 6, 7, 8, 9],
  editBatch: [2, 3, 4, 5, 6, 8, 9, 10, 11],
  certifyLocal: [0, 1, 4, 6, 7],
  collectLocal: [6, 12],
  certifyPlan: [0, 2, 3, 4, 7, 8, 9],
  queryCells: [0, 1, 5, 7, 13],
  relaxStart: [9, 14],
  relaxAdvance: [9, 14],
  relaxEnd: [5, 9, 14],
  loadInit: [0, 4, 9],
  loadRelax: [0, 4, 7, 9],
  loadSummary: [9]
};
const cold = buildColdTable();
const total = (values) => {
  let sum = 0;
  for (let i = 0; i < values.length; i++) sum += values[i];
  return BigInt(sum);
};
const storage = () => GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST;
class GpuStructuralWorld3D {
  constructor(initial, device, pipelines, info, mode, solveBatchLimit) {
    __privateAdd(this, _GpuStructuralWorld3D_instances);
    __publicField(this, "width");
    __publicField(this, "height");
    __publicField(this, "depth");
    __publicField(this, "chunkSize");
    __publicField(this, "backendInfo");
    __publicField(this, "mode");
    __privateAdd(this, _device);
    __privateAdd(this, _pipelines);
    __privateAdd(this, _banks, []);
    __privateAdd(this, _owned, []);
    __privateAdd(this, _current, 0);
    __privateAdd(this, _tick3, 0);
    __privateAdd(this, _cold2);
    __privateAdd(this, _work);
    __privateAdd(this, _dirty);
    __privateAdd(this, _uniform);
    __privateAdd(this, _commands);
    __privateAdd(this, _receipts);
    __privateAdd(this, _controlRead);
    __privateAdd(this, _receiptRead);
    __privateAdd(this, _fullRead);
    __privateAdd(this, _indirect);
    __privateAdd(this, _activityRead);
    __privateAdd(this, _queryResult);
    __privateAdd(this, _queryRead);
    __privateAdd(this, _solveDispatch);
    __privateAdd(this, _solveBatchLimit);
    __privateAdd(this, _groups, /* @__PURE__ */ new Map());
    __privateAdd(this, _params, new Uint32Array(64 * 64));
    __privateAdd(this, _computePass);
    __privateAdd(this, _busy, false);
    __privateAdd(this, _closed, false);
    __privateAdd(this, _fault, "");
    __privateAdd(this, _initial3, 0n);
    __privateAdd(this, _external3, 0n);
    __privateAdd(this, _planReusable, false);
    __privateAdd(this, _renderers, /* @__PURE__ */ new Map());
    __privateAdd(this, _gameplay);
    __privateAdd(this, _revision, 0);
    __privateAdd(this, _submissions, 0);
    __privateAdd(this, _submitTrace);
    __privateAdd(this, _stats, { tick: 0, supportPasses: 0, componentPasses: 0, blockingPasses: 0, maxDistance: 0, supportedWeight: 0, reactionTotal: 0 });
    this.width = initial.width;
    this.height = initial.height;
    this.depth = initial.depth;
    this.chunkSize = initial.chunkSize;
    __privateSet(this, _device, device);
    __privateSet(this, _pipelines, pipelines);
    this.backendInfo = Object.freeze({ ...info });
    this.mode = mode;
    __privateSet(this, _solveBatchLimit, solveBatchLimit);
    const bytes = this.width * this.height * this.depth * 4;
    const buffer = (size, usage) => {
      const b = device.createBuffer({ size, usage });
      __privateGet(this, _owned).push(b);
      return b;
    };
    for (let i = 0; i < 3; i++) __privateGet(this, _banks).push({ grid: buffer(bytes, storage()), energyQ: buffer(bytes, storage()), structure: buffer(bytes, storage()) });
    __privateSet(this, _cold2, buffer(cold.byteLength, storage()));
    device.queue.writeBuffer(__privateGet(this, _cold2), 0, cold);
    __privateSet(this, _work, buffer(64 + bytes * 4, storage()));
    __privateSet(this, _dirty, buffer(bytes / this.chunkSize ** 3 * 3 + 16, storage()));
    __privateSet(this, _indirect, buffer(12, storage() | GPUBufferUsage.INDIRECT));
    __privateSet(this, _activityRead, buffer(12, GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ));
    __privateSet(this, _queryResult, buffer(4096 * 16, storage()));
    __privateSet(this, _queryRead, buffer(4096 * 16, GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ));
    __privateSet(this, _solveDispatch, buffer(16, storage() | GPUBufferUsage.INDIRECT));
    __privateSet(this, _uniform, buffer(__privateGet(this, _params).byteLength, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST));
    __privateSet(this, _commands, buffer(65536 * 16, storage()));
    __privateSet(this, _receipts, buffer(65536 * 8, storage()));
    __privateSet(this, _controlRead, buffer(64, GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ));
    __privateSet(this, _receiptRead, buffer(65536 * 8, GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ));
    __privateSet(this, _fullRead, buffer(bytes * 3, GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ));
    __privateMethod(this, _GpuStructuralWorld3D_instances, upload_fn).call(this, 0, validateStructuralSnapshot3D(initial));
    __privateSet(this, _tick3, initial.tick);
    __privateSet(this, _initial3, total(initial.energyQ));
    device.queue.writeBuffer(__privateGet(this, _dirty), 0, new Uint32Array(__privateGet(this, _dirty).size / 4).fill(1));
    device.addEventListener("uncapturederror", (e) => {
      __privateSet(this, _fault, e.error.message);
    });
    void device.lost.then((info2) => {
      __privateSet(this, _fault, info2.message || info2.reason);
    });
    for (const key of ["width", "height", "depth", "chunkSize", "backendInfo", "mode"]) Object.defineProperty(this, key, { writable: false, configurable: false });
  }
  get tick() {
    return __privateGet(this, _tick3);
  }
  inspectSolve() {
    return { ...__privateGet(this, _stats) };
  }
  inspectActivity() {
    return __privateMethod(this, _GpuStructuralWorld3D_instances, run_fn).call(this, async () => {
      const chunks = this.width * this.height * this.depth / this.chunkSize ** 3;
      if (this.mode === "dense") return { mode: this.mode, tick: __privateGet(this, _tick3), totalChunks: chunks, finalAwake: chunks, dispatchedChunks: chunks * 27, peakChunks: chunks };
      const e = __privateGet(this, _device).createCommandEncoder();
      e.copyBufferToBuffer(__privateGet(this, _dirty), chunks * 12, __privateGet(this, _activityRead), 0, 12);
      const [v] = await __privateMethod(this, _GpuStructuralWorld3D_instances, submit_fn).call(this, e, [{ buffer: __privateGet(this, _activityRead), bytes: 12 }]);
      return { mode: this.mode, tick: __privateGet(this, _tick3), totalChunks: chunks, finalAwake: v[0], dispatchedChunks: v[1], peakChunks: v[2] };
    });
  }
  step(ticks = 1, options = {}) {
    checkedInteger(ticks, 0, 32, "ticks per request");
    checkedInteger(__privateGet(this, _tick3) + ticks, 0, Number.MAX_SAFE_INTEGER, "end tick");
    if (!options || typeof options !== "object" || Array.isArray(options) || Object.keys(options).some((k) => k !== "edits")) throw Error("Invalid structural step options.");
    const commands = prepareStructuralEdits3D(options.edits === void 0 ? [] : options.edits, this);
    return __privateMethod(this, _GpuStructuralWorld3D_instances, run_fn).call(this, async () => {
      if (!ticks && commands.length) {
        __privateSet(this, _planReusable, false);
        const bank = (__privateGet(this, _current) + 1) % 3, external = await __privateMethod(this, _GpuStructuralWorld3D_instances, edits_fn).call(this, commands, bank);
        __privateSet(this, _current, bank);
        __privateWrapper(this, _revision)._++;
        __privateSet(this, _external3, __privateGet(this, _external3) + external);
      }
      for (let t = 0; t < ticks; t++) await __privateMethod(this, _GpuStructuralWorld3D_instances, tickOnce_fn).call(this, t ? new Uint32Array() : commands);
    });
  }
  edit(edits) {
    return this.step(0, { edits });
  }
  setCell(x, y, z, material2, thermal) {
    return this.edit([{ kind: "material", x, y, z, material: material2, ...thermal === void 0 ? {} : { thermal } }]);
  }
  setEnergy(x, y, z, energyQ) {
    return this.edit([{ kind: "energy", x, y, z, energyQ }]);
  }
  setAnchor(x, y, z, anchored) {
    return this.edit([{ kind: "anchor", x, y, z, anchored }]);
  }
  setIntegrity(x, y, z, integrity) {
    return this.edit([{ kind: "integrity", x, y, z, integrity }]);
  }
  setBond(x, y, z, direction, bonded) {
    return this.edit([{ kind: "bond", x, y, z, direction, bonded }]);
  }
  snapshot() {
    return __privateMethod(this, _GpuStructuralWorld3D_instances, run_fn).call(this, async () => {
      const state = await __privateMethod(this, _GpuStructuralWorld3D_instances, readState_fn).call(this), template = new CpuStructuralWorld3D({ width: 4, height: 4, depth: 4, chunkSize: 4 }).snapshot();
      return {
        ...template,
        width: this.width,
        height: this.height,
        depth: this.depth,
        chunkSize: this.chunkSize,
        tick: __privateGet(this, _tick3),
        packedCells: Array.from(state.grid),
        energyQ: Array.from(state.energyQ),
        structure: Array.from(state.structure)
      };
    });
  }
  restore(snapshot) {
    const state = validateStructuralSnapshot3D(snapshot), tick = snapshot.tick;
    if (snapshot.width !== this.width || snapshot.height !== this.height || snapshot.depth !== this.depth) throw Error("Structural snapshot geometry differs.");
    return __privateMethod(this, _GpuStructuralWorld3D_instances, run_fn).call(this, async () => {
      __privateSet(this, _planReusable, false);
      const next = (__privateGet(this, _current) + 1) % 3;
      __privateMethod(this, _GpuStructuralWorld3D_instances, upload_fn).call(this, next, state);
      await __privateMethod(this, _GpuStructuralWorld3D_instances, submit_fn).call(this, __privateGet(this, _device).createCommandEncoder());
      __privateSet(this, _current, next);
      __privateSet(this, _tick3, tick);
      __privateWrapper(this, _revision)._++;
      __privateSet(this, _initial3, total(state.energyQ));
      __privateSet(this, _external3, 0n);
      __privateGet(this, _device).queue.writeBuffer(__privateGet(this, _dirty), 0, new Uint32Array(__privateGet(this, _dirty).size / 4).fill(1));
    });
  }
  queryRegion(request) {
    const { origin, size } = checkedActiveWorldRegion(request, this);
    return __privateMethod(this, _GpuStructuralWorld3D_instances, run_fn).call(this, async () => {
      const count = size[0] * size[1] * size[2], e = __privateGet(this, _device).createCommandEncoder();
      __privateMethod(this, _GpuStructuralWorld3D_instances, parameters_fn).call(this, 0, [...size, 0, ...origin]);
      __privateMethod(this, _GpuStructuralWorld3D_instances, writeParameters_fn).call(this, 1);
      const pass = e.beginComputePass();
      pass.setPipeline(__privateGet(this, _pipelines).queryCells);
      pass.setBindGroup(0, __privateMethod(this, _GpuStructuralWorld3D_instances, group_fn).call(this, "queryCells", __privateGet(this, _current), 0), [0]);
      pass.dispatchWorkgroups(Math.ceil(count / 64));
      pass.end();
      e.copyBufferToBuffer(__privateGet(this, _queryResult), 0, __privateGet(this, _queryRead), 0, count * 16);
      const [words] = await __privateMethod(this, _GpuStructuralWorld3D_instances, submit_fn).call(this, e, [{ buffer: __privateGet(this, _queryRead), bytes: count * 16 }]);
      const grid = new Uint32Array(count), energyQ = new Uint32Array(count), structure = new Uint32Array(count);
      for (let i = 0; i < count; i++) {
        grid[i] = words[i * 4];
        energyQ[i] = words[i * 4 + 1];
        structure[i] = words[i * 4 + 2];
      }
      return { origin: [...origin], size: [...size], grid, energyQ, structure, tick: __privateGet(this, _tick3) };
    });
  }
  copyStateInto(target) {
    const arrays = stateCopyTargets(target, this.width * this.height * this.depth);
    if (arrays.some((a) => !(a.buffer instanceof ArrayBuffer))) throw Error("State copy requires owned ArrayBuffers.");
    return __privateMethod(this, _GpuStructuralWorld3D_instances, run_fn).call(this, async () => {
      const state = await __privateMethod(this, _GpuStructuralWorld3D_instances, readState_fn).call(this);
      for (const [i, key] of ["grid", "energyQ", "structure"].entries()) Uint32Array.prototype.set.call(arrays[i], state[key]);
      return __privateGet(this, _tick3);
    });
  }
  sample(x, y, z) {
    checkedInteger(x, 0, this.width - 1, "x");
    checkedInteger(y, 0, this.height - 1, "y");
    checkedInteger(z, 0, this.depth - 1, "z");
    return this.queryRegion({ origin: [x, y, z], size: [1, 1, 1] }).then((s) => {
      const v = s.grid[0], q = s.energyQ[0], word = s.structure[0];
      return { material: v & 255, materialName: DEFAULT_REGISTRY.material(v & 255).name, phase: v >>> 24 & 15, thermal: v >>> 8 & 255, energyQ: q, temperatureQ: temperatureQ(v, q, cold), structure: word, integrity: word & INTEGRITY_3D, anchored: Boolean(word & ANCHOR_3D), bonds: BONDS_3D.map((b) => Boolean(word & b)) };
    });
  }
  energyBalance() {
    return __privateMethod(this, _GpuStructuralWorld3D_instances, run_fn).call(this, async () => {
      const currentQ = total((await __privateMethod(this, _GpuStructuralWorld3D_instances, readState_fn).call(this)).energyQ);
      return { initialQ: __privateGet(this, _initial3), externalQ: __privateGet(this, _external3), currentQ, driftQ: currentQ - __privateGet(this, _initial3) - __privateGet(this, _external3) };
    });
  }
  energyLedger() {
    return __privateMethod(this, _GpuStructuralWorld3D_instances, run_fn).call(this, async () => energyLedger(await __privateMethod(this, _GpuStructuralWorld3D_instances, readState_fn).call(this), cold));
  }
  createRenderer(canvas) {
    return __privateMethod(this, _GpuStructuralWorld3D_instances, run_fn).call(this, async () => {
      if (__privateGet(this, _renderers).size) throw Error("A structural world supports one terrain cache.");
      const renderer = await makeChunkRenderer(__privateGet(this, _device), canvas, () => ({ grid: __privateGet(this, _banks)[__privateGet(this, _current)].grid, shape: [this.width, this.height, this.depth] }), __privateGet(this, _dirty), this.chunkSize, void 0, () => __privateGet(this, _tick3));
      let closed = false;
      const wrapped = {
        render: (camera) => __privateMethod(this, _GpuStructuralWorld3D_instances, run_fn).call(this, () => renderer.render(camera)),
        setAppearance: (value) => __privateMethod(this, _GpuStructuralWorld3D_instances, run_fn).call(this, () => renderer.setAppearance(value)),
        setHeatDistortion: (value) => __privateMethod(this, _GpuStructuralWorld3D_instances, run_fn).call(this, () => renderer.setHeatDistortion(value)),
        inspectMesh: () => __privateMethod(this, _GpuStructuralWorld3D_instances, run_fn).call(this, () => renderer.inspectMesh()),
        close: () => {
          if (closed) return;
          if (__privateGet(this, _busy)) throw Error("Cannot close terrain with an operation in flight.");
          closed = true;
          renderer.close();
          __privateGet(this, _renderers).delete(wrapped);
        }
      };
      __privateGet(this, _renderers).set(wrapped, renderer);
      return Object.freeze(wrapped);
    });
  }
  createGameplay(initial, rules) {
    const shape = [this.width, this.height, this.depth];
    if (Math.min(...shape) < 16) throw Error("Resident gameplay requires dimensions of at least 16.");
    let state = checkedGameplayState(initial, shape);
    const checkedRules = checkedGameplayRules(rules, shape);
    return __privateMethod(this, _GpuStructuralWorld3D_instances, run_fn).call(this, async () => {
      if (__privateGet(this, _gameplay)) throw Error("A structural world supports one controller.");
      const profiler = new LatencyProfiler(__privateGet(this, _device)), resources = await makeGameplayResources(__privateGet(this, _device), shape, this.chunkSize, __privateGet(this, _cold2), __privateGet(this, _dirty), void 0, checkedRules, profiler);
      let closed = false, revision = __privateGet(this, _revision);
      const initialize = async (s) => {
        resources.writeState(s);
        const e = __privateGet(this, _device).createCommandEncoder();
        resources.initialize(e, __privateGet(this, _banks)[__privateGet(this, _current)].grid, __privateGet(this, _banks)[__privateGet(this, _current)].energyQ);
        await __privateMethod(this, _GpuStructuralWorld3D_instances, submit_fn).call(this, e);
        state = s;
        revision = __privateGet(this, _revision);
      };
      const execute = (command, options = {}) => {
        if (closed || revision !== __privateGet(this, _revision)) throw Error(closed ? "Structural gameplay closed." : "Terrain changed externally; restore the controller before continuing.");
        if (!options || typeof options !== "object" || Array.isArray(options) || Object.keys(options).some((k) => !["edits", "presentation"].includes(k))) throw Error("Invalid structural gameplay options.");
        const c = command ? checkedGameplayCommand(command, __privateGet(this, _tick3) + 1) : { tick: __privateGet(this, _tick3), moveX: 0, moveZ: 0, jump: false, tool: "none", look: state.look };
        if (c.tool !== "none") throw Error("Use M5 structural edits; legacy controller tools are disabled.");
        const edits = prepareStructuralEdits3D(options.edits === void 0 ? [] : options.edits, this);
        if (!command && edits.length) throw Error("Presentation cannot edit physics.");
        let renderer, camera;
        if (options.presentation) {
          renderer = __privateGet(this, _renderers).get(options.presentation.renderer);
          if (!renderer) throw Error("Renderer does not belong to this world.");
          const view = options.presentation.camera;
          if (!view || Object.keys(view).some((k) => !["forward", "right", "up"].includes(k))) throw Error("Invalid presentation camera.");
          camera = { eye: [state.player.x / 256, (state.player.y - 400) / 256, state.player.z / 256], forward: Array.from(view.forward ?? []), right: Array.from(view.right ?? []), up: Array.from(view.up ?? []) };
          renderer.validateCamera(camera);
          const axes = [camera.forward, camera.right, camera.up];
          for (let i = 0; i < 3; i++) for (let j = i; j < 3; j++) if (Math.abs(axes[i].reduce((s, v, k) => s + v * axes[j][k], 0) - (i === j ? 1 : 0)) > 1e-5) throw Error("Camera axes must be orthonormal.");
        }
        return __privateMethod(this, _GpuStructuralWorld3D_instances, run_fn).call(this, async () => {
          const start = __privateGet(this, _submissions);
          let commit;
          const latency = { startedAt: performance.now(), preparedAt: 0, boundaries: [] };
          __privateSet(this, _submitTrace, latency.boundaries);
          resources.writeState(state);
          resources.prepare(c, camera ? camera.forward.map((v) => Math.round(v * 256)) : c.look);
          latency.preparedAt = performance.now();
          const finish = async (e, bank) => {
            const { grid, energyQ } = __privateGet(this, _banks)[bank];
            if (command) {
              resources.tools(e, grid, energyQ, false);
              resources.controller(e, grid, energyQ);
            } else {
              resources.initialize(e, grid, energyQ);
              resources.present(e, grid, energyQ);
            }
            latency.renderStartedAt = performance.now();
            if (renderer && camera) renderer.encode(e, camera, grid, resources.result, void 0, c.tick);
            latency.renderEncodedAt = performance.now();
            if (command) e.copyBufferToBuffer(__privateGet(this, _work), 0, __privateGet(this, _controlRead), 0, 64);
            e.copyBufferToBuffer(resources.result, 0, resources.read, 0, 512);
            const rows = await __privateMethod(this, _GpuStructuralWorld3D_instances, submit_fn).call(this, e, [...command ? [{ buffer: __privateGet(this, _controlRead), bytes: 64 }] : [], { buffer: resources.read, bytes: 512 }]);
            const control = command ? rows[0] : new Uint32Array(16);
            if (control[2]) throw Error(`Structural gameplay rejected solve (${control[2]}).`);
            const decoded = resources.decode(rows[command ? 1 : 0], c.tick), submissions = __privateGet(this, _submissions) - start;
            commit = { ...decoded, submissions, completionBoundaries: submissions, latency };
            return control;
          };
          if (command) await __privateMethod(this, _GpuStructuralWorld3D_instances, tickOnce_fn).call(this, edits, finish);
          else await finish(__privateGet(this, _device).createCommandEncoder(), __privateGet(this, _current));
          if (!commit) throw Error("Missing gameplay commit");
          state = { player: { ...commit.player }, look: [...commit.look], status: commit.status, carved: commit.carved, iceWalk: commit.iceWalk };
          revision = __privateGet(this, _revision);
          latency.completedAt = performance.now();
          return commit;
        });
      };
      const driver = {
        step: (command, options) => execute(command, options),
        present: (presentation) => execute(void 0, { presentation }),
        restore: (s) => {
          if (closed) throw Error("Structural gameplay closed.");
          const checked = checkedGameplayState(s, shape);
          return __privateMethod(this, _GpuStructuralWorld3D_instances, run_fn).call(this, () => initialize(checked));
        },
        inspect: () => structuredClone(state),
        close: () => {
          if (closed) return;
          if (__privateGet(this, _busy)) throw Error("Cannot close gameplay with an operation in flight.");
          closed = true;
          resources.close();
          profiler.close();
          __privateSet(this, _gameplay, void 0);
        }
      };
      try {
        await initialize(state);
        __privateSet(this, _gameplay, driver);
        return Object.freeze(driver);
      } catch (error) {
        resources.close();
        profiler.close();
        throw error;
      }
    });
  }
  close() {
    var _a;
    if (__privateGet(this, _closed)) return;
    if (__privateGet(this, _busy)) throw Error("Cannot close a structural world with an operation in flight.");
    __privateSet(this, _closed, true);
    (_a = __privateGet(this, _gameplay)) == null ? void 0 : _a.close();
    for (const renderer of Array.from(__privateGet(this, _renderers).keys())) renderer.close();
    __privateGet(this, _owned).forEach((b) => b.destroy());
    __privateGet(this, _device).destroy();
  }
}
_device = new WeakMap();
_pipelines = new WeakMap();
_banks = new WeakMap();
_owned = new WeakMap();
_current = new WeakMap();
_tick3 = new WeakMap();
_cold2 = new WeakMap();
_work = new WeakMap();
_dirty = new WeakMap();
_uniform = new WeakMap();
_commands = new WeakMap();
_receipts = new WeakMap();
_controlRead = new WeakMap();
_receiptRead = new WeakMap();
_fullRead = new WeakMap();
_indirect = new WeakMap();
_activityRead = new WeakMap();
_queryResult = new WeakMap();
_queryRead = new WeakMap();
_solveDispatch = new WeakMap();
_solveBatchLimit = new WeakMap();
_groups = new WeakMap();
_params = new WeakMap();
_computePass = new WeakMap();
_busy = new WeakMap();
_closed = new WeakMap();
_fault = new WeakMap();
_initial3 = new WeakMap();
_external3 = new WeakMap();
_planReusable = new WeakMap();
_renderers = new WeakMap();
_gameplay = new WeakMap();
_revision = new WeakMap();
_submissions = new WeakMap();
_submitTrace = new WeakMap();
_stats = new WeakMap();
_GpuStructuralWorld3D_instances = new WeakSet();
address_fn = function(x, y, z) {
  const e = this.chunkSize;
  return (Math.floor(x / e) + this.width / e * (Math.floor(y / e) + this.height / e * Math.floor(z / e))) * e ** 3 + x % e + e * (y % e + e * (z % e));
};
pack_fn = function(source) {
  const out = new Uint32Array(source.length);
  let i = 0;
  for (let z = 0; z < this.depth; z++) for (let y = 0; y < this.height; y++) for (let x = 0; x < this.width; x++) out[__privateMethod(this, _GpuStructuralWorld3D_instances, address_fn).call(this, x, y, z)] = source[i++];
  return out;
};
unpack_fn = function(source) {
  const out = new Uint32Array(source.length);
  let i = 0;
  for (let z = 0; z < this.depth; z++) for (let y = 0; y < this.height; y++) for (let x = 0; x < this.width; x++) out[i++] = source[__privateMethod(this, _GpuStructuralWorld3D_instances, address_fn).call(this, x, y, z)];
  return out;
};
upload_fn = function(bank, state) {
  for (const key of ["grid", "energyQ", "structure"]) __privateGet(this, _device).queue.writeBuffer(__privateGet(this, _banks)[bank][key], 0, __privateMethod(this, _GpuStructuralWorld3D_instances, pack_fn).call(this, state[key]));
};
run_fn = async function(operation) {
  if (__privateGet(this, _closed) || __privateGet(this, _fault) || __privateGet(this, _busy)) throw Error(__privateGet(this, _closed) ? "Structural world closed." : __privateGet(this, _fault) || "Structural operation already in flight.");
  __privateSet(this, _busy, true);
  try {
    return await operation();
  } catch (error) {
    __privateSet(this, _planReusable, false);
    throw error;
  } finally {
    __privateSet(this, _busy, false);
    __privateSet(this, _submitTrace, void 0);
  }
};
group_fn = function(stage, input, output, structure = input) {
  const key = `${stage}/${input}/${output}/${structure}`;
  let group = __privateGet(this, _groups).get(key);
  if (group) return group;
  const a = __privateGet(this, _banks)[input], b = __privateGet(this, _banks)[output], buffers = [a.grid, a.energyQ, b.grid, b.energyQ, __privateGet(this, _cold2), __privateGet(this, _uniform), __privateGet(this, _dirty), __privateGet(this, _banks)[structure].structure, b.structure, __privateGet(this, _work), __privateGet(this, _commands), __privateGet(this, _receipts), __privateGet(this, _indirect), __privateGet(this, _queryResult), __privateGet(this, _solveDispatch)];
  group = __privateGet(this, _device).createBindGroup({ layout: __privateGet(this, _pipelines)[stage].getBindGroupLayout(0), entries: BINDINGS[stage].map((binding) => ({ binding, resource: { buffer: buffers[binding], ...binding === 5 ? { size: 48 } : {} } })) });
  __privateGet(this, _groups).set(key, group);
  return group;
};
compute_fn = function(e, encode) {
  if (__privateGet(this, _computePass)) throw Error("Nested structural compute encoding.");
  const pass = e.beginComputePass();
  __privateSet(this, _computePass, pass);
  try {
    encode();
  } finally {
    pass.end();
    __privateSet(this, _computePass, void 0);
  }
};
dispatch_fn = function(e, stage, input, output, structure = input, slot = 0, indirect = false) {
  const shared = __privateGet(this, _computePass), pass = shared ?? e.beginComputePass();
  pass.setPipeline(__privateGet(this, _pipelines)[stage]);
  pass.setBindGroup(0, __privateMethod(this, _GpuStructuralWorld3D_instances, group_fn).call(this, stage, input, output, structure), BINDINGS[stage].includes(5) ? [slot * 256] : []);
  if (indirect) pass.dispatchWorkgroupsIndirect(__privateGet(this, _solveDispatch), 0);
  else if (stage === "main" && this.mode === "active") pass.dispatchWorkgroupsIndirect(__privateGet(this, _indirect), 0);
  else pass.dispatchWorkgroups(stage === "editBatch" || stage === "collectLocal" || stage.startsWith("relax") ? 1 : Math.ceil(this.width * this.height * this.depth / 64));
  if (!shared) pass.end();
};
parameters_fn = function(slot, values) {
  __privateGet(this, _params).fill(0, slot * 64, (slot + 1) * 64);
  __privateGet(this, _params).set(values, slot * 64 + 4);
};
writeParameters_fn = function(slots) {
  __privateGet(this, _device).queue.writeBuffer(__privateGet(this, _uniform), 0, __privateGet(this, _params), 0, slots * 64);
};
submit_fn = async function(e, reads = []) {
  __privateGet(this, _device).pushErrorScope("validation");
  let timer;
  try {
    __privateGet(this, _device).queue.submit([e.finish()]);
    __privateWrapper(this, _submissions)._++;
    const timing = __privateGet(this, _submitTrace) ? { submittedAt: performance.now() } : void 0;
    if (timing) __privateGet(this, _submitTrace).push(timing);
    const validation = __privateGet(this, _device).popErrorScope().then((error) => {
      if (timing) timing.validatedAt = performance.now();
      return error;
    });
    const mapped = Promise.all(reads.map(async ({ buffer, bytes }) => {
      await buffer.mapAsync(GPUMapMode.READ, 0, bytes);
      try {
        return new Uint32Array(buffer.getMappedRange(0, bytes)).slice();
      } finally {
        buffer.unmap();
      }
    })).then((values2) => {
      if (timing) timing.mappedAt = performance.now();
      return values2;
    });
    const pending = Promise.all([mapped, __privateGet(this, _device).queue.onSubmittedWorkDone().then(() => {
      if (timing) timing.queueCompletedAt = performance.now();
    }), validation]).then(([values2, , error]) => {
      if (error) throw Error(error.message);
      return values2;
    });
    const values = await Promise.race([pending, new Promise((_, reject) => {
      timer = setTimeout(() => {
        __privateSet(this, _fault, "M5 GPU completion exceeded 1500 ms; state not committed.");
        __privateGet(this, _device).destroy();
        reject(Error(__privateGet(this, _fault)));
      }, 1500);
    })]);
    if (__privateGet(this, _fault)) throw Error(__privateGet(this, _fault));
    return values;
  } finally {
    if (timer) clearTimeout(timer);
  }
};
control_fn = async function(e) {
  e.copyBufferToBuffer(__privateGet(this, _work), 0, __privateGet(this, _controlRead), 0, 64);
  const [value] = await __privateMethod(this, _GpuStructuralWorld3D_instances, submit_fn).call(this, e, [{ buffer: __privateGet(this, _controlRead), bytes: 64 }]);
  if (value[2]) throw Error(`Structural solve rejected scratch state (code ${value[2]}).`);
  return value;
};
converge_fn = async function(stage, input, structure, deadline) {
  const max = this.width * this.height * this.depth + 4;
  for (let count = 0; count < max; count += 4) {
    if (performance.now() > deadline) throw Error(`Structural ${stage} deadline exceeded; tick not committed.`);
    const e = __privateGet(this, _device).createCommandEncoder();
    e.clearBuffer(__privateGet(this, _work), 0, 4);
    __privateMethod(this, _GpuStructuralWorld3D_instances, compute_fn).call(this, e, () => {
      for (let k = 0; k < 4; k++) __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, stage, input, 0, structure);
    });
    const control = await __privateMethod(this, _GpuStructuralWorld3D_instances, control_fn).call(this, e);
    if (control[0] === 0) return count + 4;
  }
  throw Error(`Structural ${stage} failed to converge; tick not committed.`);
};
edits_fn = async function(commands, bank) {
  if (!commands.length) return 0n;
  const count = commands.length / 4;
  __privateGet(this, _device).queue.writeBuffer(__privateGet(this, _commands), 0, commands);
  let e = __privateGet(this, _device).createCommandEncoder();
  e.clearBuffer(__privateGet(this, _work), 0, 64);
  for (const key of ["grid", "energyQ", "structure"]) e.copyBufferToBuffer(__privateGet(this, _banks)[__privateGet(this, _current)][key], 0, __privateGet(this, _banks)[bank][key], 0, __privateGet(this, _banks)[bank][key].size);
  for (let start = 0; start < count; ) {
    let slots = 0;
    while (start < count && slots < 16) {
      __privateMethod(this, _GpuStructuralWorld3D_instances, parameters_fn).call(this, slots, [0, 0, 0, 0, 0, start, Math.min(start + 64, count)]);
      __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "editBatch", __privateGet(this, _current), bank, __privateGet(this, _current), slots++);
      start += 64;
    }
    __privateMethod(this, _GpuStructuralWorld3D_instances, writeParameters_fn).call(this, slots);
    await __privateMethod(this, _GpuStructuralWorld3D_instances, control_fn).call(this, e);
    e = __privateGet(this, _device).createCommandEncoder();
  }
  e.copyBufferToBuffer(__privateGet(this, _receipts), 0, __privateGet(this, _receiptRead), 0, count * 8);
  const [pairs] = await __privateMethod(this, _GpuStructuralWorld3D_instances, submit_fn).call(this, e, [{ buffer: __privateGet(this, _receiptRead), bytes: count * 8 }]);
  let external = 0n;
  for (let k = 0; k < count; k++) external += BigInt(pairs[k * 2 + 1]) - BigInt(pairs[k * 2]);
  return external;
};
batchedSolve_fn = async function(commands, a, b) {
  const edited = commands.length > 0, input = edited ? a : __privateGet(this, _current), damage = edited ? b : a, normalized = edited ? a : b;
  const e = __privateGet(this, _device).createCommandEncoder();
  e.clearBuffer(__privateGet(this, _work), 0, 64);
  if (edited) {
    __privateGet(this, _device).queue.writeBuffer(__privateGet(this, _commands), 0, commands);
    for (const key of ["grid", "energyQ", "structure"]) e.copyBufferToBuffer(__privateGet(this, _banks)[__privateGet(this, _current)][key], 0, __privateGet(this, _banks)[a][key], 0, __privateGet(this, _banks)[a][key].size);
    __privateMethod(this, _GpuStructuralWorld3D_instances, parameters_fn).call(this, 0, [0, 0, 0, 0, 0, 0, commands.length / 4]);
    __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "editBatch", __privateGet(this, _current), a, __privateGet(this, _current), 0);
  }
  __privateMethod(this, _GpuStructuralWorld3D_instances, compute_fn).call(this, e, () => {
    const relax = (stage, structure, slot) => {
      __privateMethod(this, _GpuStructuralWorld3D_instances, parameters_fn).call(this, slot, [1 << slot - 1, slot, 0, 0]);
      __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "relaxStart", input, damage);
      const budget = slot === 4 ? Math.min(__privateGet(this, _solveBatchLimit), 4) : __privateGet(this, _solveBatchLimit);
      for (let k = 0; k < budget; k++) {
        __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, stage, input, damage, structure, 0, true);
        __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "relaxAdvance", input, damage);
      }
      __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "relaxEnd", input, damage, input, slot);
    };
    __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "supportInit", input, damage);
    relax("supportRelax", input, 1);
    __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "supportSummary", input, damage);
    __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "loadInit", input, damage);
    relax("loadRelax", input, 2);
    __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "loadSummary", input, damage);
    __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "damage", input, damage);
    __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "normalize", input, normalized, damage);
    __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "componentInit", input, damage, normalized);
    relax("componentRelax", normalized, 3);
    __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "blockInit", input, damage, normalized);
    relax("blockRelax", normalized, 4);
  });
  __privateMethod(this, _GpuStructuralWorld3D_instances, writeParameters_fn).call(this, 5);
  e.copyBufferToBuffer(__privateGet(this, _work), 0, __privateGet(this, _controlRead), 0, 64);
  if (edited) e.copyBufferToBuffer(__privateGet(this, _receipts), 0, __privateGet(this, _receiptRead), 0, commands.length * 2);
  const rows = await __privateMethod(this, _GpuStructuralWorld3D_instances, submit_fn).call(this, e, [{ buffer: __privateGet(this, _controlRead), bytes: 64 }, ...edited ? [{ buffer: __privateGet(this, _receiptRead), bytes: commands.length * 2 }] : []]), control = rows[0];
  if (control[2]) throw Error(`Structural solve rejected scratch state (code ${control[2]}).`);
  if (control[8]) return { complete: false, mask: control[8] };
  if (control[4] !== control[5]) throw Error("Structural reactions do not balance supported weight.");
  let external = 0n;
  if (edited) for (let k = 0; k < commands.length / 4; k++) external += BigInt(rows[1][k * 2 + 1]) - BigInt(rows[1][k * 2]);
  return { complete: true, input, damage, normalized, external, control };
};
tickOnce_fn = async function(commands, finish) {
  const deadline = performance.now() + 5e3, [a, b] = [0, 1, 2].filter((i) => i !== __privateGet(this, _current)), edited = commands.length > 0;
  if (__privateGet(this, _planReusable) && !edited) {
    const input2 = __privateGet(this, _current), e2 = __privateGet(this, _device).createCommandEncoder();
    e2.clearBuffer(__privateGet(this, _work), 0, 4);
    e2.clearBuffer(__privateGet(this, _work), 8, 4);
    e2.clearBuffer(__privateGet(this, _work), 24, 4);
    const current2 = __privateMethod(this, _GpuStructuralWorld3D_instances, encodeMotionAndMaterial_fn).call(this, e2, input2, a, b, input2), control2 = await (finish ? finish(e2, current2) : __privateMethod(this, _GpuStructuralWorld3D_instances, control_fn).call(this, e2));
    __privateSet(this, _current, current2);
    __privateWrapper(this, _tick3)._++;
    __privateWrapper(this, _revision)._++;
    __privateSet(this, _planReusable, control2[6] === 0);
    __privateSet(this, _stats, { ...__privateGet(this, _stats), tick: __privateGet(this, _tick3), supportPasses: 0, loadPasses: 0, componentPasses: 0, blockingPasses: 0, planReused: true, planReusable: __privateGet(this, _planReusable) });
    return;
  }
  __privateSet(this, _planReusable, false);
  let fallbackMask = 0;
  if (commands.length <= 256) {
    const plan = await __privateMethod(this, _GpuStructuralWorld3D_instances, batchedSolve_fn).call(this, commands, a, b);
    if (plan.complete) {
      const e2 = __privateGet(this, _device).createCommandEncoder(), current2 = __privateMethod(this, _GpuStructuralWorld3D_instances, encodeMotionAndMaterial_fn).call(this, e2, plan.input, plan.damage, plan.normalized, plan.normalized), control2 = await (finish ? finish(e2, current2) : __privateMethod(this, _GpuStructuralWorld3D_instances, control_fn).call(this, e2));
      __privateSet(this, _current, current2);
      __privateWrapper(this, _tick3)._++;
      __privateWrapper(this, _revision)._++;
      __privateSet(this, _external3, __privateGet(this, _external3) + plan.external);
      __privateSet(this, _planReusable, !edited && control2[6] === 0);
      __privateSet(this, _stats, { tick: __privateGet(this, _tick3), supportPasses: plan.control[9], loadPasses: plan.control[10], componentPasses: plan.control[11], blockingPasses: plan.control[12], maxDistance: plan.control[1], supportedWeight: plan.control[4], reactionTotal: plan.control[5], planReused: false, planReusable: __privateGet(this, _planReusable), batchedSolve: true, fallbackMask: 0 });
      return;
    }
    fallbackMask = plan.mask;
  }
  const external = await __privateMethod(this, _GpuStructuralWorld3D_instances, edits_fn).call(this, commands, a), input = edited ? a : __privateGet(this, _current), damage = edited ? b : a, normalized = edited ? a : b;
  let e = __privateGet(this, _device).createCommandEncoder();
  e.clearBuffer(__privateGet(this, _work), 0, 64);
  __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "supportInit", input, damage);
  await __privateMethod(this, _GpuStructuralWorld3D_instances, control_fn).call(this, e);
  const supportPasses = await __privateMethod(this, _GpuStructuralWorld3D_instances, converge_fn).call(this, "supportRelax", input, input, deadline);
  e = __privateGet(this, _device).createCommandEncoder();
  __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "supportSummary", input, damage);
  const summary = await __privateMethod(this, _GpuStructuralWorld3D_instances, control_fn).call(this, e), maxDistance = summary[1];
  for (let level = maxDistance; level >= 0; ) {
    if (performance.now() > deadline) throw Error("Structural load solve deadline exceeded; tick not committed.");
    e = __privateGet(this, _device).createCommandEncoder();
    let slots = 0;
    while (level >= 0 && slots < 32) {
      __privateMethod(this, _GpuStructuralWorld3D_instances, parameters_fn).call(this, slots, [0, 0, 0, 0, 0, level--]);
      __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "loadLevel", input, damage, input, slots++);
    }
    __privateMethod(this, _GpuStructuralWorld3D_instances, writeParameters_fn).call(this, slots);
    await __privateMethod(this, _GpuStructuralWorld3D_instances, control_fn).call(this, e);
  }
  e = __privateGet(this, _device).createCommandEncoder();
  __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "damage", input, damage);
  __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "normalize", input, normalized, damage);
  __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "componentInit", input, damage, normalized);
  const balanced = await __privateMethod(this, _GpuStructuralWorld3D_instances, control_fn).call(this, e);
  if (balanced[4] !== balanced[5]) throw Error("Structural reactions do not balance supported weight; tick not committed.");
  const componentPasses = await __privateMethod(this, _GpuStructuralWorld3D_instances, converge_fn).call(this, "componentRelax", input, normalized, deadline);
  e = __privateGet(this, _device).createCommandEncoder();
  __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "blockInit", input, damage, normalized);
  await __privateMethod(this, _GpuStructuralWorld3D_instances, control_fn).call(this, e);
  const blockingPasses = await __privateMethod(this, _GpuStructuralWorld3D_instances, converge_fn).call(this, "blockRelax", input, normalized, deadline);
  e = __privateGet(this, _device).createCommandEncoder();
  const current = __privateMethod(this, _GpuStructuralWorld3D_instances, encodeMotionAndMaterial_fn).call(this, e, input, damage, normalized, normalized), control = await (finish ? finish(e, current) : __privateMethod(this, _GpuStructuralWorld3D_instances, control_fn).call(this, e));
  __privateSet(this, _current, current);
  __privateWrapper(this, _tick3)._++;
  __privateWrapper(this, _revision)._++;
  __privateSet(this, _external3, __privateGet(this, _external3) + external);
  __privateSet(this, _planReusable, !edited && control[6] === 0);
  __privateSet(this, _stats, { tick: __privateGet(this, _tick3), supportPasses, componentPasses, blockingPasses, maxDistance, supportedWeight: balanced[4], reactionTotal: balanced[5], planReused: false, planReusable: __privateGet(this, _planReusable), batchedSolve: false, fallbackMask });
};
encodeMotionAndMaterial_fn = function(e, input, damage, normalized, structure) {
  __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "applyMotion", input, damage, structure);
  let current = damage, spare = normalized, slot = 0;
  if (this.mode === "active") {
    for (const key of ["grid", "energyQ", "structure"]) e.copyBufferToBuffer(__privateGet(this, _banks)[current][key], 0, __privateGet(this, _banks)[spare][key], 0, __privateGet(this, _banks)[current][key].size);
    const chunkBytes = this.width * this.height * this.depth / this.chunkSize ** 3 * 4;
    e.clearBuffer(__privateGet(this, _dirty), chunkBytes, __privateGet(this, _dirty).size - chunkBytes);
  }
  __privateMethod(this, _GpuStructuralWorld3D_instances, compute_fn).call(this, e, () => {
    if (this.mode === "active") __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "certifyLocal", current, spare);
    for (const p of volumeSchedule(__privateGet(this, _tick3))) {
      __privateMethod(this, _GpuStructuralWorld3D_instances, parameters_fn).call(this, slot, [KINDS.indexOf(p.kind), p.axis, p.parity, p.direction >>> 0, __privateGet(this, _tick3) >>> 0]);
      if (this.mode === "active") __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "collectLocal", current, spare);
      __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "main", current, spare, current, slot++);
      [current, spare] = [spare, current];
    }
    __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "normalize", current, spare);
  });
  __privateMethod(this, _GpuStructuralWorld3D_instances, writeParameters_fn).call(this, slot);
  e.copyBufferToBuffer(__privateGet(this, _banks)[spare].structure, 0, __privateGet(this, _banks)[current].structure, 0, __privateGet(this, _banks)[current].structure.size);
  if (input !== damage && input !== normalized) __privateMethod(this, _GpuStructuralWorld3D_instances, dispatch_fn).call(this, e, "certifyPlan", input, current);
  return current;
};
readState_fn = async function() {
  const e = __privateGet(this, _device).createCommandEncoder(), bytes = this.width * this.height * this.depth * 4, bank = __privateGet(this, _banks)[__privateGet(this, _current)];
  for (const [i, key] of ["grid", "energyQ", "structure"].entries()) e.copyBufferToBuffer(bank[key], 0, __privateGet(this, _fullRead), i * bytes, bytes);
  const [values] = await __privateMethod(this, _GpuStructuralWorld3D_instances, submit_fn).call(this, e, [{ buffer: __privateGet(this, _fullRead), bytes: bytes * 3 }]);
  return { grid: __privateMethod(this, _GpuStructuralWorld3D_instances, unpack_fn).call(this, values.subarray(0, bytes / 4)), energyQ: __privateMethod(this, _GpuStructuralWorld3D_instances, unpack_fn).call(this, values.subarray(bytes / 4, bytes / 2)), structure: __privateMethod(this, _GpuStructuralWorld3D_instances, unpack_fn).call(this, values.subarray(bytes / 2)) };
};
async function createStateSpaceStructuralWorld3DGPU(options = {}) {
  var _a;
  if (!options || typeof options !== "object" || Array.isArray(options)) throw Error("Invalid structural GPU options.");
  const { mode = "dense", solveBatchLimit = 16, ...geometry } = options;
  if (mode !== "dense" && mode !== "active") throw Error("Invalid structural execution mode.");
  checkedInteger(solveBatchLimit, 1, 64, "solve batch limit");
  const g = activeWorldGeometry(geometry), initial = new CpuStructuralWorld3D(geometry).snapshot();
  if (!((_a = globalThis.navigator) == null ? void 0 : _a.gpu)) throw Error("WebGPU unavailable.");
  const adapter = await navigator.gpu.requestAdapter();
  if (!adapter) throw Error("No WebGPU adapter.");
  const device = await adapter.requestDevice();
  try {
    const base = structuralShaders(g.chunkSize, [g.width, g.height, g.depth]), active = mode === "active" ? structuralActivityShaders(base.physics, g.chunkSize, g.width * g.height * g.depth / g.chunkSize ** 3) : void 0;
    const codes = { physics: (active == null ? void 0 : active.physics) ?? base.physics, mechanics: base.mechanics, ...active ? { planning: active.planning } : {} }, pipelines = {};
    for (const [name, code] of Object.entries(codes)) {
      const module = device.createShaderModule({ code }), errors = (await module.getCompilationInfo()).messages.filter((m) => m.type === "error");
      if (errors.length) throw Error(errors.map((m) => `${name}:${m.lineNum}:${m.linePos} ${m.message}`).join("\n"));
      for (const stage of Object.keys(BINDINGS)) {
        const moduleName = stage === "main" ? "physics" : ["certifyLocal", "collectLocal"].includes(stage) ? "planning" : "mechanics";
        if (moduleName !== name) continue;
        const layout = device.createBindGroupLayout({ entries: BINDINGS[stage].map((binding) => ({ binding, visibility: GPUShaderStage.COMPUTE, buffer: binding === 5 ? { type: "uniform", hasDynamicOffset: true, minBindingSize: 48 } : { type: [0, 1, 4, 7, 10].includes(binding) ? "read-only-storage" : "storage" } })) });
        pipelines[stage] = await device.createComputePipelineAsync({ layout: device.createPipelineLayout({ bindGroupLayouts: [layout] }), compute: { module, entryPoint: stage } });
      }
    }
    const info = adapter.info;
    return new GpuStructuralWorld3D(initial, device, pipelines, { vendor: info.vendor, architecture: info.architecture, device: info.device, description: info.description, isFallbackAdapter: info.isFallbackAdapter }, mode, solveBatchLimit);
  } catch (error) {
    device.destroy();
    throw error;
  }
}
export {
  GpuStructuralWorld3D,
  createStateSpaceStructuralWorld3DGPU,
  checkedGameplayState as validateStructuralGameplayState3D
};
