import { type MaterialRegistry } from './registry.js';
export { MAX_CELLS, checkedInteger, validateDimensions, validatePackedCells } from './validation.js';
import { type StructuralState } from './structure.js';
export interface PackedSnapshot {
    schemaVersion: number;
    rulesVersion: string;
    materialCatalogHash: string;
    width: number;
    height: number;
    tick: number;
    packedCells: ArrayLike<number>;
    energyQ: ArrayLike<number>;
    structure: ArrayLike<number>;
}
export declare function validateSnapshot(snapshot: PackedSnapshot, registry?: MaterialRegistry): StructuralState;
