/** Optional presentation only. The physical grid is bound read-only in every pass. */
import type { LatencyProfiler, Trace } from './latency.js';
export declare function cavernShaders(shape: readonly number[], edge: number, capacity: number): {
    lights: string;
    draw: string;
};
export declare function makeCavernAppearance(device: GPUDevice, format: GPUTextureFormat, shape: readonly number[], edge: number, capacity: number, faces: GPUBuffer, uniform: GPUBuffer): Promise<{
    draw: GPURenderPipeline;
    prepare(encoder: GPUCommandEncoder, grid: GPUBuffer, w: number, h: number, tick: number, profiler?: LatencyProfiler, trace?: Trace): {
        view: GPUTextureView;
        group: GPUBindGroup;
    };
    finish(encoder: GPUCommandEncoder, view: GPUTextureView, profiler?: LatencyProfiler, trace?: Trace): void;
    close(): void;
}>;
