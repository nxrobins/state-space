export type { LatencyRecord, LatencySnapshot, RegionRequest3D, Region3D, VolumeEdit3D, GpuStepOptions3D, GpuVolume3D, TerrainCamera, TerrainRenderer, TerrainAppearance } from './3d-gpu-core.js';
export declare function createGpuField3D(width: number, height: number, depth: number, fillMaterial?: number, options?: {
    profiling?: boolean;
    gpuTiming?: boolean;
}): Promise<import("./3d-gpu-core.js").GpuVolume3D>;
