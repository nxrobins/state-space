import { validateVolumeSnapshot, type VolumeSnapshot, type VolumeSample } from './3d.js';
import type { GameplayState3D, GameplayRules3D, ResidentGameplay3D } from './gameplay-view.js';
export type { GameplayState3D, GameplayRules3D, GameplayCommand3D, GameplayPresentation3D, GameplayCommit3D, ResidentGameplay3D } from './gameplay-view.js';
import type { LatencySnapshot } from './3d-view.js';
export type { LatencyRecord, LatencySnapshot } from './3d-view.js';
import { type TerrainRenderer } from './3d-view.js';
export type RegionRequest3D = {
    origin: readonly number[];
    size: readonly number[];
};
export type Region3D = {
    origin: number[];
    size: number[];
    grid: Uint32Array;
    tick: number;
};
export type VolumeEdit3D = {
    x: number;
    y: number;
    z: number;
} & ({
    material: number;
    thermal?: number;
} | {
    energyQ: number;
});
export type GpuStepOptions3D = {
    edits?: readonly VolumeEdit3D[];
    region?: RegionRequest3D;
};
export type Activity3D = {
    mode: 'dense' | 'sparse';
    tick: number;
    totalChunks: number;
    activityChunkSize: number;
    storageChunks: number;
    awake: number[];
    wakeReasons: number[];
    terrainDirty?: number[];
    dispatchedChunks: number;
    denseChunks: number;
    peakChunks: number;
    sleepingChunks: number;
    plannerBuilds?: number;
    plannerReuses?: number;
};
export interface GpuVolume3D {
    readonly width: number;
    readonly height: number;
    readonly depth: number;
    readonly tick: number;
    readonly backendInfo: Readonly<Record<string, string | boolean>>;
    step(ticks?: number, options?: GpuStepOptions3D): Promise<Region3D | undefined>;
    queryRegion(region: RegionRequest3D): Promise<Region3D>;
    snapshot(): Promise<VolumeSnapshot>;
    restore(snapshot: VolumeSnapshot): Promise<void>;
    sample(x: number, y: number, z: number): Promise<VolumeSample>;
    setCell(x: number, y: number, z: number, material: number, thermal?: number): Promise<void>;
    setEnergy(x: number, y: number, z: number, energyQ: number): Promise<void>;
    energyBalance(): Promise<{
        initialQ: bigint;
        externalQ: bigint;
        currentQ: bigint;
        driftQ: bigint;
    }>;
    /** Diagnostic: run one pass on scratch state without changing the committed field. */
    inspectPass(passIndex: number): Promise<VolumeSnapshot>;
    createRenderer(canvas: HTMLCanvasElement): Promise<TerrainRenderer>;
    createGameplay(state: GameplayState3D, rules: GameplayRules3D): Promise<ResidentGameplay3D>;
    inspectActivity(): Promise<Activity3D>;
    inspectLatency(afterId?: number): LatencySnapshot;
    settleLatency(): Promise<void>;
    close(): void;
}
export type { TerrainCamera, TerrainRenderer, TerrainAppearance } from './3d-view.js';
export type ResidentConfig = {
    profiling?: boolean;
    gpuTiming?: boolean;
    chunkSize: number;
    sparse?: boolean;
    activityReadbackInterval?: number;
    cpu: (w: number, h: number, d: number, fill?: number) => import('./3d.js').StateSpaceField3D;
    validate: typeof validateVolumeSnapshot;
};
export declare function createResidentVolume(initial: VolumeSnapshot, config: ResidentConfig): Promise<GpuVolume3D>;
