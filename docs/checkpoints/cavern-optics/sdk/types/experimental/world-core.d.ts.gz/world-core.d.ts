/** Finite, globally clocked 3D worlds. Chunks are storage, never simulation islands. */
import { type VolumeSnapshot, type StateSpaceField3D } from './3d-core.js';
import type { GpuStepOptions3D, Region3D, RegionRequest3D } from './3d-gpu-core.js';
export { MAT, PHASE, MATERIALS_3D, MAX_ENERGY_Q, RULES_VERSION_3D } from './3d.js';
export declare const WORLD_VERSION_3D = "finite-chunks-1";
export declare const MAX_WORLD_CELLS_3D: number;
export type WorldOptions3D = {
    width?: number;
    height?: number;
    depth?: number;
    chunkSize?: number;
    fillMaterial?: number;
};
export type WorldGeometry3D = {
    width: number;
    height: number;
    depth: number;
    chunkSize: number;
};
export type WorldChunk3D = {
    origin: number[];
    packedCells: number[];
    energyQ: number[];
};
export type WorldSnapshot3D = {
    schemaVersion: number;
    worldVersion: string;
    rulesVersion: string;
    materialCatalogHash: string;
    width: number;
    height: number;
    depth: number;
    chunkSize: number;
    tick: number;
    chunks: WorldChunk3D[];
};
export declare function worldGeometry(options?: WorldOptions3D): WorldGeometry3D;
/** Internal monolithic oracle uses precisely the shipped volume law and global schedule. */
export declare const referenceVolume: (w: number, h: number, d: number, fill?: number) => StateSpaceField3D;
export declare const validateWorldFlat: (value: VolumeSnapshot) => import("./3d-core.js").VolumeState;
export declare function chunkSnapshot(flat: VolumeSnapshot, geometry: WorldGeometry3D): WorldSnapshot3D;
/** Returns an owned, canonical monolithic copy, after validating the complete world. */
export declare function validateWorldSnapshot(value: WorldSnapshot3D): VolumeSnapshot;
export declare function checkedWorldRegion(request: RegionRequest3D, geometry: WorldGeometry3D): RegionRequest3D;
export declare class CpuWorld3D {
    #private;
    readonly width: number;
    readonly height: number;
    readonly depth: number;
    readonly chunkSize: number;
    constructor(options?: WorldOptions3D);
    get tick(): number;
    get grid(): Uint32Array<ArrayBufferLike>;
    get energyQ(): Uint32Array<ArrayBufferLike>;
    sample(x: number, y: number, z: number): import("./3d-core.js").VolumeSample;
    setCell(x: number, y: number, z: number, material: number, thermal?: number): void;
    setEnergy(x: number, y: number, z: number, q: number): void;
    copyStateInto(target: Parameters<StateSpaceField3D['copyStateInto']>[0]): number;
    energyLedger(): {
        sensibleQ: bigint;
        latentQ: bigint;
        chemicalQ: bigint;
        totalQ: bigint;
    };
    energyBalance(): {
        initialQ: bigint;
        externalQ: bigint;
        currentQ: bigint;
        driftQ: bigint;
    };
    snapshot(): WorldSnapshot3D;
    restore(value: WorldSnapshot3D): void;
    queryRegion(request: RegionRequest3D): Region3D;
    step(ticks?: number, options?: GpuStepOptions3D): Region3D | undefined;
}
export declare function createStateSpaceWorld3D(options?: WorldOptions3D): CpuWorld3D;
