import { type MaterialRegistry } from './registry.js';
import { type PhysicsState } from './thermal.js';
export declare const INTEGRITY_MASK = 255;
export declare const BOND_BITS: readonly number[];
export declare const ANCHOR = 4096;
export declare const FRESH = 8192;
export interface StructuralMaterial {
    id: number;
    density: number;
    cohesion: number;
    softening: number;
}
export interface StructuralState extends PhysicsState {
    structure: Uint32Array;
}
export interface StructuralStateInput {
    grid: ArrayLike<number>;
    energyQ: ArrayLike<number>;
    structure: ArrayLike<number>;
}
export declare function rulesForRegistry(registry: MaterialRegistry): StructuralRules;
/** Explicit creation from packed heat doses, never an implicit continuation. */
export declare function createPhysicsState(cells: ArrayLike<number>, width: number, height: number, registry: MaterialRegistry): StructuralState;
/** Explicit initial creation when the complete energy coordinate is supplied. */
export declare function seedStructureState(state: PhysicsState, width: number, height: number, registry: MaterialRegistry): StructuralState;
export declare function rewrittenStructure(before: number, after: number, word: number, rules: StructuralRules): number;
export declare function cloneStructure(state: StructuralState): StructuralState;
export declare class StructuralRules {
    #private;
    constructor(materials: readonly StructuralMaterial[], registry: MaterialRegistry);
    material(voxel: number): Readonly<StructuralMaterial>;
    eligible(voxel: number): boolean;
    validate(cells: ArrayLike<number>, energy: ArrayLike<number>, count: number): PhysicsState;
    temperature(voxel: number, energy: number): number;
}
export declare function normalizeBonds(cells: ArrayLike<number>, words: ArrayLike<number>, width: number, height: number, rules: StructuralRules): Uint32Array;
export declare function seedStructure(cells: ArrayLike<number>, width: number, height: number, rules: StructuralRules, anchors?: readonly number[]): Uint32Array;
export declare function validateStructure(state: StructuralStateInput, width: number, height: number, rules: StructuralRules, completed?: boolean): StructuralState;
export interface ComponentReport {
    readonly id: number;
    readonly cells: readonly number[];
    readonly moving: boolean;
    readonly anchored: boolean;
}
export interface StructuralPlan {
    readonly width: number;
    readonly height: number;
    readonly sources: readonly number[];
    readonly structure: readonly number[];
    readonly loads: readonly number[];
    readonly capacities: readonly number[];
    readonly reactions: readonly number[];
    readonly distances: readonly number[];
    readonly components: readonly ComponentReport[];
    readonly supportedWeight: number;
    apply(state: StructuralState, width: number, height: number): StructuralState;
}
/** Integer loads fit exactly in Number: <= 4 * MAX_CELLS < 2^32.
 * Capacity products are <= 4080 * 255 * 16384 < 2^35. Never narrow to i32/u32.
 */
export declare function planStructure(input: StructuralState, width: number, height: number, rules: StructuralRules): StructuralPlan;
