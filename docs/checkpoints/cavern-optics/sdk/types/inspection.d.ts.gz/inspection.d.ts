/** Immutable per-pass deltas. Collection is opt-in and has readback/memory costs. */
import { energyLedger } from './thermal.js';
import type { StructuralState, StructuralPlan } from './structure.js';
export interface CellChange {
    readonly index: number;
    readonly beforePacked: number;
    readonly afterPacked: number;
    readonly beforeEnergyQ: number;
    readonly afterEnergyQ: number;
    readonly beforeStructure: number;
    readonly afterStructure: number;
}
export interface PassReport {
    readonly tick: number;
    readonly passId: string;
    readonly changes: readonly CellChange[];
    readonly before: Readonly<ReturnType<typeof energyLedger>>;
    readonly after: Readonly<ReturnType<typeof energyLedger>>;
    readonly structure?: StructuralPlan;
}
export interface StepOptions {
    inspect?: boolean;
}
export declare function inspectPass(before: StructuralState, after: StructuralState, cold: Uint32Array, tick: number, passId: string, structure?: StructuralPlan): PassReport;
